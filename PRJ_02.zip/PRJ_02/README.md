# Real-Time Hospital Bed & Operating Room (OR) Scheduling Optimization Engine

[![Course: DSA-3](https://img.shields.io/badge/Course-DSA--3%20(25CS2103E)-blue.svg)](#)
[![Institution: KL University](https://img.shields.io/badge/Institution-KL%20University-red.svg)](#)
[![Java: Zero-Dependency](https://img.shields.io/badge/Engine-Zero--Dependency%20(No%20java.util.*)-green.svg)](#)

---

## 👨‍🎓 Project Information & Academic Alignment

* **Course**: Data Structures and Algorithms - 3 (**25CS2103E**)
* **Academic Year**: 2026–2027 (Odd Semester)
* **Institution**: Department of Computer Science & Engineering, KL Deemed to be University
* **Project Title**: **Hospital Bed / OR Scheduling Optimization Engine**
* **Project Path**: `D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02`

---

## 📖 Executive Summary & Problem Formulation

Hospitals operate under acute resource constraints: surgical operating rooms (OR suites), specialized intensive care beds (ICU, PACU, Surgical, General), specialized surgeons, and tight clinical deadlines. Inefficient, manual scheduling leads to prolonged patient waiting times, high OR idle dead time, and dangerous delays for incoming trauma emergencies.

This project implements an end-to-end **Hospital Bed & OR Scheduling Optimization Engine** that assigns incoming patients and procedures to rooms and discrete time slots to:
1. **Minimize Multi-OR Makespan (\(C_{\max}\))** using **Graham's Longest Processing Time (LPT) 4/3-Approximation Algorithm**.
2. **Minimize Inter-Procedure Setup & Sterilization Dead Time** using **Bitmask Dynamic Programming (TSP Formulation)** in \(O(n^2 2^n)\) time.
3. **Discover Structural Capacity Bottlenecks** via **Network Flow & Max-Flow / Min-Cut Duality (Dinic's Algorithm)** in \(O(V^2E)\) time.
4. **Perform Instantaneous Multi-Keyword Emergency Triage** on inbound clinical EHR notes using the **Aho-Corasick Automaton** and **KMP Matcher**.
5. **Resolve Resource Conflicts** via **Vertex Cover 2-Approximation** and **Bipartite Matching**.
6. **Provide High-Performance Telemetry** via **Las Vegas Randomized QuickSort**, **Universal Hashing**, **Reservoir Sampling**, and **Blelloch Parallel Prefix Sum**.

> [!IMPORTANT]
> **Strict Course Constraint Adherence**: Conforming to the DSA-3 curriculum rules ("*java.util.* forbidden inside the engine; students hand-build every algorithm*"), all fundamental collections (`CustomArrayList`, `CustomHashMap`, `CustomMinHeap`, `CustomLinkedList`, `CustomDisjointSetUnion`, `CustomQueue`, `CustomStack`) and algorithmic routines are constructed **from first principles without importing `java.util.*` inside the engine**.

---

## 🗺️ Syllabus Module Mapping (Modules 1 to 6)

| Syllabus Module | Academic Topic | Healthcare Scheduling Engine Role | Hand-Built Class Implementation |
| :--- | :--- | :--- | :--- |
| **Module 1** | System Architecture & Zero-Dependency Engine | Custom Dynamic Arrays, Hash Tables, Heaps, and Queues | [`CustomArrayList`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/ds/CustomArrayList.java), [`CustomHashMap`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/ds/CustomHashMap.java), [`CustomMinHeap`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/ds/CustomMinHeap.java), [`CustomDisjointSetUnion`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/ds/CustomDisjointSetUnion.java) |
| **Module 2** | String Algorithms | Emergency triage text extraction, keyword search, diagnostic record similarity | [`KMPMatcher`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/strings/KMPMatcher.java), [`ZFunctionMatcher`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/strings/ZFunctionMatcher.java), [`RabinKarpMatcher`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/strings/RabinKarpMatcher.java), [`AhoCorasickTriage`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/strings/AhoCorasickTriage.java), [`SuffixArrayKasai`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/strings/SuffixArrayKasai.java) |
| **Module 3** | Advanced Dynamic Programming | Typo-tolerant procedure search, pathway alignment, and OR turnaround TSP minimization | [`WagnerFischerEditDistance`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/dp/WagnerFischerEditDistance.java), [`SequenceAlignment`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/dp/SequenceAlignment.java), [`BitmaskTurnaroundDP`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/dp/BitmaskTurnaroundDP.java), [`IntervalDPScheduler`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/dp/IntervalDPScheduler.java) |
| **Module 4** | Network Flow | Multi-tier hospital capacity flow, min-cut bottleneck analysis, and surgeon-to-room bipartite matching | [`ResidualGraph`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/ResidualGraph.java), [`EdmondsKarpMaxFlow`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/EdmondsKarpMaxFlow.java), [`DinicMaxFlow`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/DinicMaxFlow.java), [`MinCutAnalyzer`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/MinCutAnalyzer.java), [`BipartiteMatcher`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/BipartiteMatcher.java), [`MinCostMaxFlow`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/flow/MinCostMaxFlow.java) |
| **Module 5** | NP-Completeness & Approximations | Parallel machine makespan (\(P \parallel C_{\max}\)) reduction, Graham's LPT 4/3-approx, Vertex Cover 2-approx | [`GrahamLPTScheduler`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/approx/GrahamLPTScheduler.java), [`ListScheduler`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/approx/ListScheduler.java), [`ExactBranchAndBoundScheduler`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/approx/ExactBranchAndBoundScheduler.java), [`VertexCover2Approximation`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/approx/VertexCover2Approximation.java) |
| **Module 6** | Randomized & Parallel Algorithms | Las Vegas priority sorting, universal collision-free hashing, stream reservoir sampling, Blelloch prefix scan | [`RandomizedQuickSort`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/randomparallel/RandomizedQuickSort.java), [`UniversalHashLookup`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/randomparallel/UniversalHashLookup.java), [`ReservoirSampler`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/randomparallel/ReservoirSampler.java), [`ParallelPrefixSum`](file:///D:/Java_2nd%20yr/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/randomparallel/ParallelPrefixSum.java), [`WorkSpanAnalyzer`](file:///D:/Java_2 implicit/DSA-03/Project_DSA-03/PRJ_02/src/com/hospital/algorithms/randomparallel/WorkSpanAnalyzer.java) |

---

## 📊 Asymptotic Complexity Reference Table

| Algorithm / Component | Time Complexity (Best / Avg / Worst) | Space Complexity | Clinical Operational Role |
| :--- | :--- | :--- | :--- |
| **`CustomMinHeap`** | \(O(1)\) / \(O(\log n)\) / \(O(\log n)\) | \(O(n)\) | Priority queue for emergency triage & machine load |
| **`CustomHashMap`** | \(O(1)\) / \(O(1)\) / \(O(n)\) | \(O(n)\) | Instant bed telemetry & patient record indexing |
| **`CustomDisjointSetUnion`** | \(O(\alpha(n))\) / \(O(\alpha(n))\) / \(O(\alpha(n))\) | \(O(n)\) | Bed ward partition & clustering |
| **KMP Matcher** | \(O(m)\) preproc, \(O(n)\) search | \(O(m)\) | Single clinical keyword search with LPS function |
| **Aho-Corasick Automaton** | \(O(\Sigma m)\) build, \(O(n + k)\) search | \(O(\Sigma m)\) | Simultaneous multi-keyword emergency triage |
| **Suffix Array & Kasai LCP** | \(O(n \log^2 n)\) SA, \(O(n)\) LCP | \(O(n)\) | Diagnostic record similarity & LCS extraction |
| **Wagner-Fischer (DP)** | \(O(m \cdot n)\) | \(O(m \cdot n)\) | Typo-tolerant procedure and medication search |
| **Bitmask Turnaround DP** | \(O(n^2 2^n)\) | \(O(n \cdot 2^n)\) | Exact optimal OR cleaning sequence (TSP) |
| **Edmonds-Karp Max-Flow** | \(O(V \cdot E^2)\) | \(O(V + E)\) | Reference max-flow with BFS shortest paths |
| **Dinic's Max-Flow** | \(O(V^2 \cdot E)\) | \(O(V + E)\) | Level graph blocking flow for hospital capacity |
| **Graham's LPT Approx** | \(O(n \log n)\) | \(O(n + m)\) | Multi-OR scheduling with \(4/3 - 1/(3m)\) bound |
| **Vertex Cover 2-Approx** | \(O(V + E)\) | \(O(V)\) | Maximal matching conflict graph resolution |
| **Randomized QuickSort** | \(O(n \log n)\) expected / \(O(n^2)\) worst | \(O(\log n)\) | Adversarial-proof triage queue sorting |
| **Reservoir Sampling** | \(O(1)\) per stream element | \(O(k)\) | Uniform random audit of emergency arrivals |
| **Blelloch Parallel Scan** | Work \(O(n)\), Span \(O(\log n)\) | \(O(n)\) | Cumulative 24-hour hospital workload telemetry |

---

## 🚀 How to Compile and Run (No .bat or Docker Required)

### 1. Prerequisites
* **Java Development Kit (JDK 11 or later)** installed and available on PATH (`javac` and `java`).

### 2. Compilation (Single Command)
Open a terminal in the project directory (`D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02`) and run:

```bash
# Windows PowerShell
javac -d bin (Get-ChildItem -Recurse -Filter *.java src,test | ForEach-Object FullName)

# Command Prompt / Bash
javac -d bin src/com/hospital/*.java src/com/hospital/ds/*.java src/com/hospital/model/*.java src/com/hospital/algorithms/*/*.java src/com/hospital/engine/*.java src/com/hospital/server/*.java src/com/hospital/server/handlers/*.java test/com/hospital/test/*.java
```

### 3. Run Automated Tests
```bash
java -cp bin com.hospital.test.FullHospitalTestSuite
```

### 4. Run Terminal Batch Pipeline
```bash
java -cp bin com.hospital.Main
```

### 5. Launch Full Web Dashboard & REST API
```bash
java -cp bin com.hospital.WebServerMain 8080
```
Then open your browser and navigate to:
👉 **`http://localhost:8080`**

---

## 🌐 Running From Another External Application

This project is built for direct programmatic integration with other applications in two ways:

1. **Via Standard Subprocess / CLI Execution**:
   ```bash
   java -cp "D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02\bin" com.hospital.Main
   ```
2. **Via HTTP REST API**:
   Start `WebServerMain` as a background process or service, then make JSON HTTP calls:
   * `POST /api/auth/login` — Login & obtain role token (`admin` / `admin123`).
   * `GET /api/schedule/run` — Retrieve optimized multi-OR schedule, Gantt slots, and metrics.
   * `GET /api/beds` — Retrieve real-time bed ward occupancy matrix.
   * `POST /api/beds/update` — Mutate bed status (`AVAILABLE`, `OCCUPIED`, `CLEANING`, `RESERVED`).
   * `GET /api/flow/analytics` — Obtain Dinic max-flow capacity and min-cut bottleneck list.
   * `POST /api/triage/evaluate` — Submit clinical text to Aho-Corasick triage automaton.
   * `POST /api/simulate/emergency` — Inject real-time Code Blue or trauma arrival.
   * `POST /api/simulate/overrun` — Apply procedure delay and ripple-shift remaining slots.
   * `GET /api/reports/analytics` — Export comprehensive clinical audit report.

---

## 🎨 Frontend Features
* **Dark & Light Mode Switcher** with instant toggle and `localStorage` state persistence.
* **Role Portal & Quick Login Chips** (Admin, Chief Medical Officer, Senior Scheduler, Triage Nurse).
* **Interactive Multi-OR Gantt Timeline** with color-coded triage priorities and turnaround buffers.
* **Hospital Bed Status Matrix** categorized by ICU, PACU, Surgical, and General wards.
* **Canvas Flow Network Visualizer** highlighting Min-Cut bottleneck tiers with live tooltips.
* **Aho-Corasick Emergency Triage Lab** with instant clinical note parsing and keyword tags.
* **NP-Hard Algorithm Comparison Benchmark** comparing Graham's LPT 4/3-Approx against Exact Branch-and-Bound.
