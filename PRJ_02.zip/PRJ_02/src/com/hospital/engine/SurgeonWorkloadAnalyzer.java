package com.hospital.engine;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.OperatingRoom;
import com.hospital.model.ScheduleSlot;
import com.hospital.model.Surgeon;

/**
 * Surgeon Workload, Fatigue, and Ergonomic Compliance Analyzer.
 * Computes individual physician utilization, cumulative shift minutes,
 * overtime breach risks, and certified procedure matching integrity.
 */
public class SurgeonWorkloadAnalyzer {

    public static class SurgeonMetric {
        public String surgeonId;
        public String name;
        public String specialty;
        public int totalAssignedMinutes;
        public int maxShiftMinutes;
        public int casesCount;
        public double utilizationPercentage;
        public double fatigueIndex; // 0.0 (Fresh) to 1.0 (Critical Fatigue)
        public boolean isOvertimeRisk;
        public CustomArrayList<String> assignedProcedures;

        public SurgeonMetric(String surgeonId, String name, String specialty, int maxShiftMinutes) {
            this.surgeonId = surgeonId;
            this.name = name;
            this.specialty = specialty;
            this.maxShiftMinutes = maxShiftMinutes;
            this.assignedProcedures = new CustomArrayList<>();
        }
    }

    public static class WorkloadReport {
        public CustomArrayList<SurgeonMetric> surgeonMetrics;
        public double averageSurgeonUtilization;
        public int totalSurgicalMinutes;
        public int surgeonsAtOvertimeRiskCount;

        public WorkloadReport() {
            this.surgeonMetrics = new CustomArrayList<>();
        }
    }

    public static WorkloadReport analyze(CustomArrayList<Surgeon> surgeons, CustomArrayList<OperatingRoom> rooms) {
        WorkloadReport report = new WorkloadReport();
        if (surgeons == null || surgeons.isEmpty()) return report;

        int totalMinutes = 0;
        int riskCount = 0;
        double sumUtil = 0;

        for (int sIdx = 0; sIdx < surgeons.size(); sIdx++) {
            Surgeon s = surgeons.get(sIdx);
            SurgeonMetric metric = new SurgeonMetric(s.getId(), s.getName(), s.getSpecialty(), s.getMaxDailyMinutes());

            int surgeonAssignedMinutes = 0;
            int caseCount = 0;

            if (rooms != null) {
                for (int r = 0; r < rooms.size(); r++) {
                    CustomArrayList<ScheduleSlot> slots = rooms.get(r).getScheduleSlots();
                    for (int k = 0; k < slots.size(); k++) {
                        ScheduleSlot slot = slots.get(k);
                        if (slot.getSurgeonName() != null &&
                                (slot.getSurgeonName().contains(s.getName()) || (slot.getSurgeonId() != null && slot.getSurgeonId().equals(s.getId())))) {
                            surgeonAssignedMinutes += slot.getDurationMinutes();
                            caseCount++;
                            metric.assignedProcedures.add(slot.getProcedureName() + " (" + slot.getDurationMinutes() + "m)");
                        }
                    }
                }
            }

            metric.totalAssignedMinutes = surgeonAssignedMinutes;
            metric.casesCount = caseCount;

            int capacity = Math.max(1, s.getMaxDailyMinutes());
            metric.utilizationPercentage = Math.min(100.0, ((double) surgeonAssignedMinutes / capacity) * 100.0);

            double hours = (double) surgeonAssignedMinutes / 60.0;
            if (hours <= 4.0) {
                metric.fatigueIndex = hours * 0.1;
            } else if (hours <= 8.0) {
                metric.fatigueIndex = 0.4 + (hours - 4.0) * 0.12;
            } else {
                metric.fatigueIndex = Math.min(1.0, 0.88 + (hours - 8.0) * 0.06);
            }

            metric.isOvertimeRisk = surgeonAssignedMinutes > (capacity * 0.85);
            if (metric.isOvertimeRisk) riskCount++;

            sumUtil += metric.utilizationPercentage;
            totalMinutes += surgeonAssignedMinutes;
            report.surgeonMetrics.add(metric);
        }

        report.totalSurgicalMinutes = totalMinutes;
        report.surgeonsAtOvertimeRiskCount = riskCount;
        report.averageSurgeonUtilization = (surgeons.size() > 0) ? (sumUtil / surgeons.size()) : 0.0;

        return report;
    }
}
