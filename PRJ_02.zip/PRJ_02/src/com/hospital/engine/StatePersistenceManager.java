package com.hospital.engine;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.*;
import com.hospital.server.SimpleJson;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Hospital State Persistence Manager.
 * Serializes and deserializes the entire hospital operational state to/from JSON files
 * using zero external libraries.
 */
public class StatePersistenceManager {

    private static final String DEFAULT_SNAPSHOT_PATH = "data/hospital_snapshot.json";

    public static String serializeStateToJson(HospitalState state) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"simulationMinute\": ").append(state.getCurrentSimulationMinute()).append(",\n");

        // Patients
        sb.append("  \"patients\": [\n");
        CustomArrayList<Patient> patients = state.getAllPatients();
        for (int i = 0; i < patients.size(); i++) {
            Patient p = patients.get(i);
            sb.append("    {\n");
            sb.append("      \"id\": \"").append(SimpleJson.escape(p.getId())).append("\",\n");
            sb.append("      \"name\": \"").append(SimpleJson.escape(p.getName())).append("\",\n");
            sb.append("      \"age\": ").append(p.getAge()).append(",\n");
            sb.append("      \"gender\": \"").append(SimpleJson.escape(p.getGender())).append("\",\n");
            sb.append("      \"triageLevel\": \"").append(p.getTriageLevel().name()).append("\",\n");
            sb.append("      \"diagnosis\": \"").append(SimpleJson.escape(p.getDiagnosis())).append("\",\n");
            sb.append("      \"requiredProcedure\": \"").append(SimpleJson.escape(p.getRequiredProcedure())).append("\",\n");
            sb.append("      \"duration\": ").append(p.getEstimatedDurationMinutes()).append(",\n");
            sb.append("      \"postOpWard\": \"").append(p.getPostOpWardRequirement().name()).append("\",\n");
            sb.append("      \"postOpStayHours\": ").append(p.getPostOpStayHours()).append(",\n");
            sb.append("      \"deadlineMinutes\": ").append(p.getDeadlineMinutes()).append(",\n");
            sb.append("      \"arrivalTimeMinutes\": ").append(p.getArrivalTimeMinutes()).append(",\n");
            sb.append("      \"assignedBedId\": \"").append(SimpleJson.escape(p.getAssignedBedId() != null ? p.getAssignedBedId() : "")).append("\"\n");
            sb.append("    }").append(i < patients.size() - 1 ? ",\n" : "\n");
        }
        sb.append("  ],\n");

        // Operating Rooms
        sb.append("  \"operatingRooms\": [\n");
        CustomArrayList<OperatingRoom> rooms = state.getAllOperatingRooms();
        for (int i = 0; i < rooms.size(); i++) {
            OperatingRoom r = rooms.get(i);
            sb.append("    {\n");
            sb.append("      \"id\": \"").append(SimpleJson.escape(r.getId())).append("\",\n");
            sb.append("      \"name\": \"").append(SimpleJson.escape(r.getName())).append("\",\n");
            sb.append("      \"isEmergencyCapable\": ").append(r.isEmergencyCapable()).append("\n");
            sb.append("    }").append(i < rooms.size() - 1 ? ",\n" : "\n");
        }
        sb.append("  ],\n");

        // Beds
        sb.append("  \"beds\": [\n");
        CustomArrayList<Bed> beds = state.getAllBeds();
        for (int i = 0; i < beds.size(); i++) {
            Bed b = beds.get(i);
            sb.append("    {\n");
            sb.append("      \"id\": \"").append(SimpleJson.escape(b.getId())).append("\",\n");
            sb.append("      \"roomNumber\": \"").append(SimpleJson.escape(b.getRoomNumber())).append("\",\n");
            sb.append("      \"wardType\": \"").append(b.getWardType().name()).append("\",\n");
            sb.append("      \"status\": \"").append(b.getStatus().name()).append("\",\n");
            sb.append("      \"currentPatientId\": \"").append(SimpleJson.escape(b.getCurrentPatientId() != null ? b.getCurrentPatientId() : "")).append("\"\n");
            sb.append("    }").append(i < beds.size() - 1 ? ",\n" : "\n");
        }
        sb.append("  ]\n");

        sb.append("}");
        return sb.toString();
    }

    public static boolean saveSnapshotToFile(HospitalState state, String filePath) {
        if (filePath == null || filePath.isEmpty()) filePath = DEFAULT_SNAPSHOT_PATH;
        try {
            Path path = Paths.get(filePath);
            if (path.getParent() != null) {
                Files.createDirectories(path.getParent());
            }
            String json = serializeStateToJson(state);
            Files.write(path, json.getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (Exception e) {
            System.err.println("Failed to save snapshot: " + e.getMessage());
            return false;
        }
    }

    public static HospitalState resetState() {
        return HospitalDataLoader.loadInitialState();
    }
}
