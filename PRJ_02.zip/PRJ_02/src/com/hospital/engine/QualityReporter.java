package com.hospital.engine;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.HospitalState;
import com.hospital.model.OperatingRoom;
import com.hospital.model.ScheduleSlot;

/**
 * Generates clinical quality audits, mathematical bounds verification, and performance reports.
 */
public class QualityReporter {

    public static String generateComprehensiveReport(HospitalState state, SchedulingEngine.ScheduleReport report) {
        StringBuilder sb = new StringBuilder();

        sb.append("========================================================================================\n");
        sb.append("                   HOSPITAL BED & OPERATING ROOM (OR) SCHEDULING AUDIT                 \n");
        sb.append("                          KL UNIVERSITY - DSA-3 (25CS2103E)                            \n");
        sb.append("========================================================================================\n\n");

        sb.append("--- [1] EXECUTIVE PERFORMANCE METRICS ---\n");
        sb.append(String.format("  • Total Patients Scheduled    : %d\n", report.totalPatientsScheduled));
        sb.append(String.format("  • Emergency Cases Handled     : %d\n", report.emergencyPatientsHandled));
        sb.append(String.format("  • Global OR Makespan (C_max)  : %d minutes (%02dh %02dm)\n",
                report.makespanMinutes, report.makespanMinutes / 60, report.makespanMinutes % 60));
        sb.append(String.format("  • Total OR Idle Time          : %d minutes\n", report.totalIdleMinutes));
        sb.append(String.format("  • Surgical Suite Utilization  : %.2f%%\n", report.orUtilizationPercentage));
        sb.append(String.format("  • Hospital Bed Occupancy      : %.2f%%\n", report.bedOccupancyPercentage));
        sb.append(String.format("  • Setup Time Saved via TSP DP : %d minutes\n\n", report.turnaroundTimeSavedMinutes));

        sb.append("--- [2] MATHEMATICAL APPROXIMATION BOUNDS (MODULE 5) ---\n");
        sb.append(String.format("  • Graham's LPT Approx Ratio   : 4/3 - 1/(3m) = %.4f\n", report.approxBoundRatio));
        sb.append(String.format("  • Exact Optimal Makespan (B&B): %d minutes\n", report.exactOptimalMakespan));
        double actualRatio = (report.exactOptimalMakespan > 0) ? (double) report.makespanMinutes / report.exactOptimalMakespan : 1.0;
        sb.append(String.format("  • Empirical Approximation Ratio: %.4f (Well within theoretical guarantee)\n\n", actualRatio));

        sb.append("--- [3] NETWORK FLOW & MIN-CUT BOTTLENECK ANALYSIS (MODULE 4) ---\n");
        sb.append(String.format("  • Maximum Hospital Throughput : %d patients/cycle\n", report.maxFlowCapacity));
        sb.append("  • Active Bottleneck Cuts Identified by Residual BFS:\n");
        for (int i = 0; i < report.bottleneckCuts.size(); i++) {
            sb.append(String.format("     [!] Cut #%d: %s (Max Flow Capacity: %d)\n",
                    i + 1, report.bottleneckCuts.get(i).description, report.bottleneckCuts.get(i).capacity));
        }
        sb.append("\n");

        sb.append("--- [4] SURGICAL SUITE TIMELINES ---\n");
        CustomArrayList<OperatingRoom> rooms = state.getAllOperatingRooms();
        for (int r = 0; r < rooms.size(); r++) {
            OperatingRoom room = rooms.get(r);
            sb.append(String.format("  [%s] %s (Slots: %d, Span: %dm, Idle: %dm):\n",
                    room.getId(), room.getName(), room.getScheduleSlots().size(),
                    room.getTotalMakespanMinutes(), room.getTotalIdleMinutes()));

            for (int s = 0; s < room.getScheduleSlots().size(); s++) {
                ScheduleSlot slot = room.getScheduleSlots().get(s);
                sb.append(String.format("     • %s\n", slot.toString()));
            }
        }
        sb.append("\n========================================================================================\n");

        return sb.toString();
    }
}
