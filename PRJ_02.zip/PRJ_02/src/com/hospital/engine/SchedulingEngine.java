package com.hospital.engine;

import com.hospital.algorithms.approx.ExactBranchAndBoundScheduler;
import com.hospital.algorithms.approx.GrahamLPTScheduler;
import com.hospital.algorithms.dp.BitmaskTurnaroundDP;
import com.hospital.algorithms.flow.BipartiteMatcher;
import com.hospital.algorithms.flow.DinicMaxFlow;
import com.hospital.algorithms.flow.MinCutAnalyzer;
import com.hospital.algorithms.flow.ResidualGraph;
import com.hospital.algorithms.randomparallel.ParallelPrefixSum;
import com.hospital.algorithms.randomparallel.RandomizedQuickSort;
import com.hospital.ds.CustomArrayList;
import com.hospital.ds.Pair;
import com.hospital.model.*;

/**
 * Master Scheduling Engine integrating DSA Modules 1 through 6
 * to solve full hospital resource, surgical suite, and bed allocation optimization.
 */
public class SchedulingEngine {

    public static class ScheduleReport {
        public int makespanMinutes;
        public int totalIdleMinutes;
        public double orUtilizationPercentage;
        public double bedOccupancyPercentage;
        public double approxBoundRatio;
        public int exactOptimalMakespan;
        public int maxFlowCapacity;
        public CustomArrayList<MinCutAnalyzer.CutEdge> bottleneckCuts;
        public CustomArrayList<ScheduleSlot> scheduledSlots;
        public int totalPatientsScheduled;
        public int emergencyPatientsHandled;
        public int turnaroundTimeSavedMinutes;

        public ScheduleReport() {
            this.bottleneckCuts = new CustomArrayList<>();
            this.scheduledSlots = new CustomArrayList<>();
        }
    }

    public static ScheduleReport runMasterSchedule(HospitalState state) {
        ScheduleReport report = new ScheduleReport();

        CustomArrayList<Patient> allPatients = state.getAllPatients();
        CustomArrayList<OperatingRoom> allRooms = state.getAllOperatingRooms();
        CustomArrayList<Surgeon> allSurgeons = state.getAllSurgeons();
        CustomArrayList<Bed> allBeds = state.getAllBeds();

        // 1. Sort patients using Las Vegas Randomized QuickSort based on clinical urgency
        Patient[] patientArray = new Patient[allPatients.size()];
        for (int i = 0; i < allPatients.size(); i++) patientArray[i] = allPatients.get(i);
        RandomizedQuickSort.sortPatients(patientArray);

        CustomArrayList<Patient> sortedPatients = new CustomArrayList<>();
        for (Patient p : patientArray) sortedPatients.add(p);

        // 2. Multi-OR Scheduling using Graham's LPT 4/3-Approximation
        GrahamLPTScheduler.ScheduleOutput lptOut = GrahamLPTScheduler.scheduleLPT(
                sortedPatients, allRooms, allSurgeons, state.getCurrentSimulationMinute()
        );

        report.makespanMinutes = lptOut.makespan;
        report.totalIdleMinutes = lptOut.totalIdleMinutes;
        report.approxBoundRatio = lptOut.approximationBoundRatio;
        report.scheduledSlots = lptOut.assignedSlots;
        report.totalPatientsScheduled = lptOut.assignedSlots.size();

        // Count emergency patients
        int emergencies = 0;
        for (int i = 0; i < sortedPatients.size(); i++) {
            if (sortedPatients.get(i).getTriageLevel().getLevel() <= 2) emergencies++;
        }
        report.emergencyPatientsHandled = emergencies;

        // 3. Exact Branch-and-Bound comparison for first subset of patients
        CustomArrayList<Patient> benchmarkSubset = new CustomArrayList<>();
        for (int i = 0; i < Math.min(8, sortedPatients.size()); i++) {
            benchmarkSubset.add(sortedPatients.get(i));
        }
        report.exactOptimalMakespan = ExactBranchAndBoundScheduler.computeOptimalMakespan(benchmarkSubset, allRooms.size());

        // 4. Bitmask TSP Turnaround Optimization inside each Operating Room
        int turnaroundSaved = 0;
        for (int r = 0; r < allRooms.size(); r++) {
            OperatingRoom room = allRooms.get(r);
            int slotCount = room.getScheduleSlots().size();
            if (slotCount >= 2 && slotCount <= 8) {
                int[][] turnaroundMatrix = new int[slotCount][slotCount];
                for (int i = 0; i < slotCount; i++) {
                    for (int j = 0; j < slotCount; j++) {
                        if (i == j) turnaroundMatrix[i][j] = 0;
                        else {
                            ScheduleSlot s1 = room.getScheduleSlots().get(i);
                            ScheduleSlot s2 = room.getScheduleSlots().get(j);
                            boolean sameProc = s1.getProcedureName().equals(s2.getProcedureName());
                            boolean emergency = s1.isEmergency() || s2.isEmergency();
                            turnaroundMatrix[i][j] = sameProc ? 10 : (emergency ? 20 : 35);
                        }
                    }
                }
                BitmaskTurnaroundDP.TSPResult tsp = BitmaskTurnaroundDP.solveOptimalSequence(turnaroundMatrix);
                int baseline = (slotCount - 1) * 35;
                turnaroundSaved += Math.max(0, baseline - tsp.minCost);
            }
        }
        report.turnaroundTimeSavedMinutes = turnaroundSaved;

        // 5. Assign Post-Op Beds across Specialized Wards
        int occupiedBeds = 0;
        for (int i = 0; i < sortedPatients.size(); i++) {
            Patient p = sortedPatients.get(i);
            WardType requiredWard = p.getPostOpWardRequirement();
            Bed assignedBed = findAvailableBed(allBeds, requiredWard, state.getCurrentSimulationMinute());
            if (assignedBed != null) {
                assignedBed.assignPatient(p.getId(), p.getPostOpStayHours() * 60, state.getCurrentSimulationMinute());
                p.setAssignedBedId(assignedBed.getId());
                occupiedBeds++;
            }
        }

        report.bedOccupancyPercentage = (allBeds.size() > 0) ? ((double) occupiedBeds / allBeds.size()) * 100.0 : 0.0;

        // 6. Compute OR Utilization %
        int totalOpTime = 0;
        for (int i = 0; i < lptOut.assignedSlots.size(); i++) {
            totalOpTime += lptOut.assignedSlots.get(i).getDurationMinutes();
        }
        int totalAvailableORMinutes = Math.max(1, allRooms.size() * report.makespanMinutes);
        report.orUtilizationPercentage = Math.min(100.0, ((double) totalOpTime / totalAvailableORMinutes) * 100.0);

        // 7. Network Flow & Min-Cut Capacity Bottleneck Discovery
        // Structure: 0:Source -> 1:Triage -> 2..4:ORs -> 5:PACU -> 6:ICU -> 7:General -> 8:Sink
        ResidualGraph capGraph = new ResidualGraph(9);
        String[] labels = new String[]{
                "Source [Inflow]",
                "ER Triage Intake",
                "OR Suite 1-2 (Cardiac/Neuro)",
                "OR Suite 3-4 (Ortho/General)",
                "OR Suite 5 (Ambulatory)",
                "PACU Recovery Beds",
                "ICU Intensive Beds",
                "General Surgical Wards",
                "Sink [Discharge/Admit]"
        };

        capGraph.addEdge(0, 1, 50); // Inbound intake capacity
        capGraph.addEdge(1, 2, 12); // Triage to major ORs
        capGraph.addEdge(1, 3, 16); // Triage to general ORs
        capGraph.addEdge(1, 4, 10); // Triage to day ORs
        capGraph.addEdge(2, 6, 8);  // Major OR to ICU (bottleneck point: 8 beds)
        capGraph.addEdge(2, 5, 6);  // Major OR to PACU
        capGraph.addEdge(3, 5, 10); // General OR to PACU
        capGraph.addEdge(3, 7, 8);  // General OR to Surgical
        capGraph.addEdge(4, 7, 10); // Day OR to General
        capGraph.addEdge(5, 7, 10); // PACU to General
        capGraph.addEdge(6, 8, 8);  // ICU to Sink
        capGraph.addEdge(7, 8, 20); // General to Sink

        MinCutAnalyzer.MinCutResult minCut = MinCutAnalyzer.findMinCut(capGraph, 0, 8, labels);
        report.maxFlowCapacity = minCut.minCutCapacity;
        report.bottleneckCuts = minCut.bottleneckEdges;

        return report;
    }

    private static Bed findAvailableBed(CustomArrayList<Bed> beds, WardType requiredWard, int currentMinute) {
        // First try matching exact ward
        for (int i = 0; i < beds.size(); i++) {
            Bed b = beds.get(i);
            if (b.getWardType() == requiredWard && b.getStatus() == BedStatus.AVAILABLE) {
                return b;
            }
        }
        // Fallback: Surgical ward for general, or General for non-critical
        for (int i = 0; i < beds.size(); i++) {
            Bed b = beds.get(i);
            if (b.getStatus() == BedStatus.AVAILABLE) {
                if (requiredWard == WardType.GENERAL || requiredWard == WardType.PACU) {
                    return b;
                }
            }
        }
        return null;
    }
}
