package com.hospital.engine;

import com.hospital.algorithms.strings.AhoCorasickTriage;
import com.hospital.model.HospitalState;
import com.hospital.model.Patient;
import com.hospital.model.TriageLevel;
import com.hospital.model.WardType;
import com.hospital.server.SimpleJson;

/**
 * Patient Admission & Ingestion Manager.
 * Parses clinical registration payload, executes Aho-Corasick automatic triage grading,
 * assigns procedural requirements, and registers the patient into the live HospitalState.
 */
public class PatientAdmissionManager {

    private static final AhoCorasickTriage triageEngine = new AhoCorasickTriage();

    public static Patient admitNewPatient(HospitalState state, String jsonPayload) {
        if (jsonPayload == null || jsonPayload.trim().isEmpty()) {
            throw new IllegalArgumentException("Payload cannot be empty");
        }

        String name = SimpleJson.extractString(jsonPayload, "name");
        if (name == null || name.isEmpty()) name = "Emergency Inbound " + (state.getAllPatients().size() + 1);

        int age = SimpleJson.extractInt(jsonPayload, "age", 45);
        String gender = SimpleJson.extractString(jsonPayload, "gender");
        if (gender == null) gender = "Unspecified";

        String report = SimpleJson.extractString(jsonPayload, "clinicalReport");
        if (report == null) report = "Clinical admission note pending.";

        String procedure = SimpleJson.extractString(jsonPayload, "procedure");
        if (procedure == null || procedure.isEmpty()) {
            procedure = inferDefaultProcedure(report);
        }

        int duration = SimpleJson.extractInt(jsonPayload, "duration", 90);
        int postOpStayHours = SimpleJson.extractInt(jsonPayload, "postOpStayHours", 24);

        // Auto-detect triage level via Aho-Corasick automaton if not specified
        String explicitTriageStr = SimpleJson.extractString(jsonPayload, "triageLevel");
        TriageLevel level;
        if (explicitTriageStr != null) {
            try {
                level = TriageLevel.valueOf(explicitTriageStr);
            } catch (Exception e) {
                level = triageEngine.inferOverallTriage(report);
            }
        } else {
            level = triageEngine.inferOverallTriage(report);
        }

        WardType wardType = inferWardType(level, procedure);
        int currentMinute = state.getCurrentSimulationMinute();
        int deadlineMinutes = currentMinute + calculateDeadlineMinutes(level);

        String patientId = "PT-" + (100 + state.getAllPatients().size() + 1);
        Patient patient = new Patient(
                patientId,
                name,
                age,
                gender,
                level,
                report,
                procedure,
                duration,
                wardType,
                postOpStayHours,
                deadlineMinutes,
                currentMinute
        );

        state.addPatient(patient);
        return patient;
    }

    private static String inferDefaultProcedure(String note) {
        String lower = note.toLowerCase();
        if (lower.contains("cardiac") || lower.contains("bypass") || lower.contains("chest")) {
            return "Coronary Artery Bypass (CABG)";
        } else if (lower.contains("head") || lower.contains("craniotomy") || lower.contains("brain") || lower.contains("hematoma")) {
            return "Emergency Craniotomy";
        } else if (lower.contains("hip") || lower.contains("fracture") || lower.contains("ortho")) {
            return "Total Hip Replacement";
        } else if (lower.contains("appendic") || lower.contains("abdominal")) {
            return "Acute Appendectomy";
        } else if (lower.contains("cataract") || lower.contains("eye")) {
            return "Cataract Phacoemulsification";
        }
        return "Emergency Trauma Laparotomy";
    }

    private static WardType inferWardType(TriageLevel level, String procedure) {
        if (level == TriageLevel.LEVEL_1_EMERGENCY) return WardType.ICU;
        if (procedure.contains("Bypass") || procedure.contains("Craniotomy") || procedure.contains("Aneurysm")) return WardType.ICU;
        if (procedure.contains("Appendectomy") || procedure.contains("Cholecystectomy")) return WardType.PACU;
        if (procedure.contains("Hip") || procedure.contains("Spinal") || procedure.contains("Fixation")) return WardType.SURGICAL;
        return WardType.GENERAL;
    }

    private static int calculateDeadlineMinutes(TriageLevel level) {
        switch (level) {
            case LEVEL_1_EMERGENCY: return 60;   // 1 hour
            case LEVEL_2_URGENT: return 180;     // 3 hours
            case LEVEL_3_SEMI_URGENT: return 480;// 8 hours
            case LEVEL_4_ELECTIVE:
            default: return 1440;                // 24 hours
        }
    }
}
