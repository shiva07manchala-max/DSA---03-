package com.hospital.engine;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.*;

/**
 * Real-Time Telemetry & Simulation Clock Engine.
 * Manages simulation time advancement, automatic bed sanitization expiry,
 * surgical progress transitions, and ward recovery step-downs.
 */
public class TelemetryClockEngine {

    public static class ClockAdvanceReport {
        public int previousMinute;
        public int newMinute;
        public int minutesAdvanced;
        public int bedsCleanedCount;
        public int patientsRecoveredCount;
        public int surgeriesCompletedCount;

        public ClockAdvanceReport(int previousMinute, int newMinute, int minutesAdvanced) {
            this.previousMinute = previousMinute;
            this.newMinute = newMinute;
            this.minutesAdvanced = minutesAdvanced;
        }
    }

    public static ClockAdvanceReport advanceTime(HospitalState state, int minutesToAdvance) {
        if (minutesToAdvance <= 0) minutesToAdvance = 30;

        int oldMinute = state.getCurrentSimulationMinute();
        int newMinute = oldMinute + minutesToAdvance;
        state.setCurrentSimulationMinute(newMinute);

        ClockAdvanceReport report = new ClockAdvanceReport(oldMinute, newMinute, minutesToAdvance);

        // 1. Process Bed Sanitization Cycle
        CustomArrayList<Bed> beds = state.getAllBeds();
        int cleaned = 0;
        int recovered = 0;

        for (int i = 0; i < beds.size(); i++) {
            Bed b = beds.get(i);
            if (b.getStatus() == BedStatus.CLEANING) {
                b.setStatus(BedStatus.AVAILABLE);
                cleaned++;
            } else if (b.getStatus() == BedStatus.OCCUPIED) {
                if (b.getOccupiedUntilMinutes() > 0 && newMinute >= b.getOccupiedUntilMinutes()) {
                    b.release();
                    recovered++;
                }
            }
        }

        report.bedsCleanedCount = cleaned;
        report.patientsRecoveredCount = recovered;

        // 2. Process Surgical Slots
        int completedSurgeries = 0;
        CustomArrayList<OperatingRoom> rooms = state.getAllOperatingRooms();
        for (int r = 0; r < rooms.size(); r++) {
            CustomArrayList<ScheduleSlot> slots = rooms.get(r).getScheduleSlots();
            for (int k = 0; k < slots.size(); k++) {
                ScheduleSlot slot = slots.get(k);
                if (newMinute >= slot.getEndMinute()) {
                    completedSurgeries++;
                }
            }
        }
        report.surgeriesCompletedCount = completedSurgeries;

        return report;
    }
}
