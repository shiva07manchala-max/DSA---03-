package com.hospital.engine;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.*;

/**
 * Seeds comprehensive initial dataset for hospital operations, beds, surgical suites, and patients.
 */
public class HospitalDataLoader {

    public static HospitalState loadInitialState() {
        HospitalState state = new HospitalState();

        // 1. Register Surgery Catalog
        state.addSurgeryCatalog(new Surgery("SURG-01", "Coronary Artery Bypass (CABG)", "Cardiothoracic", 240, 30, WardType.ICU));
        state.addSurgeryCatalog(new Surgery("SURG-02", "Emergency Craniotomy", "Neurosurgery", 180, 25, WardType.ICU));
        state.addSurgeryCatalog(new Surgery("SURG-03", "Total Hip Replacement", "Orthopedics", 120, 20, WardType.SURGICAL));
        state.addSurgeryCatalog(new Surgery("SURG-04", "Laparoscopic Cholecystectomy", "General Surgery", 75, 15, WardType.PACU));
        state.addSurgeryCatalog(new Surgery("SURG-05", "Acute Appendectomy", "General Surgery", 60, 15, WardType.PACU));
        state.addSurgeryCatalog(new Surgery("SURG-06", "Aortic Aneurysm Repair", "Cardiothoracic", 210, 30, WardType.ICU));
        state.addSurgeryCatalog(new Surgery("SURG-07", "Complex Spinal Fusion", "Neurosurgery", 195, 25, WardType.SURGICAL));
        state.addSurgeryCatalog(new Surgery("SURG-08", "Open Reduction Internal Fixation", "Orthopedics", 105, 20, WardType.SURGICAL));
        state.addSurgeryCatalog(new Surgery("SURG-09", "Emergency Trauma Laparotomy", "Trauma Surgery", 150, 25, WardType.ICU));
        state.addSurgeryCatalog(new Surgery("SURG-10", "Cataract Phacoemulsification", "Ophthalmology", 45, 10, WardType.GENERAL));

        // 2. Register Operating Rooms (Suites)
        OperatingRoom or1 = new OperatingRoom("OR-01", "Cardiac & Thoracic Suite", true);
        or1.addSupportedSpecialty("Cardiothoracic");
        or1.addSupportedSpecialty("General Surgery");
        or1.addSupportedSpecialty("Trauma Surgery");
        state.addOperatingRoom(or1);

        OperatingRoom or2 = new OperatingRoom("OR-02", "Neuro & Spine Suite", true);
        or2.addSupportedSpecialty("Neurosurgery");
        or2.addSupportedSpecialty("Orthopedics");
        or2.addSupportedSpecialty("Trauma Surgery");
        state.addOperatingRoom(or2);

        OperatingRoom or3 = new OperatingRoom("OR-03", "Orthopedic & Trauma Suite", true);
        or3.addSupportedSpecialty("Orthopedics");
        or3.addSupportedSpecialty("General Surgery");
        or3.addSupportedSpecialty("Trauma Surgery");
        state.addOperatingRoom(or3);

        OperatingRoom or4 = new OperatingRoom("OR-04", "General & Laparoscopy Suite", false);
        or4.addSupportedSpecialty("General Surgery");
        or4.addSupportedSpecialty("Ophthalmology");
        state.addOperatingRoom(or4);

        OperatingRoom or5 = new OperatingRoom("OR-05", "Ambulatory & Day Suite", false);
        or5.addSupportedSpecialty("Ophthalmology");
        or5.addSupportedSpecialty("General Surgery");
        state.addOperatingRoom(or5);

        // 3. Register Surgeons
        Surgeon s1 = new Surgeon("DOC-01", "Devi Shetty", "Cardiothoracic", 480, 1080, 600);
        s1.addCertifiedProcedure("Coronary Artery Bypass (CABG)");
        s1.addCertifiedProcedure("Aortic Aneurysm Repair");
        state.addSurgeon(s1);

        Surgeon s2 = new Surgeon("DOC-02", "Anitha Chekuri", "Neurosurgery", 480, 1080, 600);
        s2.addCertifiedProcedure("Emergency Craniotomy");
        s2.addCertifiedProcedure("Complex Spinal Fusion");
        state.addSurgeon(s2);

        Surgeon s3 = new Surgeon("DOC-03", "K. Chandusha", "Orthopedics", 480, 1080, 600);
        s3.addCertifiedProcedure("Total Hip Replacement");
        s3.addCertifiedProcedure("Open Reduction Internal Fixation");
        state.addSurgeon(s3);

        Surgeon s4 = new Surgeon("DOC-04", "Bhavan Kumar", "General Surgery", 480, 1080, 600);
        s4.addCertifiedProcedure("Laparoscopic Cholecystectomy");
        s4.addCertifiedProcedure("Acute Appendectomy");
        s4.addCertifiedProcedure("Emergency Trauma Laparotomy");
        state.addSurgeon(s4);

        Surgeon s5 = new Surgeon("DOC-05", "Shiva Reddy", "Trauma Surgery", 480, 1080, 600);
        s5.addCertifiedProcedure("Emergency Trauma Laparotomy");
        s5.addCertifiedProcedure("Acute Appendectomy");
        s5.addCertifiedProcedure("Emergency Craniotomy");
        state.addSurgeon(s5);

        // 4. Register Hospital Beds Across Specialized Wards
        // ICU Beds
        for (int i = 1; i <= 8; i++) {
            state.addBed(new Bed("BED-ICU-" + String.format("%02d", i), "ICU-Unit-" + i, WardType.ICU));
        }
        // PACU Beds (Post-Anesthesia)
        for (int i = 1; i <= 10; i++) {
            state.addBed(new Bed("BED-PACU-" + String.format("%02d", i), "PACU-Bay-" + i, WardType.PACU));
        }
        // Surgical Inpatient Beds
        for (int i = 1; i <= 16; i++) {
            state.addBed(new Bed("BED-SURG-" + String.format("%02d", i), "SURG-Wing-" + i, WardType.SURGICAL));
        }
        // General Wards
        for (int i = 1; i <= 20; i++) {
            state.addBed(new Bed("BED-GEN-" + String.format("%02d", i), "GEN-Ward-" + i, WardType.GENERAL));
        }

        // 5. Register Initial Inbound Patients & Waitlist
        state.addPatient(new Patient("PT-101", "Rajesh Sharma", 58, "Male", TriageLevel.LEVEL_1_EMERGENCY,
                "Triple vessel coronary disease with angina", "Coronary Artery Bypass (CABG)", 240, WardType.ICU, 48, 120, 480));

        state.addPatient(new Patient("PT-102", "Priya Nair", 34, "Female", TriageLevel.LEVEL_1_EMERGENCY,
                "Acute traumatic intracranial hematoma", "Emergency Craniotomy", 180, WardType.ICU, 36, 60, 485));

        state.addPatient(new Patient("PT-103", "Vikram Patel", 65, "Male", TriageLevel.LEVEL_4_ELECTIVE,
                "End-stage degenerative osteoarthritis", "Total Hip Replacement", 120, WardType.SURGICAL, 24, 720, 490));

        state.addPatient(new Patient("PT-104", "Sunita Verma", 42, "Female", TriageLevel.LEVEL_2_URGENT,
                "Acute gangrenous appendicitis with fever", "Acute Appendectomy", 60, WardType.PACU, 12, 180, 500));

        state.addPatient(new Patient("PT-105", "Amitabh Sen", 62, "Male", TriageLevel.LEVEL_2_URGENT,
                "Symptomatic thoracic aortic aneurysm", "Aortic Aneurysm Repair", 210, WardType.ICU, 48, 240, 505));

        state.addPatient(new Patient("PT-106", "Kavita Rao", 29, "Female", TriageLevel.LEVEL_3_SEMI_URGENT,
                "Symptomatic cholelithiasis", "Laparoscopic Cholecystectomy", 75, WardType.PACU, 12, 480, 510));

        state.addPatient(new Patient("PT-107", "Rohan Gupta", 45, "Male", TriageLevel.LEVEL_3_SEMI_URGENT,
                "L4-L5 disc herniation with radiculopathy", "Complex Spinal Fusion", 195, WardType.SURGICAL, 36, 600, 515));

        state.addPatient(new Patient("PT-108", "Deepa Mehta", 38, "Female", TriageLevel.LEVEL_2_URGENT,
                "Displaced bimalleolar ankle fracture", "Open Reduction Internal Fixation", 105, WardType.SURGICAL, 18, 300, 520));

        state.addPatient(new Patient("PT-109", "Manoj Tiwari", 51, "Male", TriageLevel.LEVEL_1_EMERGENCY,
                "Blunt abdominal trauma with intra-abdominal fluid", "Emergency Trauma Laparotomy", 150, WardType.ICU, 36, 90, 525));

        state.addPatient(new Patient("PT-110", "Ananya Das", 71, "Female", TriageLevel.LEVEL_4_ELECTIVE,
                "Senile mature nuclear cataract", "Cataract Phacoemulsification", 45, WardType.GENERAL, 4, 960, 530));

        return state;
    }
}
