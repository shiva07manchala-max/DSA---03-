package com.hospital.engine;

import com.hospital.algorithms.strings.AhoCorasickTriage;
import com.hospital.ds.CustomArrayList;
import com.hospital.model.*;

/**
 * Real-Time Hospital Event Simulation Manager.
 * Handles Code Blue / Trauma emergencies, procedure overruns, and dynamic schedule re-optimization.
 */
public class SimulationManager {
    private final HospitalState state;
    private final AhoCorasickTriage triageEngine;
    private int patientCounter = 200;

    public SimulationManager(HospitalState state) {
        this.state = state;
        this.triageEngine = new AhoCorasickTriage();
    }

    public Patient injectEmergencyArrival(String name, int age, String gender, String clinicalReport, String defaultProcedure, int durationMinutes) {
        TriageLevel triage = triageEngine.inferOverallTriage(clinicalReport);
        String patientId = "PT-EMERG-" + (++patientCounter);

        WardType ward = (triage == TriageLevel.LEVEL_1_EMERGENCY) ? WardType.ICU : WardType.PACU;

        Patient emergencyPatient = new Patient(
                patientId,
                name,
                age,
                gender,
                triage,
                clinicalReport,
                defaultProcedure,
                durationMinutes,
                ward,
                (triage == TriageLevel.LEVEL_1_EMERGENCY) ? 48 : 24,
                (triage == TriageLevel.LEVEL_1_EMERGENCY) ? 30 : 90, // Deadline in minutes
                state.getCurrentSimulationMinute()
        );

        state.addPatient(emergencyPatient);
        return emergencyPatient;
    }

    public boolean applyProcedureOverrun(String operatingRoomId, String slotId, int extraMinutes) {
        OperatingRoom room = state.getOperatingRoom(operatingRoomId);
        if (room == null) return false;

        CustomArrayList<ScheduleSlot> slots = room.getScheduleSlots();
        boolean found = false;

        for (int i = 0; i < slots.size(); i++) {
            ScheduleSlot slot = slots.get(i);
            if (slot.getSlotId().equals(slotId) || found) {
                if (!found) {
                    // Extend this slot
                    slot.setEndMinute(slot.getEndMinute() + extraMinutes);
                    found = true;
                } else {
                    // Ripple shift subsequent slots in the same room
                    slot.setStartMinute(slot.getStartMinute() + extraMinutes);
                    slot.setEndMinute(slot.getEndMinute() + extraMinutes);
                }
            }
        }

        if (found) {
            room.setTotalMakespanMinutes(room.getTotalMakespanMinutes() + extraMinutes);
        }
        return found;
    }

    public boolean cancelProcedure(String operatingRoomId, String slotId) {
        OperatingRoom room = state.getOperatingRoom(operatingRoomId);
        if (room == null) return false;

        CustomArrayList<ScheduleSlot> slots = room.getScheduleSlots();
        for (int i = 0; i < slots.size(); i++) {
            if (slots.get(i).getSlotId().equals(slotId)) {
                ScheduleSlot removed = slots.remove(i);
                Patient p = state.getPatient(removed.getPatientId());
                if (p != null) {
                    p.setAssignedOrId(null);
                    p.setScheduledStartTime(-1);
                }
                return true;
            }
        }
        return false;
    }

    public boolean setBedStatus(String bedId, BedStatus newStatus) {
        Bed bed = state.getBed(bedId);
        if (bed != null) {
            bed.setStatus(newStatus);
            return true;
        }
        return false;
    }
}
