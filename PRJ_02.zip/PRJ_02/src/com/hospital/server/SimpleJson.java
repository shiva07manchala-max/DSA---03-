package com.hospital.server;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomHashMap;

/**
 * Zero-dependency lightweight JSON builder & parser.
 */
public class SimpleJson {

    public static String escape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    public static String extractString(String json, String key) {
        if (json == null || key == null) return null;
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx == -1) return null;

        int colon = json.indexOf(":", idx + pattern.length());
        if (colon == -1) return null;

        int startQuote = json.indexOf("\"", colon + 1);
        if (startQuote == -1) return null;

        int endQuote = -1;
        for (int i = startQuote + 1; i < json.length(); i++) {
            if (json.charAt(i) == '"' && json.charAt(i - 1) != '\\') {
                endQuote = i;
                break;
            }
        }
        if (endQuote == -1) return null;

        return json.substring(startQuote + 1, endQuote).replace("\\\"", "\"").replace("\\n", "\n");
    }

    public static int extractInt(String json, String key, int defaultVal) {
        if (json == null || key == null) return defaultVal;
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx == -1) return defaultVal;

        int colon = json.indexOf(":", idx + pattern.length());
        if (colon == -1) return defaultVal;

        int start = colon + 1;
        while (start < json.length() && Character.isWhitespace(json.charAt(start))) start++;

        int end = start;
        while (end < json.length() && (Character.isDigit(json.charAt(end)) || json.charAt(end) == '-')) end++;

        try {
            return Integer.parseInt(json.substring(start, end));
        } catch (Exception e) {
            return defaultVal;
        }
    }
}
