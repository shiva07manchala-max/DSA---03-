package com.hospital.server.handlers;

import com.hospital.ds.CustomArrayList;
import com.hospital.engine.SurgeonWorkloadAnalyzer;
import com.hospital.model.HospitalState;
import com.hospital.model.Surgeon;
import com.hospital.server.SimpleJson;

/**
 * Handles Surgeon Registry, Utilization Metrics, and Fatigue Analysis endpoints.
 */
public class SurgeonHandler {

    public static String handleGetSurgeons(HospitalState state) {
        CustomArrayList<Surgeon> surgeons = state.getAllSurgeons();
        SurgeonWorkloadAnalyzer.WorkloadReport report = SurgeonWorkloadAnalyzer.analyze(surgeons, state.getAllOperatingRooms());

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"success\": true,\n");
        sb.append("  \"averageSurgeonUtilization\": ").append(String.format("%.2f", report.averageSurgeonUtilization)).append(",\n");
        sb.append("  \"totalSurgicalMinutes\": ").append(report.totalSurgicalMinutes).append(",\n");
        sb.append("  \"surgeonsAtRiskCount\": ").append(report.surgeonsAtOvertimeRiskCount).append(",\n");
        sb.append("  \"surgeons\": [\n");

        for (int i = 0; i < report.surgeonMetrics.size(); i++) {
            SurgeonWorkloadAnalyzer.SurgeonMetric sm = report.surgeonMetrics.get(i);
            sb.append("    {\n");
            sb.append("      \"id\": \"").append(SimpleJson.escape(sm.surgeonId)).append("\",\n");
            sb.append("      \"name\": \"").append(SimpleJson.escape(sm.name)).append("\",\n");
            sb.append("      \"specialty\": \"").append(SimpleJson.escape(sm.specialty)).append("\",\n");
            sb.append("      \"assignedMinutes\": ").append(sm.totalAssignedMinutes).append(",\n");
            sb.append("      \"maxShiftMinutes\": ").append(sm.maxShiftMinutes).append(",\n");
            sb.append("      \"casesCount\": ").append(sm.casesCount).append(",\n");
            sb.append("      \"utilizationPercentage\": ").append(String.format("%.2f", sm.utilizationPercentage)).append(",\n");
            sb.append("      \"fatigueIndex\": ").append(String.format("%.2f", sm.fatigueIndex)).append(",\n");
            sb.append("      \"isOvertimeRisk\": ").append(sm.isOvertimeRisk).append("\n");
            sb.append("    }").append(i < report.surgeonMetrics.size() - 1 ? ",\n" : "\n");
        }

        sb.append("  ]\n");
        sb.append("}");
        return sb.toString();
    }
}
