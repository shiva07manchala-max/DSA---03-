package com.hospital.server.handlers;

import com.hospital.algorithms.flow.MinCutAnalyzer;
import com.hospital.algorithms.flow.ResidualGraph;
import com.hospital.model.HospitalState;
import com.hospital.server.SimpleJson;

/**
 * Provides Network Flow and Min-Cut capacity bottleneck analytics.
 */
public class FlowHandler {

    public static String handleGetFlowAnalytics(HospitalState state) {
        ResidualGraph capGraph = new ResidualGraph(9);
        String[] labels = new String[]{
                "Inflow Source",
                "ER Triage Intake",
                "Major ORs (Cardiac/Neuro)",
                "General ORs (Ortho/Gen)",
                "Day ORs (Ambulatory)",
                "PACU Recovery Beds",
                "ICU Intensive Beds",
                "General Surgical Wards",
                "Hospital Discharge Sink"
        };

        capGraph.addEdge(0, 1, 50);
        capGraph.addEdge(1, 2, 12);
        capGraph.addEdge(1, 3, 16);
        capGraph.addEdge(1, 4, 10);
        capGraph.addEdge(2, 6, 8);  // Bottleneck
        capGraph.addEdge(2, 5, 6);
        capGraph.addEdge(3, 5, 10);
        capGraph.addEdge(3, 7, 8);
        capGraph.addEdge(4, 7, 10);
        capGraph.addEdge(5, 7, 10);
        capGraph.addEdge(6, 8, 8);  // Bottleneck
        capGraph.addEdge(7, 8, 20);

        MinCutAnalyzer.MinCutResult minCut = MinCutAnalyzer.findMinCut(capGraph, 0, 8, labels);

        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\": true,");
        json.append(String.format("\"maxFlowCapacity\": %d,", minCut.minCutCapacity));
        json.append("\"bottleneckCuts\": [");

        for (int i = 0; i < minCut.bottleneckEdges.size(); i++) {
            MinCutAnalyzer.CutEdge edge = minCut.bottleneckEdges.get(i);
            json.append("{");
            json.append(String.format("\"u\": %d,", edge.u));
            json.append(String.format("\"v\": %d,", edge.v));
            json.append(String.format("\"capacity\": %d,", edge.capacity));
            json.append(String.format("\"description\": \"%s\"", SimpleJson.escape(edge.description)));
            json.append("}");
            if (i < minCut.bottleneckEdges.size() - 1) json.append(",");
        }
        json.append("],");

        json.append("\"nodes\": [");
        for (int i = 0; i < labels.length; i++) {
            json.append("{");
            json.append(String.format("\"id\": %d,", i));
            json.append(String.format("\"name\": \"%s\",", SimpleJson.escape(labels[i])));
            json.append(String.format("\"inSourcePartition\": %b", minCut.sourceSet[i]));
            json.append("}");
            if (i < labels.length - 1) json.append(",");
        }
        json.append("]");

        json.append("}");
        return json.toString();
    }
}
