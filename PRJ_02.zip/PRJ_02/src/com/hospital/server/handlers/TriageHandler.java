package com.hospital.server.handlers;

import com.hospital.algorithms.dp.SequenceAlignment;
import com.hospital.algorithms.dp.WagnerFischerEditDistance;
import com.hospital.algorithms.strings.AhoCorasickTriage;
import com.hospital.algorithms.strings.SuffixArrayKasai;
import com.hospital.ds.CustomArrayList;
import com.hospital.model.TriageLevel;
import com.hospital.server.SimpleJson;

/**
 * Handles string algorithms, Aho-Corasick triage evaluation, and similarity matching.
 */
public class TriageHandler {
    private static final AhoCorasickTriage triageEngine = new AhoCorasickTriage();

    public static String handleEvaluateText(String bodyJson) {
        String text = SimpleJson.extractString(bodyJson, "text");
        if (text == null) text = "";

        CustomArrayList<AhoCorasickTriage.TriageMatch> matches = triageEngine.evaluateClinicalNote(text);
        TriageLevel inferredLevel = triageEngine.inferOverallTriage(text);

        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\": true,");
        json.append(String.format("\"inferredLevel\": %d,", inferredLevel.getLevel()));
        json.append(String.format("\"inferredLabel\": \"%s\",", SimpleJson.escape(inferredLevel.getLabel())));
        json.append(String.format("\"inferredColor\": \"%s\",", inferredLevel.getColorHex()));
        json.append("\"matches\": [");

        for (int i = 0; i < matches.size(); i++) {
            AhoCorasickTriage.TriageMatch m = matches.get(i);
            json.append("{");
            json.append(String.format("\"keyword\": \"%s\",", SimpleJson.escape(m.keyword)));
            json.append(String.format("\"start\": %d,", m.startIndex));
            json.append(String.format("\"end\": %d,", m.endIndex));
            json.append(String.format("\"level\": %d,", m.triageLevel.getLevel()));
            json.append(String.format("\"specialty\": \"%s\",", SimpleJson.escape(m.specialty)));
            json.append(String.format("\"urgencyScore\": %d", m.urgencyScore));
            json.append("}");
            if (i < matches.size() - 1) json.append(",");
        }
        json.append("]");
        json.append("}");
        return json.toString();
    }

    public static String handleFuzzySearch(String bodyJson) {
        String query = SimpleJson.extractString(bodyJson, "query");
        String target = SimpleJson.extractString(bodyJson, "target");

        if (query == null || target == null) {
            return "{\"success\": false, \"message\": \"query and target required\"}";
        }

        int levDist = WagnerFischerEditDistance.computeLevenshtein(query, target);
        int damerauDist = WagnerFischerEditDistance.computeDamerauLevenshtein(query, target);
        double similarity = WagnerFischerEditDistance.calculateSimilarity(query, target);

        return String.format("{\"success\": true, \"levenshtein\": %d, \"damerau\": %d, \"similarity\": %.4f}",
                levDist, damerauDist, similarity);
    }

    public static String handleSuffixLcs(String bodyJson) {
        String s1 = SimpleJson.extractString(bodyJson, "text1");
        String s2 = SimpleJson.extractString(bodyJson, "text2");

        if (s1 == null || s2 == null) {
            return "{\"success\": false, \"message\": \"text1 and text2 required\"}";
        }

        String lcs = SuffixArrayKasai.longestCommonSubstring(s1, s2);
        return String.format("{\"success\": true, \"longestCommonSubstring\": \"%s\", \"length\": %d}",
                SimpleJson.escape(lcs), lcs.length());
    }
}
