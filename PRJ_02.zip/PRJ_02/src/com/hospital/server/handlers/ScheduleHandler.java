package com.hospital.server.handlers;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.HospitalState;
import com.hospital.engine.SchedulingEngine;
import com.hospital.model.OperatingRoom;
import com.hospital.model.Patient;
import com.hospital.model.ScheduleSlot;
import com.hospital.server.SimpleJson;

/**
 * Handles scheduling requests, algorithm execution, and timeline data formatting.
 */
public class ScheduleHandler {

    public static String handleGetSchedule(HospitalState state) {
        SchedulingEngine.ScheduleReport report = SchedulingEngine.runMasterSchedule(state);

        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\": true,");
        json.append(String.format("\"makespanMinutes\": %d,", report.makespanMinutes));
        json.append(String.format("\"totalIdleMinutes\": %d,", report.totalIdleMinutes));
        json.append(String.format("\"orUtilizationPercentage\": %.2f,", report.orUtilizationPercentage));
        json.append(String.format("\"bedOccupancyPercentage\": %.2f,", report.bedOccupancyPercentage));
        json.append(String.format("\"approxBoundRatio\": %.4f,", report.approxBoundRatio));
        json.append(String.format("\"exactOptimalMakespan\": %d,", report.exactOptimalMakespan));
        json.append(String.format("\"turnaroundTimeSavedMinutes\": %d,", report.turnaroundTimeSavedMinutes));
        json.append(String.format("\"totalPatientsScheduled\": %d,", report.totalPatientsScheduled));
        json.append(String.format("\"emergencyPatientsHandled\": %d,", report.emergencyPatientsHandled));
        json.append(String.format("\"maxFlowCapacity\": %d,", report.maxFlowCapacity));

        // Operating Rooms & Slots
        json.append("\"rooms\": [");
        CustomArrayList<OperatingRoom> rooms = state.getAllOperatingRooms();
        for (int r = 0; r < rooms.size(); r++) {
            OperatingRoom room = rooms.get(r);
            json.append("{");
            json.append(String.format("\"id\": \"%s\",", room.getId()));
            json.append(String.format("\"name\": \"%s\",", SimpleJson.escape(room.getName())));
            json.append(String.format("\"isEmergencyCapable\": %b,", room.isEmergencyCapable()));
            json.append(String.format("\"makespanMinutes\": %d,", room.getTotalMakespanMinutes()));
            json.append(String.format("\"idleMinutes\": %d,", room.getTotalIdleMinutes()));

            json.append("\"slots\": [");
            for (int s = 0; s < room.getScheduleSlots().size(); s++) {
                ScheduleSlot slot = room.getScheduleSlots().get(s);
                json.append("{");
                json.append(String.format("\"slotId\": \"%s\",", slot.getSlotId()));
                json.append(String.format("\"patientId\": \"%s\",", slot.getPatientId()));
                json.append(String.format("\"patientName\": \"%s\",", SimpleJson.escape(slot.getPatientName())));
                json.append(String.format("\"procedureName\": \"%s\",", SimpleJson.escape(slot.getProcedureName())));
                json.append(String.format("\"surgeonId\": \"%s\",", slot.getSurgeonId()));
                json.append(String.format("\"surgeonName\": \"%s\",", SimpleJson.escape(slot.getSurgeonName())));
                json.append(String.format("\"triageLevel\": %d,", slot.getTriageLevel().getLevel()));
                json.append(String.format("\"triageColor\": \"%s\",", slot.getTriageLevel().getColorHex()));
                json.append(String.format("\"triageLabel\": \"%s\",", SimpleJson.escape(slot.getTriageLevel().getLabel())));
                json.append(String.format("\"startMinute\": %d,", slot.getStartMinute()));
                json.append(String.format("\"endMinute\": %d,", slot.getEndMinute()));
                json.append(String.format("\"turnaroundMinutes\": %d,", slot.getTurnaroundMinutes()));
                json.append(String.format("\"isEmergency\": %b", slot.isEmergency()));
                json.append("}");
                if (s < room.getScheduleSlots().size() - 1) json.append(",");
            }
            json.append("]");

            json.append("}");
            if (r < rooms.size() - 1) json.append(",");
        }
        json.append("]");

        json.append("}");
        return json.toString();
    }
}
