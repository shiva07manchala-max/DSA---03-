package com.hospital.server.handlers;

import com.hospital.engine.HospitalDataLoader;
import com.hospital.engine.StatePersistenceManager;
import com.hospital.model.HospitalState;
import com.hospital.server.SimpleJson;

/**
 * Handles Hospital State Serialization, Backup, and Reset endpoints.
 */
public class StatePersistenceHandler {

    public static String handleSaveState(HospitalState state) {
        boolean success = StatePersistenceManager.saveSnapshotToFile(state, "data/hospital_snapshot.json");
        String jsonSnapshot = StatePersistenceManager.serializeStateToJson(state);

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"success\": ").append(success).append(",\n");
        sb.append("  \"message\": \"Hospital operational snapshot successfully persisted to disk\",\n");
        sb.append("  \"filePath\": \"data/hospital_snapshot.json\",\n");
        sb.append("  \"snapshotBytes\": ").append(jsonSnapshot.getBytes().length).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public static String handleResetState(HospitalState[] stateRef) {
        stateRef[0] = HospitalDataLoader.loadInitialState();
        return "{\n  \"success\": true,\n  \"message\": \"Hospital operational state successfully reset to initial clinical baseline\",\n  \"patientsCount\": "
                + stateRef[0].getAllPatients().size() + "\n}";
    }

    public static String handleExportJson(HospitalState state) {
        return StatePersistenceManager.serializeStateToJson(state);
    }
}
