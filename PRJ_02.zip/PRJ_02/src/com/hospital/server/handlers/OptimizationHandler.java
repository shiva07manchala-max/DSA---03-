package com.hospital.server.handlers;

import com.hospital.algorithms.approx.MultiObjectiveOptimizationEngine;
import com.hospital.engine.PatientAdmissionManager;
import com.hospital.engine.TelemetryClockEngine;
import com.hospital.model.HospitalState;
import com.hospital.model.Patient;
import com.hospital.server.SimpleJson;

/**
 * Handles Multi-Strategy Optimization Comparisons, Simulation Clock Advancements,
 * and Dynamic Patient Admittance.
 */
public class OptimizationHandler {

    public static String handleCompareStrategies(HospitalState state) {
        MultiObjectiveOptimizationEngine.SchedulingStrategy[] strategies = MultiObjectiveOptimizationEngine.SchedulingStrategy.values();

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"success\": true,\n");
        sb.append("  \"strategies\": [\n");

        for (int i = 0; i < strategies.length; i++) {
            MultiObjectiveOptimizationEngine.SchedulingStrategy strat = strategies[i];
            MultiObjectiveOptimizationEngine.MultiObjectiveResult res = MultiObjectiveOptimizationEngine.optimize(
                    state.getAllPatients(),
                    state.getAllOperatingRooms(),
                    state.getAllSurgeons(),
                    state.getCurrentSimulationMinute(),
                    strat
            );

            sb.append("    {\n");
            sb.append("      \"key\": \"").append(strat.name()).append("\",\n");
            sb.append("      \"name\": \"").append(SimpleJson.escape(strat.getDisplayName())).append("\",\n");
            sb.append("      \"description\": \"").append(SimpleJson.escape(strat.getDescription())).append("\",\n");
            sb.append("      \"makespanMinutes\": ").append(res.makespanMinutes).append(",\n");
            sb.append("      \"idleMinutes\": ").append(res.totalIdleMinutes).append(",\n");
            sb.append("      \"tardinessMinutes\": ").append(res.totalTardinessMinutes).append(",\n");
            sb.append("      \"loadStdDev\": ").append(String.format("%.2f", res.loadStandardDeviation)).append(",\n");
            sb.append("      \"orUtilization\": ").append(String.format("%.2f", res.orUtilizationPercentage)).append(",\n");
            sb.append("      \"emergencyHandled\": ").append(res.emergencyHandledCount).append("\n");
            sb.append("    }").append(i < strategies.length - 1 ? ",\n" : "\n");
        }

        sb.append("  ]\n");
        sb.append("}");
        return sb.toString();
    }

    public static String handleAdvanceClock(HospitalState state, String body) {
        int minutes = SimpleJson.extractInt(body, "minutes", 30);
        TelemetryClockEngine.ClockAdvanceReport report = TelemetryClockEngine.advanceTime(state, minutes);

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"success\": true,\n");
        sb.append("  \"previousMinute\": ").append(report.previousMinute).append(",\n");
        sb.append("  \"currentSimulationMinute\": ").append(report.newMinute).append(",\n");
        sb.append("  \"minutesAdvanced\": ").append(report.minutesAdvanced).append(",\n");
        sb.append("  \"bedsCleanedCount\": ").append(report.bedsCleanedCount).append(",\n");
        sb.append("  \"patientsRecoveredCount\": ").append(report.patientsRecoveredCount).append(",\n");
        sb.append("  \"surgeriesCompletedCount\": ").append(report.surgeriesCompletedCount).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public static String handleAddPatient(HospitalState state, String body) {
        try {
            Patient p = PatientAdmissionManager.admitNewPatient(state, body);
            StringBuilder sb = new StringBuilder();
            sb.append("{\n");
            sb.append("  \"success\": true,\n");
            sb.append("  \"message\": \"Patient admitted and triaged successfully\",\n");
            sb.append("  \"patientId\": \"").append(SimpleJson.escape(p.getId())).append("\",\n");
            sb.append("  \"name\": \"").append(SimpleJson.escape(p.getName())).append("\",\n");
            sb.append("  \"triageLevel\": \"").append(p.getTriageLevel().name()).append("\",\n");
            sb.append("  \"assignedWard\": \"").append(p.getPostOpWardRequirement().name()).append("\",\n");
            sb.append("  \"procedure\": \"").append(SimpleJson.escape(p.getRequiredProcedure())).append("\",\n");
            sb.append("  \"deadlineMinutes\": ").append(p.getDeadlineMinutes()).append("\n");
            sb.append("}");
            return sb.toString();
        } catch (Exception e) {
            return "{\n  \"success\": false,\n  \"error\": \"" + SimpleJson.escape(e.getMessage()) + "\"\n}";
        }
    }
}
