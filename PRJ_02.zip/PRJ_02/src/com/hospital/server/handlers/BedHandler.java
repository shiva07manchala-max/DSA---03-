package com.hospital.server.handlers;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.HospitalState;
import com.hospital.model.Bed;
import com.hospital.model.BedStatus;
import com.hospital.server.SimpleJson;

/**
 * Handles bed telemetry, ward occupancies, and status mutations.
 */
public class BedHandler {

    public static String handleGetBeds(HospitalState state) {
        CustomArrayList<Bed> beds = state.getAllBeds();

        StringBuilder json = new StringBuilder();
        json.append("{");
        json.append("\"success\": true,");
        json.append(String.format("\"totalBeds\": %d,", beds.size()));
        json.append("\"beds\": [");

        for (int i = 0; i < beds.size(); i++) {
            Bed b = beds.get(i);
            json.append("{");
            json.append(String.format("\"id\": \"%s\",", b.getId()));
            json.append(String.format("\"roomNumber\": \"%s\",", SimpleJson.escape(b.getRoomNumber())));
            json.append(String.format("\"wardType\": \"%s\",", b.getWardType().name()));
            json.append(String.format("\"wardDisplayName\": \"%s\",", SimpleJson.escape(b.getWardType().getDisplayName())));
            json.append(String.format("\"status\": \"%s\",", b.getStatus().name()));
            json.append(String.format("\"currentPatientId\": %s,", (b.getCurrentPatientId() != null ? "\"" + b.getCurrentPatientId() + "\"" : "null")));
            json.append(String.format("\"occupiedUntilMinutes\": %d", b.getOccupiedUntilMinutes()));
            json.append("}");
            if (i < beds.size() - 1) json.append(",");
        }
        json.append("]");
        json.append("}");
        return json.toString();
    }

    public static String handleUpdateBed(HospitalState state, String bodyJson) {
        String bedId = SimpleJson.extractString(bodyJson, "bedId");
        String statusStr = SimpleJson.extractString(bodyJson, "status");

        if (bedId == null || statusStr == null) {
            return "{\"success\": false, \"message\": \"bedId and status required\"}";
        }

        Bed bed = state.getBed(bedId);
        if (bed == null) {
            return "{\"success\": false, \"message\": \"Bed not found\"}";
        }

        try {
            BedStatus newStatus = BedStatus.valueOf(statusStr.toUpperCase());
            bed.setStatus(newStatus);
            if (newStatus == BedStatus.AVAILABLE) {
                bed.setCurrentPatientId(null);
            }
            return String.format("{\"success\": true, \"bedId\": \"%s\", \"status\": \"%s\"}", bedId, newStatus.name());
        } catch (IllegalArgumentException e) {
            return "{\"success\": false, \"message\": \"Invalid BedStatus\"}";
        }
    }
}
