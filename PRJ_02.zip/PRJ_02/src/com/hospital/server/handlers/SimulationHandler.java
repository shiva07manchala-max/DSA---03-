package com.hospital.server.handlers;

import com.hospital.model.HospitalState;
import com.hospital.engine.SimulationManager;
import com.hospital.model.Patient;
import com.hospital.server.SimpleJson;

/**
 * Handles simulation events: emergency arrivals, procedure duration overruns, and cancellations.
 */
public class SimulationHandler {

    public static String handleEmergencyArrival(HospitalState state, SimulationManager simManager, String bodyJson) {
        String name = SimpleJson.extractString(bodyJson, "name");
        int age = SimpleJson.extractInt(bodyJson, "age", 45);
        String gender = SimpleJson.extractString(bodyJson, "gender");
        if (gender == null) gender = "Other";
        String clinicalReport = SimpleJson.extractString(bodyJson, "clinicalReport");
        if (clinicalReport == null) clinicalReport = "Emergency patient arrival with acute symptoms";
        String procedure = SimpleJson.extractString(bodyJson, "procedure");
        if (procedure == null) procedure = "Emergency Trauma Laparotomy";
        int duration = SimpleJson.extractInt(bodyJson, "duration", 90);

        if (name == null || name.isEmpty()) name = "Emergency Inbound";

        Patient p = simManager.injectEmergencyArrival(name, age, gender, clinicalReport, procedure, duration);

        return String.format("{\"success\": true, \"patientId\": \"%s\", \"name\": \"%s\", \"triageLevel\": %d, \"triageLabel\": \"%s\"}",
                p.getId(), SimpleJson.escape(p.getName()), p.getTriageLevel().getLevel(), SimpleJson.escape(p.getTriageLevel().getLabel()));
    }

    public static String handleOverrun(HospitalState state, SimulationManager simManager, String bodyJson) {
        String roomId = SimpleJson.extractString(bodyJson, "roomId");
        String slotId = SimpleJson.extractString(bodyJson, "slotId");
        int extraMinutes = SimpleJson.extractInt(bodyJson, "extraMinutes", 30);

        if (roomId == null || slotId == null) {
            return "{\"success\": false, \"message\": \"roomId and slotId required\"}";
        }

        boolean applied = simManager.applyProcedureOverrun(roomId, slotId, extraMinutes);
        return String.format("{\"success\": %b, \"roomId\": \"%s\", \"slotId\": \"%s\", \"extraMinutes\": %d}",
                applied, roomId, slotId, extraMinutes);
    }

    public static String handleCancellation(HospitalState state, SimulationManager simManager, String bodyJson) {
        String roomId = SimpleJson.extractString(bodyJson, "roomId");
        String slotId = SimpleJson.extractString(bodyJson, "slotId");

        if (roomId == null || slotId == null) {
            return "{\"success\": false, \"message\": \"roomId and slotId required\"}";
        }

        boolean cancelled = simManager.cancelProcedure(roomId, slotId);
        return String.format("{\"success\": %b, \"roomId\": \"%s\", \"slotId\": \"%s\"}", cancelled, roomId, slotId);
    }
}
