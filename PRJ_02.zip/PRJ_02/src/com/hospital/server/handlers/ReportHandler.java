package com.hospital.server.handlers;

import com.hospital.model.HospitalState;
import com.hospital.engine.QualityReporter;
import com.hospital.engine.SchedulingEngine;
import com.hospital.server.SimpleJson;

/**
 * Handles generating and exporting quality audit reports.
 */
public class ReportHandler {

    public static String handleGetReportText(HospitalState state) {
        SchedulingEngine.ScheduleReport report = SchedulingEngine.runMasterSchedule(state);
        String reportText = QualityReporter.generateComprehensiveReport(state, report);

        return String.format("{\"success\": true, \"reportText\": \"%s\"}", SimpleJson.escape(reportText));
    }
}
