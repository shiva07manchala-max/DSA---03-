package com.hospital.server.handlers;

import com.hospital.server.SimpleJson;

/**
 * Handles role-based authentication and demo credentials.
 */
public class AuthHandler {

    public static class UserSession {
        public String username;
        public String role;
        public String displayName;
        public String token;

        public UserSession(String username, String role, String displayName, String token) {
            this.username = username;
            this.role = role;
            this.displayName = displayName;
            this.token = token;
        }
    }

    public static String handleLogin(String bodyJson) {
        String username = SimpleJson.extractString(bodyJson, "username");
        String password = SimpleJson.extractString(bodyJson, "password");

        if (username == null || password == null) {
            return "{\"success\": false, \"message\": \"Username and password required\"}";
        }

        username = username.trim().toLowerCase();
        password = password.trim();

        if ("admin".equals(username) && "admin123".equals(password)) {
            return buildSuccessJson("admin", "Hospital Director / Administrator", "Dr. Rajesh Sharma (Admin)", "TOKEN-ADM-9981");
        } else if ("cmo".equals(username) && "cmo123".equals(password)) {
            return buildSuccessJson("cmo", "Chief Medical Officer", "Dr. Devi Shetty (CMO)", "TOKEN-CMO-4412");
        } else if ("scheduler".equals(username) && "sched123".equals(password)) {
            return buildSuccessJson("scheduler", "Senior Operations Scheduler", "Anitha Chekuri (Lead Scheduler)", "TOKEN-SCH-5521");
        } else if ("nurse".equals(username) && "nurse123".equals(password)) {
            return buildSuccessJson("nurse", "Emergency Triage Lead Nurse", "Kavita Rao (Triage RN)", "TOKEN-NUR-1102");
        } else {
            return "{\"success\": false, \"message\": \"Invalid credentials. Use one of the demo role buttons below.\"}";
        }
    }

    private static String buildSuccessJson(String user, String role, String name, String token) {
        return String.format("{\"success\": true, \"user\": \"%s\", \"role\": \"%s\", \"name\": \"%s\", \"token\": \"%s\"}",
                user, SimpleJson.escape(role), SimpleJson.escape(name), token);
    }
}
