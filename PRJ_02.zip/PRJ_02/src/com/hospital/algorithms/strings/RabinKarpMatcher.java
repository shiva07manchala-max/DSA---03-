package com.hospital.algorithms.strings;

import com.hospital.ds.CustomArrayList;

/**
 * Rabin-Karp String Matcher with Polynomial Rolling Hash and Double Hashing
 * for collision elimination.
 * Average running time: O(n + m), worst-case O(n*m).
 */
public class RabinKarpMatcher {
    private static final long PRIME1 = 31;
    private static final long MOD1 = 1_000_000_007L;
    private static final long PRIME2 = 37;
    private static final long MOD2 = 1_000_000_009L;

    public static CustomArrayList<Integer> search(String text, String pattern) {
        CustomArrayList<Integer> matches = new CustomArrayList<>();
        if (text == null || pattern == null || pattern.length() == 0 || text.length() < pattern.length()) {
            return matches;
        }

        int n = text.length();
        int m = pattern.length();

        long pHash1 = 0, pHash2 = 0;
        long tHash1 = 0, tHash2 = 0;
        long h1 = 1, h2 = 1;

        for (int i = 0; i < m - 1; i++) {
            h1 = (h1 * PRIME1) % MOD1;
            h2 = (h2 * PRIME2) % MOD2;
        }

        for (int i = 0; i < m; i++) {
            pHash1 = (pHash1 * PRIME1 + pattern.charAt(i)) % MOD1;
            pHash2 = (pHash2 * PRIME2 + pattern.charAt(i)) % MOD2;
            tHash1 = (tHash1 * PRIME1 + text.charAt(i)) % MOD1;
            tHash2 = (tHash2 * PRIME2 + text.charAt(i)) % MOD2;
        }

        for (int i = 0; i <= n - m; i++) {
            if (pHash1 == tHash1 && pHash2 == tHash2) {
                boolean match = true;
                for (int j = 0; j < m; j++) {
                    if (text.charAt(i + j) != pattern.charAt(j)) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    matches.add(i);
                }
            }

            if (i < n - m) {
                tHash1 = (PRIME1 * (tHash1 - text.charAt(i) * h1 % MOD1 + MOD1) + text.charAt(i + m)) % MOD1;
                tHash2 = (PRIME2 * (tHash2 - text.charAt(i) * h2 % MOD2 + MOD2) + text.charAt(i + m)) % MOD2;
            }
        }
        return matches;
    }
}
