package com.hospital.algorithms.strings;

import com.hospital.ds.CustomArrayList;

/**
 * Modern Linear-Time String Matching via Gusfield's Z-Algorithm.
 * Computes Z-array in O(n) time.
 */
public class ZFunctionMatcher {

    public static int[] computeZArray(String s) {
        int n = s.length();
        int[] z = new int[n];
        int l = 0, r = 0;

        for (int i = 1; i < n; i++) {
            if (i <= r) {
                z[i] = Math.min(r - i + 1, z[i - l]);
            }
            while (i + z[i] < n && s.charAt(z[i]) == s.charAt(i + z[i])) {
                z[i]++;
            }
            if (i + z[i] - 1 > r) {
                l = i;
                r = i + z[i] - 1;
            }
        }
        return z;
    }

    public static CustomArrayList<Integer> search(String text, String pattern) {
        CustomArrayList<Integer> matches = new CustomArrayList<>();
        if (text == null || pattern == null || pattern.length() == 0 || text.length() < pattern.length()) {
            return matches;
        }

        String concat = pattern + "$" + text;
        int[] z = computeZArray(concat);
        int patternLen = pattern.length();

        for (int i = patternLen + 1; i < concat.length(); i++) {
            if (z[i] == patternLen) {
                matches.add(i - patternLen - 1);
            }
        }
        return matches;
    }
}
