package com.hospital.algorithms.strings;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomHashMap;
import com.hospital.ds.CustomQueue;
import com.hospital.model.TriageLevel;

/**
 * Aho-Corasick Multi-Pattern Emergency Triage Automaton.
 * Builds Trie with BFS failure transitions in O(Sigma m) and searches text in O(n + k).
 */
public class AhoCorasickTriage {

    public static class TriageKeyword {
        public String keyword;
        public TriageLevel triageLevel;
        public String specialtyNeeded;
        public int urgencyScore;

        public TriageKeyword(String keyword, TriageLevel triageLevel, String specialtyNeeded, int urgencyScore) {
            this.keyword = keyword.toLowerCase();
            this.triageLevel = triageLevel;
            this.specialtyNeeded = specialtyNeeded;
            this.urgencyScore = urgencyScore;
        }
    }

    public static class TriageMatch {
        public String keyword;
        public int startIndex;
        public int endIndex;
        public TriageLevel triageLevel;
        public String specialty;
        public int urgencyScore;

        public TriageMatch(String keyword, int startIndex, int endIndex, TriageLevel triageLevel, String specialty, int urgencyScore) {
            this.keyword = keyword;
            this.startIndex = startIndex;
            this.endIndex = endIndex;
            this.triageLevel = triageLevel;
            this.specialty = specialty;
            this.urgencyScore = urgencyScore;
        }
    }

    private static class TrieNode {
        CustomHashMap<Character, TrieNode> children = new CustomHashMap<>();
        TrieNode fail = null;
        CustomArrayList<TriageKeyword> outputs = new CustomArrayList<>();
    }

    private final TrieNode root;
    private final CustomArrayList<TriageKeyword> registeredKeywords;

    public AhoCorasickTriage() {
        this.root = new TrieNode();
        this.registeredKeywords = new CustomArrayList<>();
        registerDefaultEmergencyLexicon();
        buildAutomaton();
    }

    public void addPattern(String keyword, TriageLevel level, String specialty, int urgencyScore) {
        registeredKeywords.add(new TriageKeyword(keyword, level, specialty, urgencyScore));
    }

    public void buildAutomaton() {
        for (int i = 0; i < registeredKeywords.size(); i++) {
            TriageKeyword tk = registeredKeywords.get(i);
            TrieNode curr = root;
            String word = tk.keyword;
            for (int j = 0; j < word.length(); j++) {
                char c = word.charAt(j);
                TrieNode child = curr.children.get(c);
                if (child == null) {
                    child = new TrieNode();
                    curr.children.put(c, child);
                }
                curr = child;
            }
            curr.outputs.add(tk);
        }

        CustomQueue<TrieNode> queue = new CustomQueue<>();
        CustomArrayList<Character> rootKeys = root.children.keySet();
        for (int i = 0; i < rootKeys.size(); i++) {
            TrieNode child = root.children.get(rootKeys.get(i));
            child.fail = root;
            queue.enqueue(child);
        }

        while (!queue.isEmpty()) {
            TrieNode current = queue.dequeue();
            CustomArrayList<Character> keys = current.children.keySet();
            for (int i = 0; i < keys.size(); i++) {
                char c = keys.get(i);
                TrieNode child = current.children.get(c);
                TrieNode failNode = current.fail;

                while (failNode != null && failNode.children.get(c) == null) {
                    failNode = failNode.fail;
                }
                child.fail = (failNode != null) ? failNode.children.get(c) : root;

                if (child.fail != null) {
                    for (int o = 0; o < child.fail.outputs.size(); o++) {
                        child.outputs.add(child.fail.outputs.get(o));
                    }
                }
                queue.enqueue(child);
            }
        }
    }

    public CustomArrayList<TriageMatch> evaluateClinicalNote(String note) {
        CustomArrayList<TriageMatch> matches = new CustomArrayList<>();
        if (note == null || note.isEmpty()) return matches;

        String lower = note.toLowerCase();
        TrieNode curr = root;

        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            while (curr != root && curr.children.get(c) == null) {
                curr = curr.fail;
                if (curr == null) curr = root;
            }
            TrieNode next = curr.children.get(c);
            if (next != null) {
                curr = next;
            } else {
                curr = root;
            }

            for (int o = 0; o < curr.outputs.size(); o++) {
                TriageKeyword tk = curr.outputs.get(o);
                int start = i - tk.keyword.length() + 1;
                matches.add(new TriageMatch(tk.keyword, start, i + 1, tk.triageLevel, tk.specialtyNeeded, tk.urgencyScore));
            }
        }
        return matches;
    }

    public TriageLevel inferOverallTriage(String clinicalNote) {
        CustomArrayList<TriageMatch> matches = evaluateClinicalNote(clinicalNote);
        if (matches.isEmpty()) return TriageLevel.LEVEL_4_ELECTIVE;

        TriageLevel highest = TriageLevel.LEVEL_4_ELECTIVE;
        for (int i = 0; i < matches.size(); i++) {
            if (matches.get(i).triageLevel.getLevel() < highest.getLevel()) {
                highest = matches.get(i).triageLevel;
            }
        }
        return highest;
    }

    private void registerDefaultEmergencyLexicon() {
        // Level 1: Immediate Emergencies (Life-Threatening)
        addPattern("cardiac arrest", TriageLevel.LEVEL_1_EMERGENCY, "Cardiology", 100);
        addPattern("massive hemorrhage", TriageLevel.LEVEL_1_EMERGENCY, "Trauma Surgery", 98);
        addPattern("epidural hematoma", TriageLevel.LEVEL_1_EMERGENCY, "Neurosurgery", 95);
        addPattern("subdural hematoma", TriageLevel.LEVEL_1_EMERGENCY, "Neurosurgery", 95);
        addPattern("aortic dissection", TriageLevel.LEVEL_1_EMERGENCY, "Cardiothoracic", 96);
        addPattern("respiratory failure", TriageLevel.LEVEL_1_EMERGENCY, "Pulmonology", 92);
        addPattern("septic shock", TriageLevel.LEVEL_1_EMERGENCY, "Critical Care", 90);
        addPattern("ischemic stroke", TriageLevel.LEVEL_1_EMERGENCY, "Neurology", 94);
        addPattern("ruptured aneurysm", TriageLevel.LEVEL_1_EMERGENCY, "Cardiothoracic", 97);
        addPattern("pulmonary embolism", TriageLevel.LEVEL_1_EMERGENCY, "Critical Care", 93);
        addPattern("flail chest", TriageLevel.LEVEL_1_EMERGENCY, "Trauma Surgery", 91);
        addPattern("tension pneumothorax", TriageLevel.LEVEL_1_EMERGENCY, "Thoracic Surgery", 96);

        // Level 2: Urgent (Time-Critical)
        addPattern("acute appendicitis", TriageLevel.LEVEL_2_URGENT, "General Surgery", 75);
        addPattern("compound fracture", TriageLevel.LEVEL_2_URGENT, "Orthopedics", 72);
        addPattern("bowel perforation", TriageLevel.LEVEL_2_URGENT, "General Surgery", 78);
        addPattern("compartment syndrome", TriageLevel.LEVEL_2_URGENT, "Orthopedics", 80);
        addPattern("unstable angina", TriageLevel.LEVEL_2_URGENT, "Cardiology", 76);
        addPattern("acute peritonitis", TriageLevel.LEVEL_2_URGENT, "General Surgery", 77);
        addPattern("incarcerated hernia", TriageLevel.LEVEL_2_URGENT, "General Surgery", 74);
        addPattern("displaced fracture", TriageLevel.LEVEL_2_URGENT, "Orthopedics", 70);

        // Level 3: Semi-Urgent
        addPattern("retinal detachment", TriageLevel.LEVEL_3_SEMI_URGENT, "Ophthalmology", 55);
        addPattern("cholecystectomy", TriageLevel.LEVEL_3_SEMI_URGENT, "General Surgery", 50);
        addPattern("cholelithiasis", TriageLevel.LEVEL_3_SEMI_URGENT, "General Surgery", 48);
        addPattern("disc herniation", TriageLevel.LEVEL_3_SEMI_URGENT, "Neurosurgery", 52);
        addPattern("meniscal tear", TriageLevel.LEVEL_3_SEMI_URGENT, "Orthopedics", 45);
        addPattern("carpal tunnel", TriageLevel.LEVEL_3_SEMI_URGENT, "Orthopedics", 40);

        // Level 4: Elective
        addPattern("inguinal hernia", TriageLevel.LEVEL_4_ELECTIVE, "General Surgery", 30);
        addPattern("knee replacement", TriageLevel.LEVEL_4_ELECTIVE, "Orthopedics", 25);
        addPattern("hip replacement", TriageLevel.LEVEL_4_ELECTIVE, "Orthopedics", 26);
        addPattern("cataract extraction", TriageLevel.LEVEL_4_ELECTIVE, "Ophthalmology", 20);
        addPattern("phacoemulsification", TriageLevel.LEVEL_4_ELECTIVE, "Ophthalmology", 20);
        addPattern("rhinoplasty", TriageLevel.LEVEL_4_ELECTIVE, "Plastic Surgery", 15);
        addPattern("tonsillectomy", TriageLevel.LEVEL_4_ELECTIVE, "ENT", 22);
    }
}
