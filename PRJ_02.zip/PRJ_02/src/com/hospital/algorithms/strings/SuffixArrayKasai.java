package com.hospital.algorithms.strings;

/**
 * Suffix Array construction in O(n log^2 n) and Longest Common Prefix (LCP) array
 * in linear time O(n) via Kasai's algorithm.
 * Used for clinical record similarity and longest common diagnostic phrase extraction.
 */
public class SuffixArrayKasai {

    private static class SuffixRank implements Comparable<SuffixRank> {
        int index;
        int rank0;
        int rank1;

        SuffixRank(int index, int rank0, int rank1) {
            this.index = index;
            this.rank0 = rank0;
            this.rank1 = rank1;
        }

        @Override
        public int compareTo(SuffixRank o) {
            if (this.rank0 != o.rank0) return Integer.compare(this.rank0, o.rank0);
            return Integer.compare(this.rank1, o.rank1);
        }
    }

    public static int[] buildSuffixArray(String text) {
        int n = text.length();
        SuffixRank[] suffixes = new SuffixRank[n];

        for (int i = 0; i < n; i++) {
            suffixes[i] = new SuffixRank(i, text.charAt(i), (i + 1 < n) ? text.charAt(i + 1) : -1);
        }

        quickSortSuffixes(suffixes, 0, n - 1);

        int[] ind = new int[n];
        for (int k = 4; k < 2 * n; k *= 2) {
            int rank = 0;
            int prevRank = suffixes[0].rank0;
            suffixes[0].rank0 = rank;
            ind[suffixes[0].index] = 0;

            for (int i = 1; i < n; i++) {
                if (suffixes[i].rank0 == prevRank && suffixes[i].rank1 == suffixes[i - 1].rank1) {
                    prevRank = suffixes[i].rank0;
                    suffixes[i].rank0 = rank;
                } else {
                    prevRank = suffixes[i].rank0;
                    suffixes[i].rank0 = ++rank;
                }
                ind[suffixes[i].index] = i;
            }

            for (int i = 0; i < n; i++) {
                int nextIndex = suffixes[i].index + k / 2;
                suffixes[i].rank1 = (nextIndex < n) ? suffixes[ind[nextIndex]].rank0 : -1;
            }

            quickSortSuffixes(suffixes, 0, n - 1);
        }

        int[] sa = new int[n];
        for (int i = 0; i < n; i++) {
            sa[i] = suffixes[i].index;
        }
        return sa;
    }

    public static int[] computeLCP(String text, int[] sa) {
        int n = text.length();
        int[] lcp = new int[n];
        int[] invSa = new int[n];

        for (int i = 0; i < n; i++) {
            invSa[sa[i]] = i;
        }

        int k = 0;
        for (int i = 0; i < n; i++) {
            if (invSa[i] == n - 1) {
                k = 0;
                continue;
            }
            int j = sa[invSa[i] + 1];
            while (i + k < n && j + k < n && text.charAt(i + k) == text.charAt(j + k)) {
                k++;
            }
            lcp[invSa[i]] = k;
            if (k > 0) {
                k--;
            }
        }
        return lcp;
    }

    public static String longestCommonSubstring(String s1, String s2) {
        String combined = s1 + "#" + s2 + "$";
        int n = combined.length();
        int[] sa = buildSuffixArray(combined);
        int[] lcp = computeLCP(combined, sa);

        int maxLen = 0;
        int startIdx = 0;

        for (int i = 0; i < n - 1; i++) {
            boolean fromS1First = sa[i] < s1.length();
            boolean fromS1Second = sa[i + 1] < s1.length();

            if (fromS1First != fromS1Second) {
                if (lcp[i] > maxLen) {
                    maxLen = lcp[i];
                    startIdx = sa[i];
                }
            }
        }

        if (maxLen == 0) return "";
        return combined.substring(startIdx, startIdx + maxLen);
    }

    private static void quickSortSuffixes(SuffixRank[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSortSuffixes(arr, low, pi - 1);
            quickSortSuffixes(arr, pi + 1, high);
        }
    }

    private static int partition(SuffixRank[] arr, int low, int high) {
        SuffixRank pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr[j].compareTo(pivot) < 0) {
                i++;
                SuffixRank temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        SuffixRank temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}
