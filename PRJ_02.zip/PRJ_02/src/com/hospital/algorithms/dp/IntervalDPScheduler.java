package com.hospital.algorithms.dp;

import com.hospital.ds.CustomArrayList;

/**
 * Interval Dynamic Programming Scheduler for Weighted Interval Scheduling with Deadlines.
 * Finds maximal clinical utility slot assignment in O(n log n) time.
 */
public class IntervalDPScheduler {

    public static class IntervalJob implements Comparable<IntervalJob> {
        public String id;
        public int start;
        public int finish;
        public int weight; // Priority/utility weight

        public IntervalJob(String id, int start, int finish, int weight) {
            this.id = id;
            this.start = start;
            this.finish = finish;
            this.weight = weight;
        }

        @Override
        public int compareTo(IntervalJob o) {
            return Integer.compare(this.finish, o.finish);
        }
    }

    public static CustomArrayList<IntervalJob> scheduleMaxWeight(CustomArrayList<IntervalJob> jobs) {
        int n = jobs.size();
        if (n == 0) return new CustomArrayList<>();

        // Sort by finish times using manual quicksort
        IntervalJob[] arr = new IntervalJob[n];
        for (int i = 0; i < n; i++) arr[i] = jobs.get(i);
        quickSortJobs(arr, 0, n - 1);

        int[] dp = new int[n];
        int[] parent = new int[n];
        int[] p = new int[n]; // latest compatible job index

        // Find p[i] using binary search
        for (int i = 0; i < n; i++) {
            p[i] = binarySearchLatestCompatible(arr, i);
        }

        dp[0] = arr[0].weight;
        parent[0] = -1;

        for (int i = 1; i < n; i++) {
            int inclWeight = arr[i].weight;
            if (p[i] != -1) {
                inclWeight += dp[p[i]];
            }

            if (inclWeight > dp[i - 1]) {
                dp[i] = inclWeight;
                parent[i] = p[i];
            } else {
                dp[i] = dp[i - 1];
                parent[i] = -2; // flag for take previous
            }
        }

        // Reconstruct selected jobs
        CustomArrayList<IntervalJob> selected = new CustomArrayList<>();
        int curr = n - 1;
        while (curr >= 0) {
            if (parent[curr] == -2) {
                curr--;
            } else {
                selected.add(arr[curr]);
                curr = p[curr];
            }
        }

        return selected;
    }

    private static int binarySearchLatestCompatible(IntervalJob[] jobs, int index) {
        int low = 0, high = index - 1;
        int result = -1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            if (jobs[mid].finish <= jobs[index].start) {
                result = mid;
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return result;
    }

    private static void quickSortJobs(IntervalJob[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSortJobs(arr, low, pi - 1);
            quickSortJobs(arr, pi + 1, high);
        }
    }

    private static int partition(IntervalJob[] arr, int low, int high) {
        IntervalJob pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j].compareTo(pivot) <= 0) {
                i++;
                IntervalJob temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        IntervalJob temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}
