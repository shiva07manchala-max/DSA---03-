package com.hospital.algorithms.dp;

import com.hospital.ds.CustomArrayList;

/**
 * Bitmask Dynamic Programming for Minimizing OR Setup & Sterilization Turnaround Time.
 * Formulated as Traveling Salesperson Problem (TSP) with state compression.
 * Time Complexity: O(n^2 * 2^n), Space Complexity: O(n * 2^n).
 */
public class BitmaskTurnaroundDP {

    public static class TSPResult {
        public int minCost;
        public int[] optimalOrder;

        public TSPResult(int minCost, int[] optimalOrder) {
            this.minCost = minCost;
            this.optimalOrder = optimalOrder;
        }
    }

    public static TSPResult solveOptimalSequence(int[][] costMatrix) {
        int n = costMatrix.length;
        if (n == 0) return new TSPResult(0, new int[0]);
        if (n == 1) return new TSPResult(0, new int[]{0});

        int numStates = 1 << n;
        int[][] dp = new int[numStates][n];
        int[][] parent = new int[numStates][n];

        final int INF = 1_000_000_000;

        for (int i = 0; i < numStates; i++) {
            for (int j = 0; j < n; j++) {
                dp[i][j] = INF;
                parent[i][j] = -1;
            }
        }

        // Base cases: starting at each possible first procedure
        for (int i = 0; i < n; i++) {
            dp[1 << i][i] = 0;
        }

        // DP State transitions
        for (int mask = 1; mask < numStates; mask++) {
            for (int u = 0; u < n; u++) {
                if ((mask & (1 << u)) == 0 || dp[mask][u] >= INF) continue;

                for (int v = 0; v < n; v++) {
                    if ((mask & (1 << v)) == 0) {
                        int nextMask = mask | (1 << v);
                        int newCost = dp[mask][u] + costMatrix[u][v];
                        if (newCost < dp[nextMask][v]) {
                            dp[nextMask][v] = newCost;
                            parent[nextMask][v] = u;
                        }
                    }
                }
            }
        }

        // Find minimal final cost at full mask (1 << n) - 1
        int finalMask = numStates - 1;
        int bestEnd = 0;
        int minTotalCost = INF;

        for (int i = 0; i < n; i++) {
            if (dp[finalMask][i] < minTotalCost) {
                minTotalCost = dp[finalMask][i];
                bestEnd = i;
            }
        }

        // Reconstruct path
        int[] path = new int[n];
        int currMask = finalMask;
        int currNode = bestEnd;

        for (int step = n - 1; step >= 0; step--) {
            path[step] = currNode;
            int prev = parent[currMask][currNode];
            currMask ^= (1 << currNode);
            currNode = prev;
        }

        return new TSPResult(minTotalCost, path);
    }
}
