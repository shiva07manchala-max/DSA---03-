package com.hospital.algorithms.randomparallel;

import com.hospital.model.Patient;

/**
 * Las Vegas Randomized QuickSort with uniform random pivot selection.
 * Expected running time: O(n log n) with zero adversarial worst-case vulnerability.
 */
public class RandomizedQuickSort {

    public static void sortPatients(Patient[] arr) {
        if (arr == null || arr.length <= 1) return;
        randomizedQuickSort(arr, 0, arr.length - 1);
    }

    private static void randomizedQuickSort(Patient[] arr, int low, int high) {
        if (low < high) {
            int pi = randomizedPartition(arr, low, high);
            randomizedQuickSort(arr, low, pi - 1);
            randomizedQuickSort(arr, pi + 1, high);
        }
    }

    private static int randomizedPartition(Patient[] arr, int low, int high) {
        int randIdx = low + (int) (Math.random() * (high - low + 1));
        Patient temp = arr[randIdx];
        arr[randIdx] = arr[high];
        arr[high] = temp;
        return partition(arr, low, high);
    }

    private static int partition(Patient[] arr, int low, int high) {
        Patient pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j].compareTo(pivot) <= 0) {
                i++;
                Patient temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        Patient temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}
