package com.hospital.algorithms.randomparallel;

/**
 * Parallel Prefix Sum (Blelloch Scan) algorithm and Work-Span Analysis model.
 * Work T_1 = O(n), Span T_infinity = O(log n), Achievable Parallel Speedup = T_1 / T_infinity.
 */
public class ParallelPrefixSum {

    public static int[] computePrefixSumSequential(int[] arr) {
        int n = arr.length;
        int[] prefix = new int[n];
        if (n == 0) return prefix;
        prefix[0] = arr[0];
        for (int i = 1; i < n; i++) {
            prefix[i] = prefix[i - 1] + arr[i];
        }
        return prefix;
    }

    /**
     * Blelloch Scan: Up-Sweep (Reduce) followed by Down-Sweep to compute exclusive prefix sums.
     */
    public static int[] blellochScanExclusive(int[] arr) {
        int n = arr.length;
        if (n == 0) return new int[0];

        // Pad to next power of 2
        int m = 1;
        while (m < n) m <<= 1;

        int[] tree = new int[m];
        for (int i = 0; i < n; i++) tree[i] = arr[i];

        // 1. Up-Sweep (Parallel Reduce)
        for (int d = 0; d < log2(m); d++) {
            int step = 1 << (d + 1);
            int half = 1 << d;
            for (int k = 0; k < m; k += step) {
                tree[k + step - 1] += tree[k + half - 1];
            }
        }

        // Set root to 0 for exclusive scan
        tree[m - 1] = 0;

        // 2. Down-Sweep
        for (int d = log2(m) - 1; d >= 0; d--) {
            int step = 1 << (d + 1);
            int half = 1 << d;
            for (int k = 0; k < m; k += step) {
                int t = tree[k + half - 1];
                tree[k + half - 1] = tree[k + step - 1];
                tree[k + step - 1] += t;
            }
        }

        int[] result = new int[n];
        for (int i = 0; i < n; i++) result[i] = tree[i];
        return result;
    }

    private static int log2(int val) {
        int res = 0;
        while ((1 << res) < val) res++;
        return res;
    }
}
