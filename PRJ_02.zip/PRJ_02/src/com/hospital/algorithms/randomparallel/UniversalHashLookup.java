package com.hospital.algorithms.randomparallel;

/**
 * Universal Hashing Family implementation for probabilistic collision reduction.
 * Family: h_{a,b}(k) = ((a*k + b) mod p) mod m, where p is prime > m.
 */
public class UniversalHashLookup {
    private final long a;
    private final long b;
    private final long p; // Large prime
    private final int m;  // Table size

    public UniversalHashLookup(int tableSize) {
        this.m = tableSize;
        this.p = 1_000_000_007L;
        this.a = 1 + (long) (Math.random() * (p - 1));
        this.b = (long) (Math.random() * p);
    }

    public int hash(long key) {
        long nonNegativeKey = (key < 0) ? -key : key;
        long val = ((a * (nonNegativeKey % p) + b) % p);
        return (int) (val % m);
    }

    public int hashString(String key) {
        if (key == null) return 0;
        long h = 0;
        for (int i = 0; i < key.length(); i++) {
            h = (h * 31 + key.charAt(i)) % p;
        }
        return hash(h);
    }
}
