package com.hospital.algorithms.randomparallel;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.Patient;

/**
 * Reservoir Sampling (Algorithm R) for streaming emergency patient arrivals.
 * Selects k random samples uniformly from an unbounded stream in O(n) time and O(k) memory.
 */
public class ReservoirSampler {

    public static CustomArrayList<Patient> sampleStream(CustomArrayList<Patient> stream, int k) {
        CustomArrayList<Patient> reservoir = new CustomArrayList<>(k);
        int n = stream.size();
        if (n == 0 || k <= 0) return reservoir;

        // Fill reservoir with first k elements
        for (int i = 0; i < Math.min(k, n); i++) {
            reservoir.add(stream.get(i));
        }

        // Process remaining elements
        for (int i = k; i < n; i++) {
            int j = (int) (Math.random() * (i + 1));
            if (j < k) {
                reservoir.set(j, stream.get(i));
            }
        }

        return reservoir;
    }
}
