package com.hospital.algorithms.randomparallel;

/**
 * Work-Span Performance Model & Brent's Theorem Speedup Estimator.
 * Brent's Theorem: T_p <= T_1 / p + T_infinity.
 */
public class WorkSpanAnalyzer {

    public static class ParallelMetrics {
        public long work;            // T_1
        public long span;            // T_infinity
        public double parallelism;   // T_1 / T_infinity
        public double[] speedupAtProcessors;

        public ParallelMetrics(long work, long span, double parallelism, double[] speedupAtProcessors) {
            this.work = work;
            this.span = span;
            this.parallelism = parallelism;
            this.speedupAtProcessors = speedupAtProcessors;
        }
    }

    public static ParallelMetrics analyzeTask(int n, String taskName) {
        long work = 0;
        long span = 0;

        if ("PrefixScan".equalsIgnoreCase(taskName)) {
            work = 2L * n;
            span = (long) (2.0 * (Math.log(n) / Math.log(2)));
        } else if ("QuickSort".equalsIgnoreCase(taskName)) {
            work = (long) (n * (Math.log(n) / Math.log(2)));
            span = (long) Math.pow(Math.log(n) / Math.log(2), 2);
        } else if ("Reduce".equalsIgnoreCase(taskName)) {
            work = n;
            span = (long) (Math.log(n) / Math.log(2));
        } else {
            work = n;
            span = 1;
        }

        if (span == 0) span = 1;
        double parallelism = (double) work / span;

        int[] procCounts = new int[]{1, 2, 4, 8, 16, 32, 64};
        double[] speedups = new double[procCounts.length];

        for (int i = 0; i < procCounts.length; i++) {
            int p = procCounts[i];
            double tp = ((double) work / p) + span;
            speedups[i] = (double) work / tp;
        }

        return new ParallelMetrics(work, span, parallelism, speedups);
    }
}
