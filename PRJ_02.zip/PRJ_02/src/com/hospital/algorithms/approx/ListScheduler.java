package com.hospital.algorithms.approx;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomMinHeap;
import com.hospital.model.OperatingRoom;
import com.hospital.model.Patient;

/**
 * Standard List Scheduling (Online heuristic) with 2 - 1/m approximation guarantee.
 */
public class ListScheduler {

    public static int computeListMakespan(CustomArrayList<Patient> patients, int numRooms) {
        if (patients.isEmpty() || numRooms <= 0) return 0;

        int[] roomLoads = new int[numRooms];
        for (int i = 0; i < patients.size(); i++) {
            Patient p = patients.get(i);
            int minIdx = 0;
            for (int r = 1; r < numRooms; r++) {
                if (roomLoads[r] < roomLoads[minIdx]) {
                    minIdx = r;
                }
            }
            roomLoads[minIdx] += p.getEstimatedDurationMinutes();
        }

        int makespan = 0;
        for (int load : roomLoads) {
            if (load > makespan) makespan = load;
        }
        return makespan;
    }
}
