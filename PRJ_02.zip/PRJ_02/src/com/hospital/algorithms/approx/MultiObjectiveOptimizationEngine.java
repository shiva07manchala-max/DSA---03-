package com.hospital.algorithms.approx;

import com.hospital.algorithms.randomparallel.RandomizedQuickSort;
import com.hospital.ds.CustomArrayList;
import com.hospital.model.OperatingRoom;
import com.hospital.model.Patient;
import com.hospital.model.ScheduleSlot;
import com.hospital.model.Surgeon;
import com.hospital.model.TriageLevel;

/**
 * Multi-Objective Scheduling Optimization Engine.
 * Supports Graham's LPT, Weighted Shortest Processing Time (WSPT),
 * Earliest Due Date (EDD) Tardiness Minimization, and Variance-Minimized Load Balancing.
 */
public class MultiObjectiveOptimizationEngine {

    public enum SchedulingStrategy {
        GRAHAM_LPT("Graham LPT 4/3-Approximation", "Minimizes global makespan C_max"),
        WEIGHTED_SPT("Weighted Shortest Processing Time", "Minimizes weighted sum of completion times sum(w_j * C_j)"),
        EARLIEST_DUE_DATE("Earliest Due Date (EDD)", "Minimizes maximum clinical tardiness L_max"),
        LOAD_BALANCED("Variance-Minimized Load Balancer", "Minimizes variance and standard deviation across OR suites");

        private final String displayName;
        private final String description;

        SchedulingStrategy(String displayName, String description) {
            this.displayName = displayName;
            this.description = description;
        }

        public String getDisplayName() { return displayName; }
        public String getDescription() { return description; }
    }

    public static class MultiObjectiveResult {
        public SchedulingStrategy strategy;
        public int makespanMinutes;
        public int totalIdleMinutes;
        public int totalTardinessMinutes;
        public double loadStandardDeviation;
        public double orUtilizationPercentage;
        public CustomArrayList<ScheduleSlot> assignedSlots;
        public int emergencyHandledCount;

        public MultiObjectiveResult(SchedulingStrategy strategy) {
            this.strategy = strategy;
            this.assignedSlots = new CustomArrayList<>();
        }
    }

    public static MultiObjectiveResult optimize(CustomArrayList<Patient> patients,
                                                CustomArrayList<OperatingRoom> rooms,
                                                CustomArrayList<Surgeon> surgeons,
                                                int startMinute,
                                                SchedulingStrategy strategy) {
        if (patients == null || rooms == null || rooms.isEmpty()) {
            return new MultiObjectiveResult(strategy);
        }

        CustomArrayList<Patient> orderedPatients = sortPatientsByStrategy(patients, strategy);
        MultiObjectiveResult result = new MultiObjectiveResult(strategy);

        int m = rooms.size();
        int[] roomEndTimes = new int[m];
        for (int i = 0; i < m; i++) {
            roomEndTimes[i] = startMinute;
            rooms.get(i).clearSlots();
        }

        int totalOpTime = 0;
        int totalTardiness = 0;
        int emergencies = 0;

        for (int pIdx = 0; pIdx < orderedPatients.size(); pIdx++) {
            Patient p = orderedPatients.get(pIdx);
            boolean isEmergency = p.getTriageLevel().getLevel() <= 1;
            if (p.getTriageLevel().getLevel() <= 2) emergencies++;

            // Select eligible operating room based on strategy
            int bestRoomIdx = -1;
            int earliestAvailable = Integer.MAX_VALUE;

            for (int r = 0; r < m; r++) {
                OperatingRoom room = rooms.get(r);
                boolean isEligible = room.supportsSpecialty(p.getRequiredProcedure());
                if (isEmergency && !room.isEmergencyCapable()) {
                    // Prefer emergency capable suites for level 1
                    continue;
                }

                if (isEligible || room.isEmergencyCapable()) {
                    if (roomEndTimes[r] < earliestAvailable) {
                        earliestAvailable = roomEndTimes[r];
                        bestRoomIdx = r;
                    }
                }
            }

            if (bestRoomIdx == -1) {
                // Fallback to least loaded room
                earliestAvailable = Integer.MAX_VALUE;
                for (int r = 0; r < m; r++) {
                    if (roomEndTimes[r] < earliestAvailable) {
                        earliestAvailable = roomEndTimes[r];
                        bestRoomIdx = r;
                    }
                }
            }

            OperatingRoom chosenRoom = rooms.get(bestRoomIdx);
            int slotStart = Math.max(roomEndTimes[bestRoomIdx], startMinute);
            int slotEnd = slotStart + p.getEstimatedDurationMinutes();

            // Find matching certified surgeon
            Surgeon assignedSurgeon = findSurgeon(surgeons, p.getRequiredProcedure(), p.getEstimatedDurationMinutes());
            String surgeonId = (assignedSurgeon != null) ? assignedSurgeon.getId() : "DOC-GEN";
            String surgeonName = (assignedSurgeon != null) ? assignedSurgeon.getName() : "On-Call Surgical Team";

            int turnaround = isEmergency ? 15 : 25;

            ScheduleSlot slot = new ScheduleSlot(
                    "SLOT-" + (pIdx + 1),
                    chosenRoom.getId(),
                    p.getId(),
                    p.getName(),
                    p.getRequiredProcedure(),
                    surgeonId,
                    surgeonName,
                    p.getTriageLevel(),
                    slotStart,
                    slotEnd,
                    turnaround,
                    isEmergency
            );

            chosenRoom.addSlot(slot);
            result.assignedSlots.add(slot);

            // Compute tardiness relative to clinical deadline
            int tardiness = Math.max(0, slotEnd - p.getDeadlineMinutes());
            totalTardiness += tardiness;
            totalOpTime += p.getEstimatedDurationMinutes();

            roomEndTimes[bestRoomIdx] = slotEnd + turnaround;
        }

        // Compute metrics
        int maxEnd = startMinute;
        int minEnd = Integer.MAX_VALUE;
        double sumEnd = 0;

        for (int r = 0; r < m; r++) {
            if (roomEndTimes[r] > maxEnd) maxEnd = roomEndTimes[r];
            if (roomEndTimes[r] < minEnd) minEnd = roomEndTimes[r];
            sumEnd += roomEndTimes[r];
        }

        result.makespanMinutes = maxEnd;
        result.totalIdleMinutes = (maxEnd * m) - (startMinute * m) - totalOpTime;
        result.totalTardinessMinutes = totalTardiness;
        result.emergencyHandledCount = emergencies;

        double meanLoad = sumEnd / m;
        double varianceSum = 0;
        for (int r = 0; r < m; r++) {
            varianceSum += Math.pow(roomEndTimes[r] - meanLoad, 2);
        }
        result.loadStandardDeviation = Math.sqrt(varianceSum / m);

        int totalAvailableORMinutes = Math.max(1, m * result.makespanMinutes);
        result.orUtilizationPercentage = Math.min(100.0, ((double) totalOpTime / totalAvailableORMinutes) * 100.0);

        return result;
    }

    private static CustomArrayList<Patient> sortPatientsByStrategy(CustomArrayList<Patient> patients, SchedulingStrategy strategy) {
        Patient[] arr = new Patient[patients.size()];
        for (int i = 0; i < patients.size(); i++) arr[i] = patients.get(i);

        switch (strategy) {
            case GRAHAM_LPT:
                for (int i = 0; i < arr.length - 1; i++) {
                    for (int j = 0; j < arr.length - i - 1; j++) {
                        int urgA = arr[j].getTriageLevel().getLevel();
                        int urgB = arr[j + 1].getTriageLevel().getLevel();
                        if (urgA > urgB || (urgA == urgB && arr[j].getEstimatedDurationMinutes() < arr[j + 1].getEstimatedDurationMinutes())) {
                            Patient temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
                break;

            case WEIGHTED_SPT:
                for (int i = 0; i < arr.length - 1; i++) {
                    for (int j = 0; j < arr.length - i - 1; j++) {
                        double ratioA = (double) arr[j].getEstimatedDurationMinutes() / Math.max(1, (5 - arr[j].getTriageLevel().getLevel()));
                        double ratioB = (double) arr[j + 1].getEstimatedDurationMinutes() / Math.max(1, (5 - arr[j + 1].getTriageLevel().getLevel()));
                        if (ratioA > ratioB) {
                            Patient temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
                break;

            case EARLIEST_DUE_DATE:
                for (int i = 0; i < arr.length - 1; i++) {
                    for (int j = 0; j < arr.length - i - 1; j++) {
                        if (arr[j].getDeadlineMinutes() > arr[j + 1].getDeadlineMinutes()) {
                            Patient temp = arr[j];
                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
                break;

            case LOAD_BALANCED:
            default:
                RandomizedQuickSort.sortPatients(arr);
                break;
        }

        CustomArrayList<Patient> list = new CustomArrayList<>();
        for (Patient p : arr) list.add(p);
        return list;
    }

    private static Surgeon findSurgeon(CustomArrayList<Surgeon> surgeons, String procedure, int duration) {
        if (surgeons == null) return null;
        for (int i = 0; i < surgeons.size(); i++) {
            Surgeon s = surgeons.get(i);
            if (s.canPerform(procedure) && s.hasAvailableCapacity(duration)) {
                return s;
            }
        }
        return null;
    }
}
