package com.hospital.algorithms.approx;

import com.hospital.ds.CustomArrayList;

/**
 * Vertex Cover 2-Approximation Algorithm via Maximal Matching.
 * Guarantees |C| <= 2 * |C_opt|.
 * Applied to resolve shared surgical equipment / anesthesia workstation conflict graphs.
 */
public class VertexCover2Approximation {

    public static class Edge {
        public int u;
        public int v;
        public String uLabel;
        public String vLabel;

        public Edge(int u, int v, String uLabel, String vLabel) {
            this.u = u;
            this.v = v;
            this.uLabel = uLabel;
            this.vLabel = vLabel;
        }
    }

    public static class VertexCoverResult {
        public CustomArrayList<Integer> coverVertexIndices;
        public CustomArrayList<String> coverLabels;
        public int size;

        public VertexCoverResult(CustomArrayList<Integer> coverVertexIndices, CustomArrayList<String> coverLabels) {
            this.coverVertexIndices = coverVertexIndices;
            this.coverLabels = coverLabels;
            this.size = coverVertexIndices.size();
        }
    }

    public static VertexCoverResult compute2ApproxVertexCover(int numVertices, CustomArrayList<Edge> edges, String[] labels) {
        boolean[] inCover = new boolean[numVertices];
        boolean[] edgeProcessed = new boolean[edges.size()];

        CustomArrayList<Integer> cover = new CustomArrayList<>();
        CustomArrayList<String> coverLabels = new CustomArrayList<>();

        // Greedy maximal matching: pick un-covered edge and add both endpoints
        for (int i = 0; i < edges.size(); i++) {
            if (edgeProcessed[i]) continue;
            Edge e = edges.get(i);

            if (!inCover[e.u] && !inCover[e.v]) {
                inCover[e.u] = true;
                inCover[e.v] = true;
                cover.add(e.u);
                cover.add(e.v);

                if (labels != null && e.u < labels.length) coverLabels.add(labels[e.u]);
                else coverLabels.add("Vertex-" + e.u);

                if (labels != null && e.v < labels.length) coverLabels.add(labels[e.v]);
                else coverLabels.add("Vertex-" + e.v);

                // Mark all edges incident on u or v as covered
                for (int j = 0; j < edges.size(); j++) {
                    Edge other = edges.get(j);
                    if (other.u == e.u || other.v == e.u || other.u == e.v || other.v == e.v) {
                        edgeProcessed[j] = true;
                    }
                }
            }
        }

        return new VertexCoverResult(cover, coverLabels);
    }
}
