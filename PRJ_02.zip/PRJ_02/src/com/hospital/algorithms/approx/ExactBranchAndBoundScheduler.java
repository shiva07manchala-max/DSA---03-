package com.hospital.algorithms.approx;

import com.hospital.ds.CustomArrayList;
import com.hospital.model.Patient;

/**
 * Exact Branch-and-Bound / Depth-First Pruning Scheduler for P || C_max.
 * Computes exact optimal makespan using lower bound pruning (max load and average work lower bounds).
 * Used as the ground truth reference to verify approximation quality in benchmark tests.
 */
public class ExactBranchAndBoundScheduler {

    private static int bestMakespan;

    public static int computeOptimalMakespan(CustomArrayList<Patient> patients, int numRooms) {
        int n = patients.size();
        if (n == 0 || numRooms <= 0) return 0;

        int[] durations = new int[n];
        int totalWork = 0;
        int maxDuration = 0;

        for (int i = 0; i < n; i++) {
            durations[i] = patients.get(i).getEstimatedDurationMinutes();
            totalWork += durations[i];
            if (durations[i] > maxDuration) maxDuration = durations[i];
        }

        // Sort descending to maximize branch pruning efficiency
        quickSortDesc(durations, 0, n - 1);

        int lowerBound = Math.max(maxDuration, (totalWork + numRooms - 1) / numRooms);
        bestMakespan = Integer.MAX_VALUE;

        // Upper bound heuristic using greedy list scheduling
        int[] greedyLoads = new int[numRooms];
        for (int d : durations) {
            int minIdx = 0;
            for (int r = 1; r < numRooms; r++) {
                if (greedyLoads[r] < greedyLoads[minIdx]) minIdx = r;
            }
            greedyLoads[minIdx] += d;
        }
        for (int load : greedyLoads) {
            if (load > bestMakespan || bestMakespan == Integer.MAX_VALUE) bestMakespan = load;
        }

        int[] roomLoads = new int[numRooms];
        branchAndBoundDFS(0, durations, roomLoads, numRooms, lowerBound);

        return bestMakespan;
    }

    private static void branchAndBoundDFS(int jobIndex, int[] durations, int[] roomLoads, int numRooms, int lowerBound) {
        if (jobIndex == durations.length) {
            int currentMax = 0;
            for (int load : roomLoads) {
                if (load > currentMax) currentMax = load;
            }
            if (currentMax < bestMakespan) {
                bestMakespan = currentMax;
            }
            return;
        }

        int d = durations[jobIndex];

        for (int r = 0; r < numRooms; r++) {
            // Prune: if adding this job exceeds the currently best makespan, prune branch
            if (roomLoads[r] + d >= bestMakespan) continue;

            roomLoads[r] += d;
            branchAndBoundDFS(jobIndex + 1, durations, roomLoads, numRooms, lowerBound);
            roomLoads[r] -= d;

            if (bestMakespan == lowerBound) {
                return; // Early termination: reached theoretical lower bound
            }

            // Symmetry breaking: do not explore identical empty rooms
            if (roomLoads[r] == 0) break;
        }
    }

    private static void quickSortDesc(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSortDesc(arr, low, pi - 1);
            quickSortDesc(arr, pi + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] >= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}
