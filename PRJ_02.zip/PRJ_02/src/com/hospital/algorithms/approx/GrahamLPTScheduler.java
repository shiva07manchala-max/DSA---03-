package com.hospital.algorithms.approx;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomMinHeap;
import com.hospital.model.OperatingRoom;
import com.hospital.model.Patient;
import com.hospital.model.ScheduleSlot;
import com.hospital.model.Surgeon;

/**
 * Graham's Longest Processing Time (LPT) 4/3-Approximation Algorithm
 * for NP-hard Parallel Machine Makespan Minimization (P || C_max).
 * Guarantee: C_max(LPT) <= (4/3 - 1/(3m)) * C_max(OPT).
 */
public class GrahamLPTScheduler {

    public static class MachineLoad implements Comparable<MachineLoad> {
        public OperatingRoom room;
        public int currentLoadMinutes;

        public MachineLoad(OperatingRoom room) {
            this.room = room;
            this.currentLoadMinutes = 0;
        }

        @Override
        public int compareTo(MachineLoad o) {
            return Integer.compare(this.currentLoadMinutes, o.currentLoadMinutes);
        }
    }

    public static class ScheduleOutput {
        public int makespan;
        public int totalIdleMinutes;
        public double approximationBoundRatio;
        public CustomArrayList<ScheduleSlot> assignedSlots;

        public ScheduleOutput(int makespan, int totalIdleMinutes, double approximationBoundRatio, CustomArrayList<ScheduleSlot> assignedSlots) {
            this.makespan = makespan;
            this.totalIdleMinutes = totalIdleMinutes;
            this.approximationBoundRatio = approximationBoundRatio;
            this.assignedSlots = assignedSlots;
        }
    }

    public static ScheduleOutput scheduleLPT(CustomArrayList<Patient> patients,
                                             CustomArrayList<OperatingRoom> rooms,
                                             CustomArrayList<Surgeon> surgeons,
                                             int startDayMinute) {
        int n = patients.size();
        int m = rooms.size();
        if (n == 0 || m == 0) {
            return new ScheduleOutput(0, 0, 1.0, new CustomArrayList<>());
        }

        // 1. Sort patients in non-increasing order of duration (LPT)
        Patient[] sortedPatients = new Patient[n];
        for (int i = 0; i < n; i++) sortedPatients[i] = patients.get(i);
        quickSortPatientsByDurationDesc(sortedPatients, 0, n - 1);

        // 2. Clear previous slots from rooms
        for (int i = 0; i < m; i++) {
            rooms.get(i).clearSlots();
        }

        // 3. Min-Heap of Operating Rooms keyed by current completion time
        CustomMinHeap<MachineLoad> heap = new CustomMinHeap<>();
        for (int i = 0; i < m; i++) {
            heap.insert(new MachineLoad(rooms.get(i)));
        }

        CustomArrayList<ScheduleSlot> allSlots = new CustomArrayList<>();
        int slotCounter = 1;

        for (int i = 0; i < n; i++) {
            Patient p = sortedPatients[i];
            MachineLoad minMachine = heap.extractMin();

            // Find a qualified available surgeon
            Surgeon assignedSurgeon = findBestSurgeon(surgeons, p.getRequiredProcedure(), p.getEstimatedDurationMinutes());
            String surgeonName = assignedSurgeon != null ? assignedSurgeon.getName() : "On-Call General Specialist";
            String surgeonId = assignedSurgeon != null ? assignedSurgeon.getId() : "SURG-GEN";

            int startMin = startDayMinute + minMachine.currentLoadMinutes;
            int turnaround = (p.getTriageLevel().getLevel() <= 2) ? 15 : 25; // 15m for emergency, 25m elective
            int endMin = startMin + p.getEstimatedDurationMinutes();

            ScheduleSlot slot = new ScheduleSlot(
                    "SLOT-" + String.format("%03d", slotCounter++),
                    minMachine.room.getId(),
                    p.getId(),
                    p.getName(),
                    p.getRequiredProcedure(),
                    surgeonId,
                    surgeonName,
                    p.getTriageLevel(),
                    startMin,
                    endMin,
                    turnaround,
                    p.getTriageLevel().getLevel() <= 2
            );

            p.setAssignedOrId(minMachine.room.getId());
            p.setScheduledStartTime(startMin);

            minMachine.room.addSlot(slot);
            allSlots.add(slot);

            if (assignedSurgeon != null) {
                assignedSurgeon.addWorkload(p.getEstimatedDurationMinutes());
            }

            minMachine.currentLoadMinutes += p.getEstimatedDurationMinutes() + turnaround;
            heap.insert(minMachine);
        }

        // Calculate makespan and idle times
        int maxMakespan = 0;
        int totalSum = 0;
        for (int i = 0; i < m; i++) {
            int roomSpan = rooms.get(i).getTotalMakespanMinutes();
            if (roomSpan > maxMakespan) maxMakespan = roomSpan;
        }

        int totalIdle = 0;
        for (int i = 0; i < m; i++) {
            int idle = Math.max(0, maxMakespan - rooms.get(i).getTotalMakespanMinutes());
            rooms.get(i).setTotalIdleMinutes(idle);
            totalIdle += idle;
        }

        double approxRatio = 4.0 / 3.0 - (1.0 / (3.0 * m));
        return new ScheduleOutput(maxMakespan, totalIdle, approxRatio, allSlots);
    }

    private static Surgeon findBestSurgeon(CustomArrayList<Surgeon> surgeons, String procedure, int duration) {
        if (surgeons == null) return null;
        Surgeon best = null;
        int minWorkload = Integer.MAX_VALUE;

        for (int i = 0; i < surgeons.size(); i++) {
            Surgeon s = surgeons.get(i);
            if (s.canPerform(procedure) && s.hasAvailableCapacity(duration)) {
                if (s.getCurrentWorkloadMinutes() < minWorkload) {
                    minWorkload = s.getCurrentWorkloadMinutes();
                    best = s;
                }
            }
        }
        return best;
    }

    private static void quickSortPatientsByDurationDesc(Patient[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSortPatientsByDurationDesc(arr, low, pi - 1);
            quickSortPatientsByDurationDesc(arr, pi + 1, high);
        }
    }

    private static int partition(Patient[] arr, int low, int high) {
        // Sort highest priority first, then longest duration
        Patient pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            boolean shouldComeFirst;
            if (arr[j].getTriageLevel().getLevel() != pivot.getTriageLevel().getLevel()) {
                shouldComeFirst = arr[j].getTriageLevel().getLevel() < pivot.getTriageLevel().getLevel();
            } else {
                shouldComeFirst = arr[j].getEstimatedDurationMinutes() >= pivot.getEstimatedDurationMinutes();
            }

            if (shouldComeFirst) {
                i++;
                Patient temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        Patient temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }
}
