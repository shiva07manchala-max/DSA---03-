package com.hospital.algorithms.flow;

import com.hospital.ds.CustomQueue;

/**
 * Edmonds-Karp Max-Flow Algorithm using BFS to find shortest augmenting paths.
 * Complexity: O(V * E^2).
 */
public class EdmondsKarpMaxFlow {

    public static int computeMaxFlow(ResidualGraph graph, int source, int sink) {
        int n = graph.getNumVertices();
        int maxFlow = 0;

        while (true) {
            ResidualGraph.Edge[] parentEdge = new ResidualGraph.Edge[n];
            int[] parentNode = new int[n];
            for (int i = 0; i < n; i++) parentNode[i] = -1;

            CustomQueue<Integer> queue = new CustomQueue<>();
            queue.enqueue(source);
            parentNode[source] = source;

            while (!queue.isEmpty() && parentNode[sink] == -1) {
                int u = queue.dequeue();
                for (int i = 0; i < graph.getEdges(u).size(); i++) {
                    ResidualGraph.Edge edge = graph.getEdges(u).get(i);
                    int v = edge.v;
                    if (parentNode[v] == -1 && edge.residualCapacity() > 0) {
                        parentNode[v] = u;
                        parentEdge[v] = edge;
                        queue.enqueue(v);
                    }
                }
            }

            if (parentNode[sink] == -1) {
                break; // No more augmenting paths
            }

            int pushFlow = Integer.MAX_VALUE;
            int curr = sink;
            while (curr != source) {
                ResidualGraph.Edge edge = parentEdge[curr];
                pushFlow = Math.min(pushFlow, edge.residualCapacity());
                curr = parentNode[curr];
            }

            curr = sink;
            while (curr != source) {
                ResidualGraph.Edge edge = parentEdge[curr];
                edge.flow += pushFlow;
                ResidualGraph.Edge revEdge = graph.getEdges(edge.v).get(edge.rev);
                revEdge.flow -= pushFlow;
                curr = parentNode[curr];
            }

            maxFlow += pushFlow;
        }

        return maxFlow;
    }
}
