package com.hospital.algorithms.flow;

import com.hospital.ds.CustomArrayList;

/**
 * Residual Flow Network representation using adjacency lists with forward and reverse edges.
 */
public class ResidualGraph {
    public static class Edge {
        public int u;
        public int v;
        public int capacity;
        public int flow;
        public int cost;
        public int rev; // index of reverse edge in adj[v]

        public Edge(int u, int v, int capacity, int cost, int rev) {
            this.u = u;
            this.v = v;
            this.capacity = capacity;
            this.flow = 0;
            this.cost = cost;
            this.rev = rev;
        }

        public int residualCapacity() {
            return capacity - flow;
        }
    }

    private final int numVertices;
    private final CustomArrayList<Edge>[] adj;

    @SuppressWarnings("unchecked")
    public ResidualGraph(int numVertices) {
        this.numVertices = numVertices;
        this.adj = new CustomArrayList[numVertices];
        for (int i = 0; i < numVertices; i++) {
            adj[i] = new CustomArrayList<>();
        }
    }

    public void addEdge(int u, int v, int capacity) {
        addEdge(u, v, capacity, 0);
    }

    public void addEdge(int u, int v, int capacity, int cost) {
        if (u < 0 || u >= numVertices || v < 0 || v >= numVertices) {
            throw new IndexOutOfBoundsException("Vertex index out of bounds: " + u + " -> " + v);
        }
        int uIndex = adj[u].size();
        int vIndex = adj[v].size();

        Edge forward = new Edge(u, v, capacity, cost, vIndex);
        Edge backward = new Edge(v, u, 0, -cost, uIndex);

        adj[u].add(forward);
        adj[v].add(backward);
    }

    public int getNumVertices() {
        return numVertices;
    }

    public CustomArrayList<Edge> getEdges(int u) {
        return adj[u];
    }
}
