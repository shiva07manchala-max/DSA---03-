package com.hospital.algorithms.flow;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomQueue;

/**
 * Min-Cut Analyzer exploiting Max-Flow / Min-Cut Duality.
 * Identifies the exact bottleneck cut edges in the healthcare capacity network
 * (e.g. ICU beds shortage vs Operating Room saturation).
 */
public class MinCutAnalyzer {

    public static class CutEdge {
        public int u;
        public int v;
        public int capacity;
        public String description;

        public CutEdge(int u, int v, int capacity, String description) {
            this.u = u;
            this.v = v;
            this.capacity = capacity;
            this.description = description;
        }
    }

    public static class MinCutResult {
        public int minCutCapacity;
        public boolean[] sourceSet;
        public CustomArrayList<CutEdge> bottleneckEdges;

        public MinCutResult(int minCutCapacity, boolean[] sourceSet, CustomArrayList<CutEdge> bottleneckEdges) {
            this.minCutCapacity = minCutCapacity;
            this.sourceSet = sourceSet;
            this.bottleneckEdges = bottleneckEdges;
        }
    }

    public static MinCutResult findMinCut(ResidualGraph graph, int source, int sink, String[] nodeLabels) {
        // Step 1: Compute Max Flow first via Dinic
        int maxFlow = DinicMaxFlow.computeMaxFlow(graph, source, sink);

        // Step 2: Reachability BFS from source on residual graph
        int n = graph.getNumVertices();
        boolean[] visited = new boolean[n];
        CustomQueue<Integer> queue = new CustomQueue<>();

        visited[source] = true;
        queue.enqueue(source);

        while (!queue.isEmpty()) {
            int u = queue.dequeue();
            for (int i = 0; i < graph.getEdges(u).size(); i++) {
                ResidualGraph.Edge edge = graph.getEdges(u).get(i);
                if (edge.residualCapacity() > 0 && !visited[edge.v]) {
                    visited[edge.v] = true;
                    queue.enqueue(edge.v);
                }
            }
        }

        // Step 3: Extract saturated forward edges crossing cut from S to T
        CustomArrayList<CutEdge> cutEdges = new CustomArrayList<>();
        int cutCapacity = 0;

        for (int u = 0; u < n; u++) {
            if (visited[u]) {
                for (int i = 0; i < graph.getEdges(u).size(); i++) {
                    ResidualGraph.Edge edge = graph.getEdges(u).get(i);
                    if (!visited[edge.v] && edge.capacity > 0) {
                        String desc = (nodeLabels != null && u < nodeLabels.length && edge.v < nodeLabels.length)
                                ? nodeLabels[u] + " ➔ " + nodeLabels[edge.v]
                                : "Node " + u + " ➔ Node " + edge.v;
                        cutEdges.add(new CutEdge(u, edge.v, edge.capacity, desc));
                        cutCapacity += edge.capacity;
                    }
                }
            }
        }

        return new MinCutResult(cutCapacity, visited, cutEdges);
    }
}
