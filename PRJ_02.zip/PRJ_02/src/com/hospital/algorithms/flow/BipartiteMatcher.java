package com.hospital.algorithms.flow;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.Pair;

/**
 * Maximum Bipartite Matching using augmenting paths / Ford-Fulkerson reduction.
 * Used for assigning qualified Surgeons to specialized Operating Rooms.
 */
public class BipartiteMatcher {

    public static class MatchingResult {
        public int matchCount;
        public CustomArrayList<Pair<Integer, Integer>> matchedPairs; // (LeftNode, RightNode)

        public MatchingResult(int matchCount, CustomArrayList<Pair<Integer, Integer>> matchedPairs) {
            this.matchCount = matchCount;
            this.matchedPairs = matchedPairs;
        }
    }

    public static MatchingResult computeMaxMatching(int numLeft, int numRight, boolean[][] compatibility) {
        int source = 0;
        int sink = numLeft + numRight + 1;
        int totalNodes = sink + 1;

        ResidualGraph graph = new ResidualGraph(totalNodes);

        // Source to Left Partition
        for (int i = 0; i < numLeft; i++) {
            graph.addEdge(source, 1 + i, 1);
        }

        // Left Partition to Right Partition
        for (int i = 0; i < numLeft; i++) {
            for (int j = 0; j < numRight; j++) {
                if (compatibility[i][j]) {
                    graph.addEdge(1 + i, 1 + numLeft + j, 1);
                }
            }
        }

        // Right Partition to Sink
        for (int j = 0; j < numRight; j++) {
            graph.addEdge(1 + numLeft + j, sink, 1);
        }

        int maxFlow = DinicMaxFlow.computeMaxFlow(graph, source, sink);

        CustomArrayList<Pair<Integer, Integer>> pairs = new CustomArrayList<>();
        for (int i = 0; i < numLeft; i++) {
            int u = 1 + i;
            for (int e = 0; e < graph.getEdges(u).size(); e++) {
                ResidualGraph.Edge edge = graph.getEdges(u).get(e);
                if (edge.capacity > 0 && edge.flow == 1 && edge.v != source) {
                    int rightIndex = edge.v - (1 + numLeft);
                    pairs.add(new Pair<>(i, rightIndex));
                    break;
                }
            }
        }

        return new MatchingResult(maxFlow, pairs);
    }
}
