package com.hospital.algorithms.flow;

import com.hospital.ds.CustomQueue;

/**
 * Successive Shortest Path (SSP) Min-Cost Max-Flow algorithm using SPFA/Bellman-Ford.
 * Optimizes assignment with procedure costs and priority incentives.
 */
public class MinCostMaxFlow {

    public static class FlowCostResult {
        public int maxFlow;
        public int minCost;

        public FlowCostResult(int maxFlow, int minCost) {
            this.maxFlow = maxFlow;
            this.minCost = minCost;
        }
    }

    public static FlowCostResult computeMinCostMaxFlow(ResidualGraph graph, int source, int sink) {
        int n = graph.getNumVertices();
        int maxFlow = 0;
        int minCost = 0;

        int[] dist = new int[n];
        int[] parentNode = new int[n];
        ResidualGraph.Edge[] parentEdge = new ResidualGraph.Edge[n];
        boolean[] inQueue = new boolean[n];

        final int INF = 1_000_000_000;

        while (true) {
            for (int i = 0; i < n; i++) {
                dist[i] = INF;
                parentNode[i] = -1;
                inQueue[i] = false;
            }

            dist[source] = 0;
            CustomQueue<Integer> queue = new CustomQueue<>();
            queue.enqueue(source);
            inQueue[source] = true;

            while (!queue.isEmpty()) {
                int u = queue.dequeue();
                inQueue[u] = false;

                for (int i = 0; i < graph.getEdges(u).size(); i++) {
                    ResidualGraph.Edge edge = graph.getEdges(u).get(i);
                    if (edge.residualCapacity() > 0 && dist[u] + edge.cost < dist[edge.v]) {
                        dist[edge.v] = dist[u] + edge.cost;
                        parentNode[edge.v] = u;
                        parentEdge[edge.v] = edge;
                        if (!inQueue[edge.v]) {
                            queue.enqueue(edge.v);
                            inQueue[edge.v] = true;
                        }
                    }
                }
            }

            if (dist[sink] >= INF) {
                break; // No more augmenting paths
            }

            int push = Integer.MAX_VALUE;
            int curr = sink;
            while (curr != source) {
                push = Math.min(push, parentEdge[curr].residualCapacity());
                curr = parentNode[curr];
            }

            curr = sink;
            while (curr != source) {
                ResidualGraph.Edge edge = parentEdge[curr];
                edge.flow += push;
                ResidualGraph.Edge rev = graph.getEdges(edge.v).get(edge.rev);
                rev.flow -= push;
                minCost += push * edge.cost;
                curr = parentNode[curr];
            }

            maxFlow += push;
        }

        return new FlowCostResult(maxFlow, minCost);
    }
}
