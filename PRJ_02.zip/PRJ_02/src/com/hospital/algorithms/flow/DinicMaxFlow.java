package com.hospital.algorithms.flow;

import com.hospital.ds.CustomQueue;

/**
 * Dinic's Algorithm for Maximum Flow on Level Graphs with Blocking Flows.
 * Complexity: O(V^2 * E), and O(min(V^(2/3), E^(1/2)) * E) on unit network graphs.
 */
public class DinicMaxFlow {

    public static int computeMaxFlow(ResidualGraph graph, int source, int sink) {
        int n = graph.getNumVertices();
        int maxFlow = 0;
        int[] level = new int[n];
        int[] ptr = new int[n];

        while (bfsLevelGraph(graph, source, sink, level)) {
            for (int i = 0; i < n; i++) ptr[i] = 0;

            while (true) {
                int pushed = dfsBlockingFlow(graph, source, sink, Integer.MAX_VALUE, level, ptr);
                if (pushed == 0) break;
                maxFlow += pushed;
            }
        }

        return maxFlow;
    }

    private static boolean bfsLevelGraph(ResidualGraph graph, int source, int sink, int[] level) {
        for (int i = 0; i < level.length; i++) level[i] = -1;
        level[source] = 0;

        CustomQueue<Integer> queue = new CustomQueue<>();
        queue.enqueue(source);

        while (!queue.isEmpty()) {
            int u = queue.dequeue();
            for (int i = 0; i < graph.getEdges(u).size(); i++) {
                ResidualGraph.Edge edge = graph.getEdges(u).get(i);
                if (edge.residualCapacity() > 0 && level[edge.v] == -1) {
                    level[edge.v] = level[u] + 1;
                    queue.enqueue(edge.v);
                }
            }
        }

        return level[sink] != -1;
    }

    private static int dfsBlockingFlow(ResidualGraph graph, int u, int sink, int flow, int[] level, int[] ptr) {
        if (u == sink || flow == 0) return flow;

        for (; ptr[u] < graph.getEdges(u).size(); ptr[u]++) {
            ResidualGraph.Edge edge = graph.getEdges(u).get(ptr[u]);
            if (level[edge.v] == level[u] + 1 && edge.residualCapacity() > 0) {
                int pushed = dfsBlockingFlow(graph, edge.v, sink, Math.min(flow, edge.residualCapacity()), level, ptr);
                if (pushed > 0) {
                    edge.flow += pushed;
                    ResidualGraph.Edge revEdge = graph.getEdges(edge.v).get(edge.rev);
                    revEdge.flow -= pushed;
                    return pushed;
                }
            }
        }

        return 0;
    }
}
