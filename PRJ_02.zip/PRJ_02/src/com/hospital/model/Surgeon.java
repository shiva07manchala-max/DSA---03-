package com.hospital.model;

import com.hospital.ds.CustomArrayList;

/**
 * Surgeon model with specialty capabilities and operating window constraints.
 */
public class Surgeon {
    private String id;
    private String name;
    private String specialty;
    private CustomArrayList<String> certifiedProcedures;
    private int shiftStartMinutes;
    private int shiftEndMinutes;
    private int currentWorkloadMinutes;
    private int maxDailyMinutes;

    public Surgeon(String id, String name, String specialty, int shiftStartMinutes, int shiftEndMinutes, int maxDailyMinutes) {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.certifiedProcedures = new CustomArrayList<>();
        this.shiftStartMinutes = shiftStartMinutes;
        this.shiftEndMinutes = shiftEndMinutes;
        this.maxDailyMinutes = maxDailyMinutes;
        this.currentWorkloadMinutes = 0;
    }

    public void addCertifiedProcedure(String procedure) {
        this.certifiedProcedures.add(procedure);
    }

    public boolean canPerform(String procedure) {
        if (procedure == null) return false;
        for (int i = 0; i < certifiedProcedures.size(); i++) {
            if (procedure.equalsIgnoreCase(certifiedProcedures.get(i))) {
                return true;
            }
        }
        return false;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecialty() { return specialty; }
    public CustomArrayList<String> getCertifiedProcedures() { return certifiedProcedures; }
    public int getShiftStartMinutes() { return shiftStartMinutes; }
    public int getShiftEndMinutes() { return shiftEndMinutes; }
    public int getCurrentWorkloadMinutes() { return currentWorkloadMinutes; }
    public void addWorkload(int minutes) { this.currentWorkloadMinutes += minutes; }
    public int getMaxDailyMinutes() { return maxDailyMinutes; }
    public boolean hasAvailableCapacity(int duration) { return currentWorkloadMinutes + duration <= maxDailyMinutes; }

    @Override
    public String toString() {
        return "Surgeon{" + id + ": Dr. " + name + " (" + specialty + ")}";
    }
}
