package com.hospital.model;

/**
 * Clinical patient record representing patient demographic, triage, and scheduling requirements.
 */
public class Patient implements Comparable<Patient> {
    private String id;
    private String name;
    private int age;
    private String gender;
    private TriageLevel triageLevel;
    private String diagnosis;
    private String requiredProcedure;
    private int estimatedDurationMinutes;
    private WardType postOpWardRequirement;
    private int postOpStayHours;
    private int deadlineMinutes;
    private int arrivalTimeMinutes;
    private String assignedBedId;
    private String assignedOrId;
    private int scheduledStartTime;

    public Patient(String id, String name, int age, String gender, TriageLevel triageLevel,
                   String diagnosis, String requiredProcedure, int estimatedDurationMinutes,
                   WardType postOpWardRequirement, int postOpStayHours, int deadlineMinutes,
                   int arrivalTimeMinutes) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.triageLevel = triageLevel;
        this.diagnosis = diagnosis;
        this.requiredProcedure = requiredProcedure;
        this.estimatedDurationMinutes = estimatedDurationMinutes;
        this.postOpWardRequirement = postOpWardRequirement;
        this.postOpStayHours = postOpStayHours;
        this.deadlineMinutes = deadlineMinutes;
        this.arrivalTimeMinutes = arrivalTimeMinutes;
        this.assignedBedId = null;
        this.assignedOrId = null;
        this.scheduledStartTime = -1;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public TriageLevel getTriageLevel() { return triageLevel; }
    public void setTriageLevel(TriageLevel triageLevel) { this.triageLevel = triageLevel; }
    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
    public String getRequiredProcedure() { return requiredProcedure; }
    public int getEstimatedDurationMinutes() { return estimatedDurationMinutes; }
    public void setEstimatedDurationMinutes(int duration) { this.estimatedDurationMinutes = duration; }
    public WardType getPostOpWardRequirement() { return postOpWardRequirement; }
    public int getPostOpStayHours() { return postOpStayHours; }
    public int getDeadlineMinutes() { return deadlineMinutes; }
    public int getArrivalTimeMinutes() { return arrivalTimeMinutes; }
    public String getAssignedBedId() { return assignedBedId; }
    public void setAssignedBedId(String assignedBedId) { this.assignedBedId = assignedBedId; }
    public String getAssignedOrId() { return assignedOrId; }
    public void setAssignedOrId(String assignedOrId) { this.assignedOrId = assignedOrId; }
    public int getScheduledStartTime() { return scheduledStartTime; }
    public void setScheduledStartTime(int scheduledStartTime) { this.scheduledStartTime = scheduledStartTime; }

    @Override
    public int compareTo(Patient other) {
        if (this.triageLevel.getLevel() != other.triageLevel.getLevel()) {
            return Integer.compare(this.triageLevel.getLevel(), other.triageLevel.getLevel());
        }
        if (this.deadlineMinutes != other.deadlineMinutes) {
            return Integer.compare(this.deadlineMinutes, other.deadlineMinutes);
        }
        return Integer.compare(this.arrivalTimeMinutes, other.arrivalTimeMinutes);
    }

    @Override
    public String toString() {
        return "Patient{" + id + " | " + name + " | " + triageLevel.name() + " | " + requiredProcedure + " (" + estimatedDurationMinutes + "m)}";
    }
}
