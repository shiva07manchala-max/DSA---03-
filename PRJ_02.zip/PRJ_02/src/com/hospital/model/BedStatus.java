package com.hospital.model;

public enum BedStatus {
    AVAILABLE,
    OCCUPIED,
    CLEANING,
    RESERVED,
    MAINTENANCE
}
