package com.hospital.model;

public enum WardType {
    ICU("Intensive Care Unit", 1.5),
    PACU("Post-Anesthesia Care Unit", 1.2),
    SURGICAL("Surgical Inpatient Ward", 1.0),
    GENERAL("General Medical Ward", 0.8),
    EMERGENCY("Emergency Holding", 1.4);

    private final String displayName;
    private final double costWeight;

    WardType(String displayName, double costWeight) {
        this.displayName = displayName;
        this.costWeight = costWeight;
    }

    public String getDisplayName() {
        return displayName;
    }

    public double getCostWeight() {
        return costWeight;
    }
}
