package com.hospital.model;

public enum TriageLevel {
    LEVEL_1_EMERGENCY(1, "Resuscitation / Immediate", "Immediate threat to life; zero delay allowed.", "#ef4444"),
    LEVEL_2_URGENT(2, "Emergent / Urgent", "Potential threat to life/limb; max 30 min wait.", "#f59e0b"),
    LEVEL_3_SEMI_URGENT(3, "Urgent / Semi-Urgent", "Severe condition; max 60 min wait.", "#3b82f6"),
    LEVEL_4_ELECTIVE(4, "Standard / Elective", "Stable planned procedure; scheduled slot.", "#10b981");

    private final int level;
    private final String label;
    private final String description;
    private final String colorHex;

    TriageLevel(int level, String label, String description, String colorHex) {
        this.level = level;
        this.label = label;
        this.description = description;
        this.colorHex = colorHex;
    }

    public int getLevel() {
        return level;
    }

    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    public String getColorHex() {
        return colorHex;
    }

    public static TriageLevel fromLevel(int level) {
        for (TriageLevel tl : values()) {
            if (tl.level == level) return tl;
        }
        return LEVEL_4_ELECTIVE;
    }
}
