package com.hospital.model;

/**
 * Scheduled surgery time block on an OR timeline.
 */
public class ScheduleSlot {
    private String slotId;
    private String operatingRoomId;
    private String patientId;
    private String patientName;
    private String procedureName;
    private String surgeonId;
    private String surgeonName;
    private TriageLevel triageLevel;
    private int startMinute;
    private int endMinute;
    private int turnaroundMinutes;
    private boolean isEmergency;

    public ScheduleSlot(String slotId, String operatingRoomId, String patientId, String patientName,
                        String procedureName, String surgeonId, String surgeonName,
                        TriageLevel triageLevel, int startMinute, int endMinute,
                        int turnaroundMinutes, boolean isEmergency) {
        this.slotId = slotId;
        this.operatingRoomId = operatingRoomId;
        this.patientId = patientId;
        this.patientName = patientName;
        this.procedureName = procedureName;
        this.surgeonId = surgeonId;
        this.surgeonName = surgeonName;
        this.triageLevel = triageLevel;
        this.startMinute = startMinute;
        this.endMinute = endMinute;
        this.turnaroundMinutes = turnaroundMinutes;
        this.isEmergency = isEmergency;
    }

    public String getSlotId() { return slotId; }
    public String getOperatingRoomId() { return operatingRoomId; }
    public String getPatientId() { return patientId; }
    public String getPatientName() { return patientName; }
    public String getProcedureName() { return procedureName; }
    public String getSurgeonId() { return surgeonId; }
    public String getSurgeonName() { return surgeonName; }
    public TriageLevel getTriageLevel() { return triageLevel; }
    public int getStartMinute() { return startMinute; }
    public void setStartMinute(int startMinute) { this.startMinute = startMinute; }
    public int getEndMinute() { return endMinute; }
    public void setEndMinute(int endMinute) { this.endMinute = endMinute; }
    public int getTurnaroundMinutes() { return turnaroundMinutes; }
    public void setTurnaroundMinutes(int turnaroundMinutes) { this.turnaroundMinutes = turnaroundMinutes; }
    public boolean isEmergency() { return isEmergency; }

    public int getDurationMinutes() {
        return endMinute - startMinute;
    }

    @Override
    public String toString() {
        return String.format("[%02d:%02d - %02d:%02d] %s (Pt: %s, Surg: %s, Room: %s)",
                startMinute / 60, startMinute % 60,
                endMinute / 60, endMinute % 60,
                procedureName, patientName, surgeonName, operatingRoomId);
    }
}
