package com.hospital.model;

import com.hospital.ds.CustomArrayList;

/**
 * Operating Room (OR) surgical suite model with equipment compatibility and schedule slots.
 */
public class OperatingRoom {
    private String id;
    private String name;
    private CustomArrayList<String> supportedSpecialties;
    private CustomArrayList<ScheduleSlot> scheduleSlots;
    private int totalMakespanMinutes;
    private int totalIdleMinutes;
    private boolean isEmergencyCapable;

    public OperatingRoom(String id, String name, boolean isEmergencyCapable) {
        this.id = id;
        this.name = name;
        this.isEmergencyCapable = isEmergencyCapable;
        this.supportedSpecialties = new CustomArrayList<>();
        this.scheduleSlots = new CustomArrayList<>();
        this.totalMakespanMinutes = 0;
        this.totalIdleMinutes = 0;
    }

    public void addSupportedSpecialty(String specialty) {
        this.supportedSpecialties.add(specialty);
    }

    public boolean supportsSpecialty(String specialty) {
        if (specialty == null) return false;
        for (int i = 0; i < supportedSpecialties.size(); i++) {
            if (specialty.equalsIgnoreCase(supportedSpecialties.get(i))) {
                return true;
            }
        }
        return false;
    }

    public void addSlot(ScheduleSlot slot) {
        this.scheduleSlots.add(slot);
        if (slot.getEndMinute() > totalMakespanMinutes) {
            totalMakespanMinutes = slot.getEndMinute();
        }
    }

    public void clearSlots() {
        this.scheduleSlots.clear();
        this.totalMakespanMinutes = 0;
        this.totalIdleMinutes = 0;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public boolean isEmergencyCapable() { return isEmergencyCapable; }
    public CustomArrayList<String> getSupportedSpecialties() { return supportedSpecialties; }
    public CustomArrayList<ScheduleSlot> getScheduleSlots() { return scheduleSlots; }
    public int getTotalMakespanMinutes() { return totalMakespanMinutes; }
    public void setTotalMakespanMinutes(int makespan) { this.totalMakespanMinutes = makespan; }
    public int getTotalIdleMinutes() { return totalIdleMinutes; }
    public void setTotalIdleMinutes(int idle) { this.totalIdleMinutes = idle; }

    @Override
    public String toString() {
        return name + " (" + id + ") - " + scheduleSlots.size() + " slots, Makespan: " + totalMakespanMinutes + "m";
    }
}
