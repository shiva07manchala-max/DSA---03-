package com.hospital.model;

/**
 * Surgery classification and base procedural metadata.
 */
public class Surgery {
    private String id;
    private String name;
    private String specialty;
    private int baseDurationMinutes;
    private int baseTurnaroundMinutes;
    private WardType recommendedPostOpWard;

    public Surgery(String id, String name, String specialty, int baseDurationMinutes, int baseTurnaroundMinutes, WardType recommendedPostOpWard) {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.baseDurationMinutes = baseDurationMinutes;
        this.baseTurnaroundMinutes = baseTurnaroundMinutes;
        this.recommendedPostOpWard = recommendedPostOpWard;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getSpecialty() { return specialty; }
    public int getBaseDurationMinutes() { return baseDurationMinutes; }
    public int getBaseTurnaroundMinutes() { return baseTurnaroundMinutes; }
    public WardType getRecommendedPostOpWard() { return recommendedPostOpWard; }

    @Override
    public String toString() {
        return name + " (" + specialty + ", " + baseDurationMinutes + "m)";
    }
}
