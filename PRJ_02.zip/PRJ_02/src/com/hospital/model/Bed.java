package com.hospital.model;

/**
 * Hospital Bed unit with telemetry, ward allocation, and occupancy states.
 */
public class Bed {
    private String id;
    private String roomNumber;
    private WardType wardType;
    private BedStatus status;
    private String currentPatientId;
    private int occupiedUntilMinutes;
    private int cleaningRequiredMinutes;

    public Bed(String id, String roomNumber, WardType wardType) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.wardType = wardType;
        this.status = BedStatus.AVAILABLE;
        this.currentPatientId = null;
        this.occupiedUntilMinutes = 0;
        this.cleaningRequiredMinutes = 0;
    }

    public String getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public WardType getWardType() { return wardType; }
    public BedStatus getStatus() { return status; }
    public void setStatus(BedStatus status) { this.status = status; }
    public String getCurrentPatientId() { return currentPatientId; }
    public void setCurrentPatientId(String currentPatientId) { this.currentPatientId = currentPatientId; }
    public int getOccupiedUntilMinutes() { return occupiedUntilMinutes; }
    public void setOccupiedUntilMinutes(int occupiedUntilMinutes) { this.occupiedUntilMinutes = occupiedUntilMinutes; }
    public int getCleaningRequiredMinutes() { return cleaningRequiredMinutes; }
    public void setCleaningRequiredMinutes(int cleaningRequiredMinutes) { this.cleaningRequiredMinutes = cleaningRequiredMinutes; }

    public boolean isAvailableAt(int timeMinute) {
        return (status == BedStatus.AVAILABLE && timeMinute >= occupiedUntilMinutes);
    }

    public void assignPatient(String patientId, int durationMinutes, int currentTimeMinutes) {
        this.currentPatientId = patientId;
        this.status = BedStatus.OCCUPIED;
        this.occupiedUntilMinutes = currentTimeMinutes + durationMinutes;
    }

    public void release() {
        this.currentPatientId = null;
        this.status = BedStatus.CLEANING;
        this.cleaningRequiredMinutes = 30; // 30 min standard sanitization turnaround
    }

    @Override
    public String toString() {
        return "Bed{" + id + " [" + wardType + "] - " + status + " (" + (currentPatientId != null ? currentPatientId : "None") + ")}";
    }
}
