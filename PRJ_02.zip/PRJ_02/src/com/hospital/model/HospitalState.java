package com.hospital.model;

import com.hospital.ds.CustomArrayList;
import com.hospital.ds.CustomHashMap;

/**
 * State store managing all patients, beds, OR suites, and surgeons in the hospital.
 */
public class HospitalState {
    private final CustomHashMap<String, Patient> patients;
    private final CustomHashMap<String, Bed> beds;
    private final CustomHashMap<String, OperatingRoom> operatingRooms;
    private final CustomHashMap<String, Surgeon> surgeons;
    private final CustomHashMap<String, Surgery> surgeryCatalog;
    private int currentSimulationMinute;

    public HospitalState() {
        this.patients = new CustomHashMap<>();
        this.beds = new CustomHashMap<>();
        this.operatingRooms = new CustomHashMap<>();
        this.surgeons = new CustomHashMap<>();
        this.surgeryCatalog = new CustomHashMap<>();
        this.currentSimulationMinute = 480; // 08:00 AM in minutes
    }

    public void addPatient(Patient patient) {
        patients.put(patient.getId(), patient);
    }

    public Patient getPatient(String id) {
        return patients.get(id);
    }

    public CustomArrayList<Patient> getAllPatients() {
        return patients.values();
    }

    public void addBed(Bed bed) {
        beds.put(bed.getId(), bed);
    }

    public Bed getBed(String id) {
        return beds.get(id);
    }

    public CustomArrayList<Bed> getAllBeds() {
        return beds.values();
    }

    public void addOperatingRoom(OperatingRoom room) {
        operatingRooms.put(room.getId(), room);
    }

    public OperatingRoom getOperatingRoom(String id) {
        return operatingRooms.get(id);
    }

    public CustomArrayList<OperatingRoom> getAllOperatingRooms() {
        return operatingRooms.values();
    }

    public void addSurgeon(Surgeon surgeon) {
        surgeons.put(surgeon.getId(), surgeon);
    }

    public Surgeon getSurgeon(String id) {
        return surgeons.get(id);
    }

    public CustomArrayList<Surgeon> getAllSurgeons() {
        return surgeons.values();
    }

    public void addSurgeryCatalog(Surgery surgery) {
        surgeryCatalog.put(surgery.getName(), surgery);
    }

    public Surgery getSurgery(String name) {
        return surgeryCatalog.get(name);
    }

    public CustomArrayList<Surgery> getAllSurgeries() {
        return surgeryCatalog.values();
    }

    public int getCurrentSimulationMinute() {
        return currentSimulationMinute;
    }

    public void setCurrentSimulationMinute(int minute) {
        this.currentSimulationMinute = minute;
    }

    public void advanceTime(int minutes) {
        this.currentSimulationMinute += minutes;
    }
}
