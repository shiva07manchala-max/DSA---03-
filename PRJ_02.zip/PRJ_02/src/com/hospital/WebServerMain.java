package com.hospital;

import com.hospital.engine.HospitalDataLoader;
import com.hospital.model.HospitalState;
import com.hospital.engine.SimulationManager;
import com.hospital.server.handlers.*;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.Executors;

/**
 * Embedded Zero-Dependency HTTP Server & High-Performance REST API Engine.
 * Serves both the web UI and extended clinical optimization API endpoints.
 */
public class WebServerMain {
    private static final Object STATE_LOCK = new Object();
    private static HospitalState hospitalState;
    private static SimulationManager simulationManager;

    public static void main(String[] args) throws Exception {
        int port = 8080;
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.out.println("Using default port 8080");
            }
        }

        synchronized (STATE_LOCK) {
            hospitalState = HospitalDataLoader.loadInitialState();
            simulationManager = new SimulationManager(hospitalState);
        }

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        // API Handler
        server.createContext("/api", new ApiHttpHandler());

        // Static Web UI Handler
        server.createContext("/", new StaticFileHttpHandler());

        server.setExecutor(Executors.newFixedThreadPool(16));
        server.start();

        System.out.println("================================================================================");
        System.out.println(" 🏥 HOSPITAL BED & OR SCHEDULING ENGINE (DSA-3: 25CS2103E)");
        System.out.println(" 🚀 Web Server & REST API active at: http://localhost:" + port);
        System.out.println(" 💻 Zero-dependency engine - No .bat or docker required");
        System.out.println(" ⚡ Upgraded Backend: State Persistence, Multi-Objective DP, Live Telemetry");
        System.out.println("================================================================================");
    }

    private static class ApiHttpHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            String path = exchange.getRequestURI().getPath();
            String method = exchange.getRequestMethod();
            String body = readRequestBody(exchange);
            String responseJson = "{\"error\": \"Not Found\"}";
            int statusCode = 200;

            try {
                synchronized (STATE_LOCK) {
                    if ("/api/auth/login".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = AuthHandler.handleLogin(body);
                    } else if ("/api/schedule/run".equals(path) || "/api/schedule".equals(path)) {
                        responseJson = ScheduleHandler.handleGetSchedule(hospitalState);
                    } else if ("/api/schedule/strategies".equals(path)) {
                        responseJson = OptimizationHandler.handleCompareStrategies(hospitalState);
                    } else if ("/api/flow/analytics".equals(path) || "/api/flow".equals(path)) {
                        responseJson = FlowHandler.handleGetFlowAnalytics(hospitalState);
                    } else if ("/api/beds".equals(path) && "GET".equalsIgnoreCase(method)) {
                        responseJson = BedHandler.handleGetBeds(hospitalState);
                    } else if ("/api/beds/update".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = BedHandler.handleUpdateBed(hospitalState, body);
                    } else if ("/api/surgeons".equals(path) || "/api/surgeons/workload".equals(path)) {
                        responseJson = SurgeonHandler.handleGetSurgeons(hospitalState);
                    } else if ("/api/patients/add".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = OptimizationHandler.handleAddPatient(hospitalState, body);
                    } else if ("/api/simulate/advance-clock".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = OptimizationHandler.handleAdvanceClock(hospitalState, body);
                    } else if ("/api/triage/evaluate".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = TriageHandler.handleEvaluateText(body);
                    } else if ("/api/search/fuzzy".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = TriageHandler.handleFuzzySearch(body);
                    } else if ("/api/similarity/suffix-lcs".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = TriageHandler.handleSuffixLcs(body);
                    } else if ("/api/simulate/emergency".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = SimulationHandler.handleEmergencyArrival(hospitalState, simulationManager, body);
                    } else if ("/api/simulate/overrun".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = SimulationHandler.handleOverrun(hospitalState, simulationManager, body);
                    } else if ("/api/simulate/cancel".equals(path) && "POST".equalsIgnoreCase(method)) {
                        responseJson = SimulationHandler.handleCancellation(hospitalState, simulationManager, body);
                    } else if ("/api/state/save".equals(path)) {
                        responseJson = StatePersistenceHandler.handleSaveState(hospitalState);
                    } else if ("/api/state/reset".equals(path) && "POST".equalsIgnoreCase(method)) {
                        HospitalState[] ref = new HospitalState[]{ hospitalState };
                        responseJson = StatePersistenceHandler.handleResetState(ref);
                        hospitalState = ref[0];
                        simulationManager = new SimulationManager(hospitalState);
                    } else if ("/api/state/export".equals(path)) {
                        responseJson = StatePersistenceHandler.handleExportJson(hospitalState);
                    } else if ("/api/reports/analytics".equals(path)) {
                        responseJson = ReportHandler.handleGetReportText(hospitalState);
                    } else {
                        statusCode = 404;
                        responseJson = "{\"error\": \"Endpoint not found: " + path + "\"}";
                    }
                }
            } catch (Exception e) {
                statusCode = 500;
                responseJson = "{\"error\": \"" + e.getMessage() + "\"}";
            }

            byte[] bytes = responseJson.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
            exchange.sendResponseHeaders(statusCode, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }

        private String readRequestBody(HttpExchange exchange) throws IOException {
            try (InputStream is = exchange.getRequestBody();
                 ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) != -1) {
                    bos.write(buffer, 0, len);
                }
                return new String(bos.toByteArray(), StandardCharsets.UTF_8);
            }
        }
    }

    private static class StaticFileHttpHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            // Robust multi-path resolution
            Path filePath = Paths.get("web" + path);
            if (!Files.exists(filePath)) {
                filePath = Paths.get("D:/Java_2nd yr/DSA-03/Project_DSA-03/PRJ_02/web" + path);
            }
            if (!Files.exists(filePath)) {
                filePath = Paths.get(System.getProperty("user.dir"), "web" + path);
            }

            if (Files.exists(filePath) && !Files.isDirectory(filePath)) {
                String contentType = getContentType(path);
                exchange.getResponseHeaders().set("Content-Type", contentType);
                byte[] fileBytes = Files.readAllBytes(filePath);
                exchange.sendResponseHeaders(200, fileBytes.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(fileBytes);
                }
            } else {
                String notFound = "<h1>404 Not Found</h1><p>File not found: " + path + "</p>";
                byte[] bytes = notFound.getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "text/html");
                exchange.sendResponseHeaders(404, bytes.length);
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(bytes);
                }
            }
        }

        private String getContentType(String path) {
            if (path.endsWith(".html")) return "text/html; charset=UTF-8";
            if (path.endsWith(".css")) return "text/css; charset=UTF-8";
            if (path.endsWith(".js")) return "application/javascript; charset=UTF-8";
            if (path.endsWith(".json")) return "application/json; charset=UTF-8";
            if (path.endsWith(".png")) return "image/png";
            if (path.endsWith(".svg")) return "image/svg+xml";
            return "text/plain";
        }
    }
}
