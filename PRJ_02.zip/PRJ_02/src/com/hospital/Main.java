package com.hospital;

import com.hospital.algorithms.approx.GrahamLPTScheduler;
import com.hospital.algorithms.dp.BitmaskTurnaroundDP;
import com.hospital.algorithms.flow.MinCutAnalyzer;
import com.hospital.algorithms.flow.ResidualGraph;
import com.hospital.algorithms.strings.AhoCorasickTriage;
import com.hospital.algorithms.strings.SuffixArrayKasai;
import com.hospital.ds.CustomArrayList;
import com.hospital.engine.HospitalDataLoader;
import com.hospital.model.HospitalState;
import com.hospital.engine.QualityReporter;
import com.hospital.engine.SchedulingEngine;

/**
 * Terminal Command-Line Interface and Batch Pipeline Runner.
 * Can be invoked by external systems via standard CLI arguments.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println(" 🏥 HOSPITAL BED & OPERATING ROOM (OR) SCHEDULING OPTIMIZATION ENGINE");
        System.out.println("                   KL UNIVERSITY - DSA-3 (25CS2103E)");
        System.out.println("================================================================================");

        HospitalState state = HospitalDataLoader.loadInitialState();

        if (args.length > 0 && "--web".equalsIgnoreCase(args[0])) {
            int port = 8080;
            if (args.length > 1) {
                try { port = Integer.parseInt(args[1]); } catch (Exception ignored) {}
            }
            try {
                WebServerMain.main(new String[]{String.valueOf(port)});
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        System.out.println("\n[+] Executing Master Scheduling Pipeline (Modules 1 to 6)...");
        long start = System.currentTimeMillis();

        SchedulingEngine.ScheduleReport report = SchedulingEngine.runMasterSchedule(state);
        long duration = System.currentTimeMillis() - start;

        System.out.println("[+] Master Pipeline completed in " + duration + " ms.\n");

        String auditReport = QualityReporter.generateComprehensiveReport(state, report);
        System.out.println(auditReport);

        System.out.println("\n[!] To launch the interactive Web Dashboard & REST API, run:");
        System.out.println("    java -cp bin com.hospital.WebServerMain 8080");
        System.out.println("    Then open http://localhost:8080 in your web browser.\n");
    }
}
