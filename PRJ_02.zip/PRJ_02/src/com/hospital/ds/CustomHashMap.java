package com.hospital.ds;

/**
 * Hand-built Separate Chaining Hash Map conforming to zero-dependency mandate.
 *
 * @param <K> Key type
 * @param <V> Value type
 */
public class CustomHashMap<K, V> {
    public static class Entry<K, V> {
        public final K key;
        public V value;
        public Entry<K, V> next;

        public Entry(K key, V value, Entry<K, V> next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }

    private Entry<K, V>[] table;
    private int size;
    private static final int INITIAL_CAPACITY = 16;
    private static final float LOAD_FACTOR = 0.75f;

    @SuppressWarnings("unchecked")
    public CustomHashMap() {
        this.table = new Entry[INITIAL_CAPACITY];
        this.size = 0;
    }

    @SuppressWarnings("unchecked")
    public CustomHashMap(int initialCapacity) {
        int cap = 1;
        while (cap < initialCapacity) cap <<= 1;
        this.table = new Entry[cap];
        this.size = 0;
    }

    private int hash(K key) {
        if (key == null) return 0;
        int h = key.hashCode();
        return (h ^ (h >>> 16)) & (table.length - 1);
    }

    public V put(K key, V value) {
        if ((float) (size + 1) / table.length > LOAD_FACTOR) {
            resize();
        }

        int index = hash(key);
        Entry<K, V> curr = table[index];

        while (curr != null) {
            if (key == null ? curr.key == null : key.equals(curr.key)) {
                V oldVal = curr.value;
                curr.value = value;
                return oldVal;
            }
            curr = curr.next;
        }

        table[index] = new Entry<>(key, value, table[index]);
        size++;
        return null;
    }

    public V get(K key) {
        int index = hash(key);
        Entry<K, V> curr = table[index];
        while (curr != null) {
            if (key == null ? curr.key == null : key.equals(curr.key)) {
                return curr.value;
            }
            curr = curr.next;
        }
        return null;
    }

    public V getOrDefault(K key, V defaultValue) {
        V val = get(key);
        return val != null ? val : defaultValue;
    }

    public boolean containsKey(K key) {
        int index = hash(key);
        Entry<K, V> curr = table[index];
        while (curr != null) {
            if (key == null ? curr.key == null : key.equals(curr.key)) {
                return true;
            }
            curr = curr.next;
        }
        return false;
    }

    public V remove(K key) {
        int index = hash(key);
        Entry<K, V> curr = table[index];
        Entry<K, V> prev = null;

        while (curr != null) {
            if (key == null ? curr.key == null : key.equals(curr.key)) {
                if (prev == null) {
                    table[index] = curr.next;
                } else {
                    prev.next = curr.next;
                }
                size--;
                return curr.value;
            }
            prev = curr;
            curr = curr.next;
        }
        return null;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        for (int i = 0; i < table.length; i++) {
            table[i] = null;
        }
        size = 0;
    }

    public CustomArrayList<K> keySet() {
        CustomArrayList<K> keys = new CustomArrayList<>(size);
        for (Entry<K, V> bucket : table) {
            Entry<K, V> curr = bucket;
            while (curr != null) {
                keys.add(curr.key);
                curr = curr.next;
            }
        }
        return keys;
    }

    public CustomArrayList<V> values() {
        CustomArrayList<V> list = new CustomArrayList<>(size);
        for (Entry<K, V> bucket : table) {
            Entry<K, V> curr = bucket;
            while (curr != null) {
                list.add(curr.value);
                curr = curr.next;
            }
        }
        return list;
    }

    public CustomArrayList<Entry<K, V>> entrySet() {
        CustomArrayList<Entry<K, V>> entries = new CustomArrayList<>(size);
        for (Entry<K, V> bucket : table) {
            Entry<K, V> curr = bucket;
            while (curr != null) {
                entries.add(curr);
                curr = curr.next;
            }
        }
        return entries;
    }

    @SuppressWarnings("unchecked")
    private void resize() {
        int newCap = table.length * 2;
        Entry<K, V>[] newTable = new Entry[newCap];

        for (Entry<K, V> head : table) {
            Entry<K, V> curr = head;
            while (curr != null) {
                Entry<K, V> next = curr.next;
                int h = (curr.key == null) ? 0 : curr.key.hashCode();
                int newIdx = (h ^ (h >>> 16)) & (newCap - 1);

                curr.next = newTable[newIdx];
                newTable[newIdx] = curr;
                curr = next;
            }
        }
        this.table = newTable;
    }
}
