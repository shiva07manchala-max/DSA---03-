package com.hospital.ds;

/**
 * Hand-built LIFO Stack conforming to zero-dependency mandate.
 *
 * @param <T> Element type
 */
public class CustomStack<T> {
    private Object[] elements;
    private int size;
    private static final int DEFAULT_CAPACITY = 16;

    public CustomStack() {
        this(DEFAULT_CAPACITY);
    }

    public CustomStack(int capacity) {
        this.elements = new Object[Math.max(capacity, 1)];
        this.size = 0;
    }

    public void push(T element) {
        ensureCapacity(size + 1);
        elements[size++] = element;
    }

    @SuppressWarnings("unchecked")
    public T pop() {
        if (size == 0) {
            throw new IllegalStateException("Stack is empty");
        }
        T item = (T) elements[--size];
        elements[size] = null;
        return item;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) return null;
        return (T) elements[size - 1];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        for (int i = 0; i < size; i++) elements[i] = null;
        size = 0;
    }

    private void ensureCapacity(int minCapacity) {
        if (minCapacity > elements.length) {
            int newCap = elements.length * 2;
            Object[] newArr = new Object[newCap];
            for (int i = 0; i < size; i++) newArr[i] = elements[i];
            elements = newArr;
        }
    }
}
