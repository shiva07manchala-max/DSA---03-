package com.hospital.ds;

import java.util.Comparator;

/**
 * Hand-built Indexed Binary Min-Heap supporting O(log n) insertions, extracts,
 * and custom priority comparisons without java.util.* collections.
 *
 * @param <T> Element type
 */
public class CustomMinHeap<T> {
    private Object[] heap;
    private int size;
    private final Comparator<T> comparator;
    private static final int DEFAULT_CAPACITY = 16;

    public CustomMinHeap() {
        this(DEFAULT_CAPACITY, null);
    }

    public CustomMinHeap(Comparator<T> comparator) {
        this(DEFAULT_CAPACITY, comparator);
    }

    public CustomMinHeap(int initialCapacity, Comparator<T> comparator) {
        this.heap = new Object[Math.max(initialCapacity, 1)];
        this.size = 0;
        this.comparator = comparator;
    }

    public void insert(T element) {
        if (element == null) throw new NullPointerException("Cannot insert null element");
        ensureCapacity(size + 1);
        heap[size] = element;
        siftUp(size);
        size++;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) return null;
        return (T) heap[0];
    }

    @SuppressWarnings("unchecked")
    public T extractMin() {
        if (size == 0) return null;
        T min = (T) heap[0];
        heap[0] = heap[size - 1];
        heap[size - 1] = null;
        size--;
        if (size > 0) {
            siftDown(0);
        }
        return min;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        for (int i = 0; i < size; i++) heap[i] = null;
        size = 0;
    }

    @SuppressWarnings("unchecked")
    private int compare(T a, T b) {
        if (comparator != null) {
            return comparator.compare(a, b);
        }
        return ((Comparable<T>) a).compareTo(b);
    }

    @SuppressWarnings("unchecked")
    private void siftUp(int k) {
        T key = (T) heap[k];
        while (k > 0) {
            int parent = (k - 1) >>> 1;
            T p = (T) heap[parent];
            if (compare(key, p) >= 0) break;
            heap[k] = p;
            k = parent;
        }
        heap[k] = key;
    }

    @SuppressWarnings("unchecked")
    private void siftDown(int k) {
        T key = (T) heap[k];
        int half = size >>> 1;
        while (k < half) {
            int child = (k << 1) + 1;
            T c = (T) heap[child];
            int right = child + 1;
            if (right < size && compare((T) heap[right], c) < 0) {
                child = right;
                c = (T) heap[child];
            }
            if (compare(key, c) <= 0) break;
            heap[k] = c;
            k = child;
        }
        heap[k] = key;
    }

    private void ensureCapacity(int minCapacity) {
        if (minCapacity > heap.length) {
            int newCap = heap.length * 2;
            Object[] newHeap = new Object[newCap];
            for (int i = 0; i < size; i++) {
                newHeap[i] = heap[i];
            }
            this.heap = newHeap;
        }
    }
}
