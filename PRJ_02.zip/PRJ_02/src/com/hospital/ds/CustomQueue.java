package com.hospital.ds;

/**
 * Hand-built Ring-Buffer FIFO Queue conforming to zero-dependency mandate.
 *
 * @param <T> Element type
 */
public class CustomQueue<T> {
    private Object[] elements;
    private int head;
    private int tail;
    private int size;
    private static final int DEFAULT_CAPACITY = 16;

    public CustomQueue() {
        this(DEFAULT_CAPACITY);
    }

    public CustomQueue(int capacity) {
        this.elements = new Object[Math.max(capacity, 1)];
        this.head = 0;
        this.tail = 0;
        this.size = 0;
    }

    public void enqueue(T element) {
        if (size == elements.length) {
            resize(elements.length * 2);
        }
        elements[tail] = element;
        tail = (tail + 1) % elements.length;
        size++;
    }

    @SuppressWarnings("unchecked")
    public T dequeue() {
        if (size == 0) {
            throw new IllegalStateException("Queue is empty");
        }
        T item = (T) elements[head];
        elements[head] = null;
        head = (head + 1) % elements.length;
        size--;
        return item;
    }

    @SuppressWarnings("unchecked")
    public T peek() {
        if (size == 0) return null;
        return (T) elements[head];
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        for (int i = 0; i < elements.length; i++) elements[i] = null;
        head = tail = size = 0;
    }

    private void resize(int newCap) {
        Object[] newArr = new Object[newCap];
        for (int i = 0; i < size; i++) {
            newArr[i] = elements[(head + i) % elements.length];
        }
        elements = newArr;
        head = 0;
        tail = size;
    }
}
