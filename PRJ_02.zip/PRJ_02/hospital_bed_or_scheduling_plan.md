# Implementation Plan: Hospital Bed & Operating Room (OR) Scheduling Optimization Engine

## Goal Description
Build a production-grade, highly optimized **Hospital Bed & Operating Room (OR) Scheduling Optimization Engine** with an end-to-end fullstack architecture (zero-dependency Java backend + modern responsive light/dark UI frontend with login) designed to maximize hospital bed and surgical suite utilization, minimize makespan and idle turnaround times, respect doctor/staff specializations and patient clinical urgency levels, and provide comprehensive real-time analytics.

The solution strictly adheres to the **KL University DSA-3 (25CS2103E)** course syllabus requirements:
1. **Zero-Dependency Engine**: All core data structures (`CustomArrayList`, `CustomHashMap`, `CustomMinHeap`, `CustomLinkedList`, `CustomDisjointSetUnion`, `CustomQueue`, `CustomStack`, etc.) and algorithms are hand-crafted from first principles without importing `java.util.*` inside the engine.
2. **Complete Syllabus Alignment (Modules 1 to 6)**:
   - **Module 1**: Custom fundamental collections, asymptotic models, and problem-to-paradigm mapping.
   - **Module 2 (String Algorithms)**: KMP, Z-Function, Rabin-Karp rolling hash, Aho-Corasick multi-pattern triage automaton, Suffix Array & Kasai LCP diagnostic record similarity.
   - **Module 3 (Dynamic Programming)**: Wagner-Fischer edit distance, Needleman-Wunsch sequence alignment, Interval DP, and Bitmask TSP Turnaround minimization ($O(n^2 2^n)$).
   - **Module 4 (Network Flow)**: Ford-Fulkerson, Edmonds-Karp ($O(VE^2)$), Dinic's blocking flow ($O(V^2E)$), Max-Flow/Min-Cut bottleneck identification, and Bipartite Matching for surgeon-to-OR assignment.
   - **Module 5 (NP-Completeness & Approximations)**: Graham's LPT 4/3-Approximation ($P \parallel C_{\max}$), Vertex Cover 2-Approximation for request conflict graphs, and Exact Branch-and-Bound scheduler.
   - **Module 6 (Randomized & Parallel Algorithms)**: Las Vegas Randomized QuickSort, Universal Hashing, Reservoir Sampling for streaming triage arrivals, and Blelloch Parallel Prefix Sum with work-span analysis ($T_1, T_\infty$).
3. **No `.bat`, Render, or Docker Files**: Standalone Java compilation and execution using standard `javac` and `java` commands, with direct cross-application integration capability via clean CLI flags or standard REST JSON APIs.
4. **User-Friendly Frontend**:
   - Modern Dark & Light Mode themes with instant toggle and persistent state.
   - Secure, attractive Login / Role Selection portal (Admin, Chief Surgeon, Hospital Operations Scheduler, Triage Nurse).
   - Interactive Multi-OR Gantt Schedule visualization.
   - Live Bed Occupancy & Ward Telemetry (ICU, PACU, Surgical, General).
   - Real-Time Emergency EHR Triage analyzer powered by Aho-Corasick.
   - Flow Network & Min-Cut Capacity Bottleneck visualizer.
   - Algorithm Comparison Suite (LPT Approx vs Exact Branch-and-Bound).
   - Dynamic simulation controls (Emergency Code Blue injection, procedure delays, cancellations).

---

## User Review Required

> [!IMPORTANT]
> **Target Project Location**: The project will be created in `D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02`.
> Standard Java (JDK 11+) is required to compile and run. No third-party Maven/Gradle or NPM packages are required to run the application, guaranteeing zero setup friction and effortless execution from any external launcher or IDE.

> [!NOTE]
> The backend provides both:
> 1. A standalone Web Server with embedded static frontend delivery and REST API (`com.hospital.WebServerMain` on `http://localhost:8080`).
> 2. A terminal-based CLI / Pipeline Engine (`com.hospital.Main`) suitable for programmatic batch invocation from other software.

---

## Proposed System Architecture

```mermaid
flowchart TD
    subgraph UI ["Modern Responsive Frontend (Dark/Light Theme)"]
        Login["Login & Role Portal"]
        Gantt["Interactive OR Gantt View"]
        Beds["Bed Ward Grid (ICU/PACU/General)"]
        FlowVis["Min-Cut Bottleneck Visualizer"]
        TriageTool["Aho-Corasick Emergency Triage"]
        AlgoLab["Algorithm Benchmark Lab (LPT vs Exact)"]
        TSPView["Bitmask TSP Turnaround Optimizer"]
    end

    subgraph API ["Java HTTP REST Server (Zero External Dependencies)"]
        AuthHandler["/api/auth/*"]
        ScheduleHandler["/api/schedule/*"]
        FlowHandler["/api/flow/*"]
        BedHandler["/api/beds & /api/rooms"]
        TriageHandler["/api/triage/*"]
        SimHandler["/api/simulate/*"]
    end

    subgraph Engine ["DSA-3 Zero-Dependency Core Engine (No java.util.*)"]
        subgraph DS ["Module 1: Custom Data Structures"]
            CList["CustomArrayList<T>"]
            CMap["CustomHashMap<K,V>"]
            CHeap["CustomMinHeap<T>"]
            CDSU["CustomDisjointSetUnion"]
            CQueue["CustomQueue<T>"]
            CStack["CustomStack<T>"]
        end

        subgraph Mod2 ["Module 2: String Algorithms"]
            KMP["KMP & Z-Function"]
            RabinKarp["Rabin-Karp Rolling Hash"]
            AhoCorasick["Aho-Corasick Multi-Pattern Automaton"]
            SuffixArray["Suffix Array & Kasai LCP"]
        end

        subgraph Mod3 ["Module 3: Advanced DP"]
            EditDist["Wagner-Fischer & Damerau Edit Distance"]
            SeqAlign["Needleman-Wunsch Alignment"]
            BitmaskTSP["Bitmask Turnaround TSP DP (O(n^2 2^n))"]
            IntervalDP["Interval DP Scheduler"]
        end

        subgraph Mod4 ["Module 4: Network Flow"]
            Dinic["Dinic's Level Graph Max-Flow"]
            EdmondsKarp["Edmonds-Karp Max-Flow"]
            MinCut["Min-Cut Bottleneck Analyzer"]
            Bipartite["Bipartite Matching (Surgeon to OR)"]
        end

        subgraph Mod5 ["Module 5: NP-Hard & Approximations"]
            GrahamLPT["Graham's LPT 4/3-Approximation"]
            BranchBound["Exact Branch-and-Bound Scheduler"]
            VertexCover["Vertex Cover 2-Approximation"]
        end

        subgraph Mod6 ["Module 6: Randomized & Parallel"]
            RandQuick["Randomized QuickSort (Las Vegas)"]
            UnivHash["Universal Hashing"]
            Reservoir["Reservoir Sampling (O(k))"]
            ParallelScan["Blelloch Parallel Prefix Sum (T1, T_inf)"]
        end
    end

    UI <--> API
    API <--> Engine
```

---

## Detailed Directory Structure (`D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02`)

```
D:\Java_2nd yr\DSA-03\Project_DSA-03\PRJ_02\
├── src/
│   └── com/
│       └── hospital/
│           ├── Main.java                                   # Terminal CLI & Pipeline runner
│           ├── WebServerMain.java                          # Embedded HTTP Server & REST API
│           ├── ds/                                         # Module 1: Zero-Dependency Data Structures
│           │   ├── CustomArrayList.java
│           │   ├── CustomLinkedList.java
│           │   ├── CustomHashMap.java
│           │   ├── CustomMinHeap.java
│           │   ├── CustomQueue.java
│           │   ├── CustomStack.java
│           │   ├── CustomDisjointSetUnion.java
│           │   └── Pair.java
│           ├── model/                                      # Clinical & Operational Models
│           │   ├── Bed.java
│           │   ├── BedStatus.java
│           │   ├── WardType.java
│           │   ├── Patient.java
│           │   ├── TriageLevel.java
│           │   ├── OperatingRoom.java
│           │   ├── SurgeryType.java
│           │   ├── Surgeon.java
│           │   ├── SurgicalProcedure.java
│           │   ├── ScheduledSlot.java
│           │   └── ScheduleResult.java
│           ├── algorithms/
│           │   ├── strings/                                # Module 2: String Algorithms
│           │   │   ├── KMPMatcher.java
│           │   │   ├── ZFunctionMatcher.java
│           │   │   ├── RabinKarpMatcher.java
│           │   │   ├── AhoCorasickTriage.java
│           │   │   └── SuffixArrayKasai.java
│           │   ├── dp/                                     # Module 3: Advanced DP
│           │   │   ├── WagnerFischerEditDistance.java
│           │   │   ├── SequenceAlignment.java
│           │   │   ├── BitmaskTurnaroundDP.java
│           │   │   └── IntervalDPScheduler.java
│           │   ├── flow/                                   # Module 4: Network Flow
│           │   │   ├── ResidualGraph.java
│           │   │   ├── EdmondsKarpMaxFlow.java
│           │   │   ├── DinicMaxFlow.java
│           │   │   ├── MinCutAnalyzer.java
│           │   │   ├── BipartiteMatcher.java
│           │   │   └── MinCostMaxFlow.java
│           │   ├── approx/                                 # Module 5: NP-Hard & Approximations
│           │   │   ├── GrahamLPTScheduler.java
│           │   │   ├── ListScheduler.java
│           │   │   ├── ExactBranchAndBoundScheduler.java
│           │   │   └── VertexCover2Approximation.java
│           │   └── randomparallel/                         # Module 6: Randomized & Parallel
│           │       ├── RandomizedQuickSort.java
│           │       ├── UniversalHashLookup.java
│           │       ├── ReservoirSampler.java
│           │       ├── ParallelPrefixSum.java
│           │       └── WorkSpanAnalyzer.java
│           ├── engine/                                     # Unified High-Level Scheduling Engine
│           │   ├── HospitalState.java
│           │   ├── SchedulingEngine.java
│           │   ├── SimulationManager.java
│           │   └── QualityReporter.java
│           └── server/                                     # HTTP Server & REST API Handlers
│               ├── SimpleJson.java                         # Zero-dependency JSON serializer/parser
│               ├── ApiRouter.java
│               └── handlers/
│                   ├── AuthHandler.java
│                   ├── ScheduleHandler.java
│                   ├── FlowHandler.java
│                   ├── BedHandler.java
│                   ├── TriageHandler.java
│                   ├── SimulationHandler.java
│                   └── ReportHandler.java
├── test/
│   └── com/
│       └── hospital/
│           └── test/
│               ├── DataStructuresTest.java
│               ├── StringAlgorithmsTest.java
│               ├── DynamicProgrammingTest.java
│               ├── NetworkFlowTest.java
│               ├── ApproximationTest.java
│               ├── RandomizedParallelTest.java
│               └── FullSystemIntegrationTest.java
├── web/                                                    # Modern Web Frontend (HTML5/CSS3/ES6)
│   ├── index.html                                          # Single Page App Shell
│   ├── css/
│   │   ├── style.css                                       # Core Styles, Dark/Light Themes, Layout
│   │   └── components.css                                  # Gantt, Beds Grid, Flow Graph, Badges
│   ├── js/
│   │   ├── app.js                                          # App Coordinator & State Manager
│   │   ├── api.js                                          # REST API Client wrapper
│   │   ├── theme.js                                        # Dark/Light Mode Theme Switcher
│   │   ├── auth.js                                         # Login & Role Management
│   │   ├── gantt.js                                        # Interactive OR Gantt Chart Renderer
│   │   ├── bedgrid.js                                      # Bed Ward Status Grid Renderer
│   │   ├── flowview.js                                     # Network Flow & Min-Cut Canvas visualizer
│   │   ├── triage.js                                       # Aho-Corasick Live Triage UI
│   │   ├── compare.js                                      # LPT vs Exact Benchmark Comparison UI
│   │   └── reports.js                                      # Quality & Capacity Analytics Reports
└── README.md                                               # Comprehensive Academic & Operational Guide
```

---

## Key Modules & Algorithm Implementation Details

### 1. Zero-Dependency Custom Data Structures (Module 1)
- `CustomArrayList<T>`: Dynamic array with automatic geometric doubling ($1.5\times$ / $2\times$), amortized $O(1)$ insertions.
- `CustomHashMap<K, V>`: Separate chaining hash table with prime modulus bucket resizing and load factor tracking ($0.75$).
- `CustomMinHeap<T>`: Binary heap with index tracking for $O(\log n)$ decrease-key and $O(1)$ peek.
- `CustomDisjointSetUnion`: Union-Find with union by rank and path compression ($O(\alpha(n))$).
- `CustomQueue<T>` & `CustomStack<T>`: Pure array-backed/linked FIFO and LIFO structures.

### 2. String Algorithms & Emergency Triage (Module 2)
- `AhoCorasickTriage`: Multi-pattern search trie with failure links and dictionary output links. Scans unbounded clinical text in $O(N + M + K)$ time to detect critical conditions (e.g., "cardiac arrest", "massive hemorrhage", "epidural hematoma", "septic shock") and automatically promotes patients to Trauma Level-1 or Emergency Priority.
- `SuffixArrayKasai`: Computes Suffix Array ($O(n \log^2 n)$) and LCP array ($O(n)$ via Kasai) to identify maximal common diagnostic strings across EHR records.
- `KMPMatcher`, `ZFunctionMatcher`, `RabinKarpMatcher`: Linear single-pattern matching with polynomial rolling double-hashing.

### 3. Advanced Dynamic Programming (Module 3)
- `BitmaskTurnaroundDP`: Solves the OR turnaround setup & sterilization sequence as an exact Traveling Salesperson Problem (TSP) with bitmask states $O(n^2 2^n)$. Given $n$ scheduled procedures in an OR suite and a transition matrix $C[i][j]$ (cleanup, sterilization, equipment changeover between procedure type $i$ and $j$), computes the minimal total dead time permutation.
- `WagnerFischerEditDistance` & `SequenceAlignment`: Computes Levenshtein/Damerau distances for fuzzy search and Needleman-Wunsch global alignment for surgical pathway validation.
- `IntervalDPScheduler`: Finds maximum weight non-overlapping procedure allocations.

### 4. Network Flow & Bottleneck Discovery (Module 4)
- `DinicMaxFlow` & `EdmondsKarpMaxFlow`: Constructs hospital flow network `Source -> Emergency/Elective Triage -> OR Suites -> PACU Beds -> ICU/General Wards -> Sink`.
- `MinCutAnalyzer`: Runs BFS from source on the residual graph after max-flow convergence. Identifies the exact bottleneck cut edges (e.g., determining if intake is choked by PACU bed deficits or OR room shortage).
- `BipartiteMatcher`: Maximum bipartite matching to assign specialized surgeons to compatible operating rooms with required equipment.

### 5. NP-Hard Scheduling & Approximation Algorithms (Module 5)
- `GrahamLPTScheduler`: Implements Longest Processing Time (LPT) greedy 4/3-approximation algorithm for the NP-hard $P \parallel C_{\max}$ identical parallel machine makespan minimization problem. Guarantees makespan $\le (4/3 - 1/(3m)) \times \text{OPT}$.
- `ExactBranchAndBoundScheduler`: Depth-first branch-and-bound with lower bounding (max load and remaining work bounds) to compute the exact optimal makespan for smaller workloads and benchmark approximation accuracy.
- `VertexCover2Approximation`: Resolves shared resource conflict graphs (overlapping equipment requests) using 2-approximation maximal matching.

### 6. Randomized & Parallel Algorithms (Module 6)
- `RandomizedQuickSort`: Las Vegas quicksort with randomized pivot selection guaranteeing expected $O(n \log n)$ triage sorting regardless of adversarial input order.
- `ReservoirSampler`: Algorithm R sampling $k$ elements uniformly at random from an unbounded stream of emergency arrivals.
- `ParallelPrefixSum`: Parallel Blelloch scan implementation simulating work-span analysis ($T_1 = O(n), T_\infty = O(\log n)$) for cumulative hospital bed-hour workload forecasting.

---

## Frontend UI Features & User Experience

1. **Authentication & Role Selection**:
   - Role badges: Admin, Chief Medical Officer, Operations Scheduler, Triage Nurse.
   - Quick-login demo buttons with pre-filled credentials.
2. **Dark / Light Theme Toggle**:
   - Modern slate-dark palette (high contrast, hospital neon accents: teal, emerald, amber, rose).
   - Crisp clean-light medical palette.
   - Persisted across reloads in `localStorage`.
3. **Multi-OR Gantt Interactive Timeline**:
   - Live visual blocks per room with procedure name, patient ID, surgeon, duration, and status.
   - Color coding by Triage Level (Emergency / Urgent / Elective).
   - Setup/cleaning turnaround buffers visually highlighted between surgeries.
4. **Bed Ward Grid**:
   - Interactive bed matrix separated by wards (ICU, PACU, Surgical, General).
   - Real-time status indicators (Available, Occupied, Cleaning, Reserved, Emergency Quarantine).
   - Quick-click bed modal for patient details and manual reassignment.
5. **Network Capacity & Bottleneck Graph**:
   - Visual flow diagram with live edge capacities and flows.
   - Distinct red highlight over the Min-Cut bottleneck tier.
6. **Live Emergency Triage Portal**:
   - Real-time text area to type or paste emergency EHR notes.
   - Instant Aho-Corasick keyword highlight tags and automated triage score calculation.
7. **Simulation Sandbox**:
   - Buttons to trigger: "Code Blue Arrival", "Emergency Trauma Surge", "OR Overrun (+45m)", "Bed Sanitization Delay".
   - Watch the schedule dynamically re-optimize in real time.

---

## Verification Plan

### Automated Tests
1. Unit tests for each custom data structure (no exceptions, proper resizing, heap property maintenance).
2. Algorithmic unit tests for all 6 modules:
   - KMP, Z-Function, Rabin-Karp, Aho-Corasick keyword detection.
   - Wagner-Fischer edit distance, Bitmask TSP optimal path calculation.
   - Edmonds-Karp & Dinic max-flow correctness, Min-Cut capacity calculation.
   - Graham LPT 4/3-bound verification against exact Branch-and-Bound optimal solution.
   - Randomized Quicksort stability & Reservoir sampling distribution.
3. Full system integration test executing realistic hospital simulation cycles.

### Manual Verification
1. Start backend server via direct `java` command:
   ```powershell
   javac -d bin (Get-ChildItem -Recurse -Filter *.java src,test | ForEach-Object FullName)
   java -cp bin com.hospital.WebServerMain 8080
   ```
2. Open `http://localhost:8080` in web browser.
3. Test login with `admin` / `admin123`.
4. Toggle between Dark and Light mode.
5. Trigger automated schedule generation using Graham's LPT algorithm.
6. View OR Gantt timeline, Bed Ward distribution, and Min-Cut capacity bottleneck.
7. Test Aho-Corasick triage with sample medical notes.
8. Inject emergency arrivals and verify real-time rescheduling without conflicts.
