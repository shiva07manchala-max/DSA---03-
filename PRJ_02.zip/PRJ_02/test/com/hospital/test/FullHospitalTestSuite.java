package com.hospital.test;

import com.hospital.algorithms.approx.ExactBranchAndBoundScheduler;
import com.hospital.algorithms.approx.GrahamLPTScheduler;
import com.hospital.algorithms.approx.MultiObjectiveOptimizationEngine;
import com.hospital.algorithms.approx.VertexCover2Approximation;
import com.hospital.algorithms.dp.BitmaskTurnaroundDP;
import com.hospital.algorithms.dp.SequenceAlignment;
import com.hospital.algorithms.dp.WagnerFischerEditDistance;
import com.hospital.algorithms.flow.BipartiteMatcher;
import com.hospital.algorithms.flow.DinicMaxFlow;
import com.hospital.algorithms.flow.MinCutAnalyzer;
import com.hospital.algorithms.flow.ResidualGraph;
import com.hospital.algorithms.randomparallel.ParallelPrefixSum;
import com.hospital.algorithms.randomparallel.RandomizedQuickSort;
import com.hospital.algorithms.randomparallel.ReservoirSampler;
import com.hospital.algorithms.randomparallel.UniversalHashLookup;
import com.hospital.algorithms.strings.AhoCorasickTriage;
import com.hospital.algorithms.strings.KMPMatcher;
import com.hospital.algorithms.strings.SuffixArrayKasai;
import com.hospital.algorithms.strings.ZFunctionMatcher;
import com.hospital.ds.*;
import com.hospital.engine.*;
import com.hospital.model.*;

/**
 * Comprehensive Automated Test Suite covering Modules 1 through 6,
 * Advanced Multi-Objective Optimization, State Persistence, and Telemetry Engine.
 */
public class FullHospitalTestSuite {
    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println(" 🧪 RUNNING EXPANDED AUTOMATED UNIT & INTEGRATION TEST SUITE (DSA-3)");
        System.out.println("================================================================================\n");

        testModule1DataStructures();
        testModule2StringAlgorithms();
        testModule3DynamicProgramming();
        testModule4NetworkFlow();
        testModule5ApproximationAlgorithms();
        testModule6RandomizedAndParallel();
        testFullSystemIntegration();
        testAdvancedBackendUpgrades();

        System.out.println("\n================================================================================");
        System.out.println(String.format(" 📊 FINAL RESULTS: %d PASSED, %d FAILED (Success Rate: %.1f%%)",
                testsPassed, testsFailed, (testsPassed + testsFailed > 0) ? (100.0 * testsPassed / (testsPassed + testsFailed)) : 100.0));
        System.out.println("================================================================================");

        if (testsFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            System.out.println("  [PASS] " + testName);
            testsPassed++;
        } else {
            System.err.println("  [FAIL] " + testName);
            testsFailed++;
        }
    }

    private static void testModule1DataStructures() {
        System.out.println("--- Testing Module 1: Zero-Dependency Data Structures ---");

        // CustomArrayList
        CustomArrayList<Integer> list = new CustomArrayList<>();
        for (int i = 0; i < 25; i++) list.add(i);
        assertTrue("CustomArrayList geometric resizing & size", list.size() == 25 && list.get(24) == 24);
        list.remove(0);
        assertTrue("CustomArrayList removal shifting", list.size() == 24 && list.get(0) == 1);

        // CustomHashMap
        CustomHashMap<String, Integer> map = new CustomHashMap<>();
        map.put("ICU-1", 100);
        map.put("ICU-2", 200);
        assertTrue("CustomHashMap put and get", map.get("ICU-1") == 100 && map.get("ICU-2") == 200);
        assertTrue("CustomHashMap keySet size", map.keySet().size() == 2);

        // CustomMinHeap
        CustomMinHeap<Integer> heap = new CustomMinHeap<>();
        heap.insert(50);
        heap.insert(10);
        heap.insert(30);
        assertTrue("CustomMinHeap extractMin priority", heap.extractMin() == 10 && heap.extractMin() == 30 && heap.extractMin() == 50);

        // CustomDisjointSetUnion
        CustomDisjointSetUnion dsu = new CustomDisjointSetUnion(10);
        dsu.union(1, 2);
        dsu.union(2, 3);
        assertTrue("CustomDisjointSetUnion connectivity", dsu.connected(1, 3) && !dsu.connected(1, 4));
    }

    private static void testModule2StringAlgorithms() {
        System.out.println("\n--- Testing Module 2: String Processing & Triage Automaton ---");

        // KMP
        CustomArrayList<Integer> kmpMatches = KMPMatcher.search("PATIENT_CARDIAC_ARREST_ADMISSION", "CARDIAC");
        assertTrue("KMP pattern search index", kmpMatches.size() == 1 && kmpMatches.get(0) == 8);

        // Z-Function
        CustomArrayList<Integer> zMatches = ZFunctionMatcher.search("PATIENT_TRAUMA_EMERGENCY_TRAUMA", "TRAUMA");
        assertTrue("Z-Algorithm multi-match detection", zMatches.size() == 2);

        // Aho-Corasick Triage
        AhoCorasickTriage triage = new AhoCorasickTriage();
        String report = "54yo male presented with severe acute appendicitis and fever.";
        TriageLevel level = triage.inferOverallTriage(report);
        assertTrue("Aho-Corasick emergency triage classification", level == TriageLevel.LEVEL_2_URGENT);

        // Aho-Corasick extended terms
        String emergencyReport = "Trauma victim in severe shock following aortic dissection.";
        TriageLevel emLevel = triage.inferOverallTriage(emergencyReport);
        assertTrue("Aho-Corasick extended life-threatening pattern matching", emLevel == TriageLevel.LEVEL_1_EMERGENCY);

        // Suffix Array & Kasai LCP
        String s1 = "ACUTE_MYOCARDIAL_INFARCTION";
        String s2 = "SUSPECTED_MYOCARDIAL_INJURY";
        String lcs = SuffixArrayKasai.longestCommonSubstring(s1, s2);
        assertTrue("Suffix Array Kasai Longest Common Substring", lcs.equals("_MYOCARDIAL_IN"));
    }

    private static void testModule3DynamicProgramming() {
        System.out.println("\n--- Testing Module 3: Dynamic Programming ---");

        // Edit Distance
        int dist = WagnerFischerEditDistance.computeDamerauLevenshtein("Craniotmy", "Craniotomy");
        assertTrue("Wagner-Fischer Damerau Edit Distance typo-correction", dist == 1);

        // Sequence Alignment
        SequenceAlignment.AlignmentResult align = SequenceAlignment.needlemanWunsch("ACGA", "ACTA", 1, -1, -2);
        assertTrue("Needleman-Wunsch global alignment", align.score > 0);

        // Bitmask Turnaround TSP
        int[][] cost = {
                {0, 10, 15, 20},
                {10, 0, 35, 25},
                {15, 35, 0, 30},
                {20, 25, 30, 0}
        };
        BitmaskTurnaroundDP.TSPResult tsp = BitmaskTurnaroundDP.solveOptimalSequence(cost);
        assertTrue("Bitmask Turnaround TSP optimization", tsp.minCost > 0 && tsp.optimalOrder.length == 4);
    }

    private static void testModule4NetworkFlow() {
        System.out.println("\n--- Testing Module 4: Network Flow & Min-Cut ---");

        ResidualGraph g = new ResidualGraph(4);
        g.addEdge(0, 1, 10);
        g.addEdge(0, 2, 5);
        g.addEdge(1, 3, 5);
        g.addEdge(2, 3, 10);
        g.addEdge(1, 2, 15);

        int maxFlow = DinicMaxFlow.computeMaxFlow(g, 0, 3);
        assertTrue("Dinic max-flow computation", maxFlow == 15);

        // Bipartite Matching
        boolean[][] compat = {
                {true, false, true},
                {true, true, false},
                {false, true, false}
        };
        BipartiteMatcher.MatchingResult match = BipartiteMatcher.computeMaxMatching(3, 3, compat);
        assertTrue("Bipartite surgeon-to-room matching", match.matchCount == 3);
    }

    private static void testModule5ApproximationAlgorithms() {
        System.out.println("\n--- Testing Module 5: NP-Hard Approximations ---");

        CustomArrayList<Patient> list = new CustomArrayList<>();
        list.add(new Patient("P1", "Test1", 50, "M", TriageLevel.LEVEL_4_ELECTIVE, "", "S1", 120, WardType.GENERAL, 10, 100, 0));
        list.add(new Patient("P2", "Test2", 50, "M", TriageLevel.LEVEL_4_ELECTIVE, "", "S2", 90, WardType.GENERAL, 10, 100, 0));
        list.add(new Patient("P3", "Test3", 50, "M", TriageLevel.LEVEL_4_ELECTIVE, "", "S3", 60, WardType.GENERAL, 10, 100, 0));
        list.add(new Patient("P4", "Test4", 50, "M", TriageLevel.LEVEL_4_ELECTIVE, "", "S4", 30, WardType.GENERAL, 10, 100, 0));

        int exactOpt = ExactBranchAndBoundScheduler.computeOptimalMakespan(list, 2);
        assertTrue("Exact Branch-and-Bound optimal makespan", exactOpt == 150);

        // Vertex Cover 2-Approx
        CustomArrayList<VertexCover2Approximation.Edge> edges = new CustomArrayList<>();
        edges.add(new VertexCover2Approximation.Edge(0, 1, "R1", "R2"));
        edges.add(new VertexCover2Approximation.Edge(1, 2, "R2", "R3"));
        VertexCover2Approximation.VertexCoverResult vc = VertexCover2Approximation.compute2ApproxVertexCover(3, edges, null);
        assertTrue("Vertex Cover 2-Approximation bounds", vc.size <= 2 * 1);
    }

    private static void testModule6RandomizedAndParallel() {
        System.out.println("\n--- Testing Module 6: Randomized & Parallel Algorithms ---");

        // Randomized QuickSort
        Patient[] arr = new Patient[4];
        arr[0] = new Patient("P1", "A", 30, "M", TriageLevel.LEVEL_4_ELECTIVE, "", "", 10, WardType.GENERAL, 1, 100, 0);
        arr[1] = new Patient("P2", "B", 30, "M", TriageLevel.LEVEL_1_EMERGENCY, "", "", 10, WardType.GENERAL, 1, 100, 0);
        arr[2] = new Patient("P3", "C", 30, "M", TriageLevel.LEVEL_2_URGENT, "", "", 10, WardType.GENERAL, 1, 100, 0);
        arr[3] = new Patient("P4", "D", 30, "M", TriageLevel.LEVEL_3_SEMI_URGENT, "", "", 10, WardType.GENERAL, 1, 100, 0);

        RandomizedQuickSort.sortPatients(arr);
        assertTrue("Randomized QuickSort priority correctness",
                arr[0].getTriageLevel() == TriageLevel.LEVEL_1_EMERGENCY &&
                        arr[3].getTriageLevel() == TriageLevel.LEVEL_4_ELECTIVE);

        // Parallel Blelloch Scan
        int[] data = {1, 2, 3, 4};
        int[] scan = ParallelPrefixSum.blellochScanExclusive(data);
        assertTrue("Blelloch Parallel Prefix Scan", scan[0] == 0 && scan[1] == 1 && scan[2] == 3 && scan[3] == 6);
    }

    private static void testFullSystemIntegration() {
        System.out.println("\n--- Testing Full System End-to-End Integration ---");
        HospitalState state = HospitalDataLoader.loadInitialState();
        SchedulingEngine.ScheduleReport report = SchedulingEngine.runMasterSchedule(state);

        assertTrue("Master Pipeline scheduled all patients", report.totalPatientsScheduled > 0);
        assertTrue("OR utilization calculated", report.orUtilizationPercentage > 0.0);
        assertTrue("Bed occupancy calculated", report.bedOccupancyPercentage > 0.0);
        assertTrue("Min-cut bottlenecks detected", report.bottleneckCuts.size() > 0);
    }

    private static void testAdvancedBackendUpgrades() {
        System.out.println("\n--- Testing Advanced Backend Upgrades ---");
        HospitalState state = HospitalDataLoader.loadInitialState();

        // 1. Multi-Objective Strategy Optimization
        MultiObjectiveOptimizationEngine.MultiObjectiveResult lptRes = MultiObjectiveOptimizationEngine.optimize(
                state.getAllPatients(), state.getAllOperatingRooms(), state.getAllSurgeons(), 480,
                MultiObjectiveOptimizationEngine.SchedulingStrategy.GRAHAM_LPT
        );
        assertTrue("MultiObjective Graham LPT execution", lptRes.makespanMinutes > 0 && lptRes.assignedSlots.size() > 0);

        MultiObjectiveOptimizationEngine.MultiObjectiveResult wsptRes = MultiObjectiveOptimizationEngine.optimize(
                state.getAllPatients(), state.getAllOperatingRooms(), state.getAllSurgeons(), 480,
                MultiObjectiveOptimizationEngine.SchedulingStrategy.WEIGHTED_SPT
        );
        assertTrue("MultiObjective Weighted SPT execution", wsptRes.makespanMinutes > 0);

        MultiObjectiveOptimizationEngine.MultiObjectiveResult eddRes = MultiObjectiveOptimizationEngine.optimize(
                state.getAllPatients(), state.getAllOperatingRooms(), state.getAllSurgeons(), 480,
                MultiObjectiveOptimizationEngine.SchedulingStrategy.EARLIEST_DUE_DATE
        );
        assertTrue("MultiObjective Earliest Due Date (EDD) execution", eddRes.makespanMinutes > 0);

        // 2. Surgeon Workload & Fatigue Analyzer
        SurgeonWorkloadAnalyzer.WorkloadReport wlReport = SurgeonWorkloadAnalyzer.analyze(state.getAllSurgeons(), state.getAllOperatingRooms());
        assertTrue("Surgeon Workload & Fatigue Analysis", wlReport.surgeonMetrics.size() == state.getAllSurgeons().size());

        // 3. State Persistence Manager
        String jsonSnapshot = StatePersistenceManager.serializeStateToJson(state);
        assertTrue("State Persistence JSON Serialization", jsonSnapshot != null && jsonSnapshot.contains("simulationMinute"));
        boolean saved = StatePersistenceManager.saveSnapshotToFile(state, "data/test_snapshot.json");
        assertTrue("State Persistence File Snapshot Backup", saved);

        // 4. Telemetry Clock Engine
        int initialMinute = state.getCurrentSimulationMinute();
        // Mark one bed as cleaning
        state.getAllBeds().get(0).setStatus(BedStatus.CLEANING);
        TelemetryClockEngine.ClockAdvanceReport clockReport = TelemetryClockEngine.advanceTime(state, 30);
        assertTrue("Telemetry Clock Advancement", clockReport.newMinute == initialMinute + 30 && clockReport.bedsCleanedCount >= 1);

        // 5. Patient Dynamic Ingestion & Auto-Triage
        String patientJson = "{\"name\": \"Vikramaditya\", \"age\": 60, \"gender\": \"Male\", \"clinicalReport\": \"Sudden cardiac arrest with severe hypotension\", \"duration\": 180}";
        Patient admitted = PatientAdmissionManager.admitNewPatient(state, patientJson);
        assertTrue("Patient Dynamic Admission with Auto-Triage", admitted != null && admitted.getTriageLevel() == TriageLevel.LEVEL_1_EMERGENCY);
    }
}
