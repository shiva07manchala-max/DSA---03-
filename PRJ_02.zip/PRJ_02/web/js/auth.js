// Authentication & Role Management Module
const AuthModule = (() => {
    const TOKEN_KEY = 'hospital_auth_token';
    const USER_KEY = 'hospital_auth_user';

    const init = () => {
        setupListeners();
        checkSession();
    };

    const setupListeners = () => {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const u = document.getElementById('loginUsername').value;
                const p = document.getElementById('loginPassword').value;
                await performLogin(u, p);
            });
        }

        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', performLogout);
        }

        // Quick demo role chips
        document.querySelectorAll('.role-chip-card, .role-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const u = chip.getAttribute('data-user');
                const p = chip.getAttribute('data-pass');
                document.getElementById('loginUsername').value = u;
                document.getElementById('loginPassword').value = p;
                performLogin(u, p);
            });
        });

        // Password visibility toggle
        const togglePassBtn = document.getElementById('togglePasswordBtn');
        if (togglePassBtn) {
            togglePassBtn.addEventListener('click', () => {
                const passInput = document.getElementById('loginPassword');
                if (passInput.type === 'password') {
                    passInput.type = 'text';
                    togglePassBtn.textContent = '🙈';
                } else {
                    passInput.type = 'password';
                    togglePassBtn.textContent = '👁️';
                }
            });
        }
    };

    const performLogin = async (username, password) => {
        const errElem = document.getElementById('loginError');
        if (errElem) errElem.style.display = 'none';

        try {
            const res = await ApiClient.login(username, password);
            if (res.success) {
                localStorage.setItem(TOKEN_KEY, res.token);
                localStorage.setItem(USER_KEY, JSON.stringify({
                    username: res.user,
                    role: res.role,
                    name: res.name
                }));
                showDashboard(res);
                if (window.AppCoordinator) {
                    window.AppCoordinator.refreshAllData();
                }
            } else {
                showError(res.message || 'Login failed. Please check credentials.');
            }
        } catch (err) {
            showError('Could not reach backend server. Make sure the Java Web Server is running on port 8080.');
        }
    };

    const performLogout = () => {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
        document.getElementById('authView').style.display = 'flex';
        document.getElementById('appView').style.display = 'none';
    };

    const checkSession = () => {
        const token = localStorage.getItem(TOKEN_KEY);
        const userStr = localStorage.getItem(USER_KEY);
        if (token && userStr) {
            try {
                const user = JSON.parse(userStr);
                showDashboard(user);
            } catch (e) {
                performLogout();
            }
        } else {
            performLogout();
        }
    };

    const showDashboard = (user) => {
        document.getElementById('authView').style.display = 'none';
        document.getElementById('appView').style.display = 'flex';

        const nameElem = document.getElementById('sidebarUserName');
        const roleElem = document.getElementById('sidebarUserRole');
        const avatarElem = document.getElementById('sidebarAvatar');

        if (nameElem) nameElem.textContent = user.name || user.username;
        if (roleElem) roleElem.textContent = user.role;
        if (avatarElem) {
            const initial = (user.name || user.username || 'A').charAt(0).toUpperCase();
            avatarElem.textContent = initial;
        }
    };

    const showError = (msg) => {
        const errElem = document.getElementById('loginError');
        if (errElem) {
            errElem.textContent = msg;
            errElem.style.display = 'block';
        }
    };

    return { init, performLogin, performLogout };
})();

document.addEventListener('DOMContentLoaded', AuthModule.init);
