// Main App Coordinator & State Orchestrator
const AppCoordinator = (() => {

    const init = () => {
        setupNavigation();
        setupSimulationTriggers();
        setupModals();
        refreshAllData();
    };

    const setupNavigation = () => {
        const navItems = document.querySelectorAll('.nav-item');
        const sections = document.querySelectorAll('.app-section');

        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const targetTab = item.getAttribute('data-tab');

                navItems.forEach(n => n.classList.remove('active'));
                item.classList.add('active');

                sections.forEach(s => {
                    if (s.id === `section-${targetTab}`) {
                        s.style.display = 'block';
                    } else {
                        s.style.display = 'none';
                    }
                });

                if (targetTab === 'flow' && window.FlowViewModule && window.latestFlowData) {
                    window.FlowViewModule.render(window.latestFlowData);
                }
                if (targetTab === 'reports' && window.ReportsModule) {
                    window.ReportsModule.loadReport();
                }
            });
        });
    };

    const refreshAllData = async () => {
        try {
            // Fetch Schedule Data
            const scheduleRes = await ApiClient.getSchedule();
            if (scheduleRes.success) {
                updateKpis(scheduleRes);
                GanttModule.render(scheduleRes);
                CompareModule.render(scheduleRes);
            }

            // Fetch Beds Data
            const bedRes = await ApiClient.getBeds();
            if (bedRes.success) {
                BedGridModule.render(bedRes);
            }

            // Fetch Flow Data
            const flowRes = await ApiClient.getFlowAnalytics();
            if (flowRes.success) {
                window.latestFlowData = flowRes;
                FlowViewModule.render(flowRes);
            }
        } catch (err) {
            console.warn('Backend not yet ready or polling failed:', err);
        }
    };

    const updateKpis = (data) => {
        const setVal = (id, val) => {
            const elem = document.getElementById(id);
            if (elem) elem.textContent = val;
        };

        const totalHours = (data.makespanMinutes / 60).toFixed(1);
        setVal('kpiMakespan', `${data.makespanMinutes}m (${totalHours}h)`);
        setVal('kpiUtilization', `${data.orUtilizationPercentage.toFixed(1)}%`);
        setVal('kpiBedOccupancy', `${data.bedOccupancyPercentage.toFixed(1)}%`);
        setVal('kpiTurnaroundSaved', `${data.turnaroundTimeSavedMinutes} mins`);
        setVal('kpiPatientsCount', `${data.totalPatientsScheduled} (${data.emergencyPatientsHandled} Emergencies)`);
    };

    const setupSimulationTriggers = () => {
        const btnCodeBlue = document.getElementById('btnSimulateCodeBlue');
        if (btnCodeBlue) {
            btnCodeBlue.addEventListener('click', async () => {
                await ApiClient.injectEmergency({
                    name: "Emergency Code Blue Arrival",
                    age: 52,
                    gender: "Male",
                    clinicalReport: "Sudden collapse with acute massive hemorrhage and cardiac arrest symptoms",
                    procedure: "Emergency Trauma Laparotomy",
                    duration: 120
                });
                alert('🚨 Code Blue Emergency Injected! Schedule dynamically updated.');
                refreshAllData();
            });
        }

        const btnTraumaSurge = document.getElementById('btnSimulateTraumaSurge');
        if (btnTraumaSurge) {
            btnTraumaSurge.addEventListener('click', async () => {
                await ApiClient.injectEmergency({
                    name: "Multiple Highway Trauma Inbound",
                    age: 28,
                    gender: "Female",
                    clinicalReport: "Motorcycle collision resulting in acute epidural hematoma and compound fracture",
                    procedure: "Emergency Craniotomy",
                    duration: 150
                });
                alert('🚨 Trauma Level-1 Injected! Real-time priority preemption executed.');
                refreshAllData();
            });
        }

        const btnRefreshMaster = document.getElementById('btnRefreshMaster');
        if (btnRefreshMaster) {
            btnRefreshMaster.addEventListener('click', refreshAllData);
        }
    };

    const setupModals = () => {
        // Close buttons for modals
        document.querySelectorAll('.modal-close-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.modal-backdrop').forEach(m => m.classList.remove('open'));
            });
        });
    };

    return { init, refreshAllData };
})();

window.AppCoordinator = AppCoordinator;
document.addEventListener('DOMContentLoaded', AppCoordinator.init);
