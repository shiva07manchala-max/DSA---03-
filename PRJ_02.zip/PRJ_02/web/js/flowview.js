// Network Flow & Min-Cut Bottleneck Canvas Visualizer
const FlowViewModule = (() => {
    const render = (flowData) => {
        const canvas = document.getElementById('flowCanvas');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const width = canvas.parentElement.clientWidth || 800;
        const height = 400;
        canvas.width = width;
        canvas.height = height;

        ctx.clearRect(0, 0, width, height);

        // Node layout coordinates
        const positions = [
            { x: 60, y: height / 2, label: 'Source', desc: 'Inflow' },
            { x: 180, y: height / 2, label: 'ER Triage', desc: 'Intake' },
            { x: 340, y: height * 0.25, label: 'Cardiac/Neuro OR', desc: 'Suites 1-2' },
            { x: 340, y: height * 0.5, label: 'Ortho/Gen OR', desc: 'Suites 3-4' },
            { x: 340, y: height * 0.75, label: 'Ambulatory OR', desc: 'Suite 5' },
            { x: 500, y: height * 0.35, label: 'PACU Beds', desc: 'Post-Op' },
            { x: 500, y: height * 0.65, label: 'ICU Beds', desc: 'Intensive' },
            { x: 650, y: height / 2, label: 'General Wards', desc: 'Inpatient' },
            { x: width - 80, y: height / 2, label: 'Sink', desc: 'Discharge' }
        ];

        // Draw edges
        const edges = [
            { u: 0, v: 1, cap: 50 },
            { u: 1, v: 2, cap: 12 },
            { u: 1, v: 3, cap: 16 },
            { u: 1, v: 4, cap: 10 },
            { u: 2, v: 6, cap: 8, bottleneck: true },
            { u: 2, v: 5, cap: 6 },
            { u: 3, v: 5, cap: 10 },
            { u: 3, v: 7, cap: 8 },
            { u: 4, v: 7, cap: 10 },
            { u: 5, v: 7, cap: 10 },
            { u: 6, v: 8, cap: 8, bottleneck: true },
            { u: 7, v: 8, cap: 20 }
        ];

        edges.forEach(e => {
            const p1 = positions[e.u];
            const p2 = positions[e.v];

            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.lineWidth = e.bottleneck ? 3.5 : 2;
            ctx.strokeStyle = e.bottleneck ? '#ef4444' : 'rgba(56, 189, 248, 0.4)';
            ctx.stroke();

            // Label capacity
            const midX = (p1.x + p2.x) / 2;
            const midY = (p1.y + p2.y) / 2 - 6;
            ctx.fillStyle = e.bottleneck ? '#fca5a5' : '#94a3b8';
            ctx.font = '11px JetBrains Mono, monospace';
            ctx.fillText(`cap:${e.cap}`, midX, midY);
        });

        // Draw nodes
        positions.forEach((pos, idx) => {
            const isSource = idx === 0;
            const isSink = idx === positions.length - 1;

            ctx.beginPath();
            ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2);
            ctx.fillStyle = isSource ? '#0284c7' : isSink ? '#10b981' : '#1e293b';
            ctx.fill();
            ctx.lineWidth = 2;
            ctx.strokeStyle = isSource ? '#38bdf8' : isSink ? '#34d399' : 'rgba(255, 255, 255, 0.3)';
            ctx.stroke();

            // Label
            ctx.fillStyle = '#f8fafc';
            ctx.font = 'bold 11px Inter, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(pos.label, pos.x, pos.y + 35);

            ctx.fillStyle = '#94a3b8';
            ctx.font = '10px Inter, sans-serif';
            ctx.fillText(pos.desc, pos.x, pos.y + 47);
        });

        // Render Cut Description List
        const cutListElem = document.getElementById('bottleneckCutsList');
        if (cutListElem && flowData.bottleneckCuts) {
            cutListElem.innerHTML = '';
            flowData.bottleneckCuts.forEach((cut, i) => {
                const li = document.createElement('div');
                li.className = 'cut-banner';
                li.innerHTML = `<span>⚠️ <strong>Bottleneck Cut #${i + 1}:</strong> ${cut.description} (Max Throughput: ${cut.capacity} patients/period)</span>`;
                cutListElem.appendChild(li);
            });
        }
    };

    return { render };
})();
