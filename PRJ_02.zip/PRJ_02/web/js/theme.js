// Theme Switcher Module supporting 6 vibrant healthcare color palettes
const ThemeModule = (() => {
    const THEME_KEY = 'hospital_ui_theme';
    const THEMES = [
        'midnight',
        'clinical-light',
        'cyber-neon',
        'emerald-health',
        'royal-amethyst',
        'ocean-sapphire'
    ];

    const init = () => {
        let savedTheme = localStorage.getItem(THEME_KEY) || 'midnight';
        // Compatibility for legacy 'dark' / 'light'
        if (savedTheme === 'dark') savedTheme = 'midnight';
        if (savedTheme === 'light') savedTheme = 'clinical-light';

        applyTheme(savedTheme);
        setupListeners();
    };

    const setupListeners = () => {
        // Quick toggle button (toggles between current and clinical-light/midnight)
        const toggleBtn = document.getElementById('themeToggleBtn');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => {
                const current = document.documentElement.getAttribute('data-theme') || 'midnight';
                const next = (current === 'clinical-light' || current === 'light') ? 'midnight' : 'clinical-light';
                applyTheme(next);
            });
        }

        // Topbar Dropdown selector
        const themeDropdown = document.getElementById('themeSelectDropdown');
        if (themeDropdown) {
            themeDropdown.addEventListener('change', (e) => {
                applyTheme(e.target.value);
            });
        }

        // Login screen theme pill buttons
        document.querySelectorAll('.theme-pill').forEach(pill => {
            pill.addEventListener('click', () => {
                const selectedTheme = pill.getAttribute('data-theme');
                if (selectedTheme) {
                    applyTheme(selectedTheme);
                }
            });
        });
    };

    const applyTheme = (theme) => {
        if (!THEMES.includes(theme) && theme !== 'dark' && theme !== 'light') {
            theme = 'midnight';
        }

        // Normalize
        let normalizedTheme = theme;
        if (theme === 'dark') normalizedTheme = 'midnight';
        if (theme === 'light') normalizedTheme = 'clinical-light';

        document.documentElement.setAttribute('data-theme', normalizedTheme);
        localStorage.setItem(THEME_KEY, normalizedTheme);

        // Update Toggle Icon
        const toggleBtn = document.getElementById('themeToggleBtn');
        if (toggleBtn) {
            toggleBtn.innerHTML = normalizedTheme === 'clinical-light' ? '🌙' : '☀️';
            toggleBtn.title = normalizedTheme === 'clinical-light' ? 'Switch to Midnight Dark' : 'Switch to Clinical Light';
        }

        // Update Topbar Dropdown
        const themeDropdown = document.getElementById('themeSelectDropdown');
        if (themeDropdown) {
            themeDropdown.value = normalizedTheme;
        }

        // Update Login Theme Pills Active Indicator
        document.querySelectorAll('.theme-pill').forEach(pill => {
            if (pill.getAttribute('data-theme') === normalizedTheme) {
                pill.classList.add('active');
                pill.style.outline = '2px solid #ffffff';
                pill.style.outlineOffset = '2px';
            } else {
                pill.classList.remove('active');
                pill.style.outline = 'none';
            }
        });
    };

    return { init, applyTheme };
})();

document.addEventListener('DOMContentLoaded', ThemeModule.init);
