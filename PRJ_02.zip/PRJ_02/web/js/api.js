// API Client module for REST communication
const ApiClient = (() => {
    const getBaseUrl = () => {
        if (window.location.protocol === 'file:') {
            return 'http://localhost:8080';
        }
        return window.location.origin;
    };

    const request = async (endpoint, method = 'GET', data = null) => {
        const url = `${getBaseUrl()}${endpoint}`;
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('hospital_auth_token') || ''}`
            }
        };

        if (data && (method === 'POST' || method === 'PUT')) {
            options.body = JSON.stringify(data);
        }

        try {
            const res = await fetch(url, options);
            if (!res.ok) {
                throw new Error(`HTTP Error ${res.status}: ${res.statusText}`);
            }
            return await res.json();
        } catch (err) {
            console.error(`API Call failed on ${endpoint}:`, err);
            throw err;
        }
    };

    return {
        login: (username, password) => request('/api/auth/login', 'POST', { username, password }),
        getSchedule: () => request('/api/schedule/run', 'GET'),
        getBeds: () => request('/api/beds', 'GET'),
        updateBed: (bedId, status) => request('/api/beds/update', 'POST', { bedId, status }),
        getFlowAnalytics: () => request('/api/flow/analytics', 'GET'),
        evaluateTriage: (text) => request('/api/triage/evaluate', 'POST', { text }),
        fuzzySearch: (query, target) => request('/api/search/fuzzy', 'POST', { query, target }),
        suffixLcs: (text1, text2) => request('/api/similarity/suffix-lcs', 'POST', { text1, text2 }),
        injectEmergency: (patient) => request('/api/simulate/emergency', 'POST', patient),
        applyOverrun: (roomId, slotId, extraMinutes) => request('/api/simulate/overrun', 'POST', { roomId, slotId, extraMinutes }),
        cancelSlot: (roomId, slotId) => request('/api/simulate/cancel', 'POST', { roomId, slotId }),
        getReport: () => request('/api/reports/analytics', 'GET')
    };
})();
