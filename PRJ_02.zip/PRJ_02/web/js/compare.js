// Algorithm Comparison & Benchmark Lab (Module 5)
const CompareModule = (() => {
    const render = (scheduleData) => {
        const approxRatioElem = document.getElementById('benchmarkApproxRatio');
        const exactOptElem = document.getElementById('benchmarkExactOpt');
        const lptMakespanElem = document.getElementById('benchmarkLptMakespan');
        const empiricalRatioElem = document.getElementById('benchmarkEmpiricalRatio');

        if (!approxRatioElem) return;

        const lptMakespan = scheduleData.makespanMinutes || 0;
        const exactOpt = scheduleData.exactOptimalMakespan || lptMakespan;
        const theoreticalRatio = scheduleData.approxBoundRatio || 1.2667;
        const empiricalRatio = (exactOpt > 0) ? (lptMakespan / exactOpt) : 1.0;

        approxRatioElem.textContent = theoreticalRatio.toFixed(4);
        exactOptElem.textContent = `${exactOpt} mins`;
        lptMakespanElem.textContent = `${lptMakespan} mins`;
        empiricalRatioElem.textContent = `${empiricalRatio.toFixed(4)}x`;

        // Render comparison bar visualizer
        const barLpt = document.getElementById('barLptMakespan');
        const barOpt = document.getElementById('barExactMakespan');
        if (barLpt && barOpt) {
            const maxVal = Math.max(lptMakespan, exactOpt, 1);
            barLpt.style.width = `${(lptMakespan / maxVal) * 100}%`;
            barOpt.style.width = `${(exactOpt / maxVal) * 100}%`;
        }
    };

    return { render };
})();
