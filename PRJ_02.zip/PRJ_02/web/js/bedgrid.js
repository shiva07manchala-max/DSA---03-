// Bed Ward Status & Telemetry Grid Module
const BedGridModule = (() => {
    const render = (bedData) => {
        const wards = {
            'ICU': document.getElementById('wardIcuGrid'),
            'PACU': document.getElementById('wardPacuGrid'),
            'SURGICAL': document.getElementById('wardSurgGrid'),
            'GENERAL': document.getElementById('wardGenGrid')
        };

        // Clear all grids
        Object.values(wards).forEach(grid => {
            if (grid) grid.innerHTML = '';
        });

        const beds = bedData.beds || [];

        beds.forEach(bed => {
            const targetGrid = wards[bed.wardType] || wards['GENERAL'];
            if (!targetGrid) return;

            const card = document.createElement('div');
            card.className = 'bed-card';

            const statusClass = `status-${bed.status.toLowerCase()}`;
            const icon = (bed.status === 'AVAILABLE') ? '🟢' :
                         (bed.status === 'OCCUPIED') ? '🔴' :
                         (bed.status === 'CLEANING') ? '🟡' : '🔵';

            card.innerHTML = `
                <div class="bed-icon">${icon}</div>
                <div class="bed-id">${bed.roomNumber || bed.id}</div>
                <div style="font-size:11px; color:var(--text-muted); margin-top:2px;">
                    ${bed.currentPatientId ? 'Pt: ' + bed.currentPatientId : 'Vacant'}
                </div>
                <span class="bed-status-badge ${statusClass}">${bed.status}</span>
            `;

            card.addEventListener('click', () => openBedModal(bed));
            targetGrid.appendChild(card);
        });
    };

    const openBedModal = (bed) => {
        const modal = document.getElementById('bedDetailModal');
        if (!modal) return;

        document.getElementById('bedModalId').textContent = `${bed.roomNumber} (${bed.id})`;
        document.getElementById('bedModalWard').textContent = bed.wardDisplayName || bed.wardType;
        document.getElementById('bedModalStatus').textContent = bed.status;
        document.getElementById('bedModalPatient').textContent = bed.currentPatientId || 'None (Vacant)';

        // Status action buttons
        document.getElementById('btnSetBedAvailable').onclick = () => updateBedStatus(bed.id, 'AVAILABLE');
        document.getElementById('btnSetBedCleaning').onclick = () => updateBedStatus(bed.id, 'CLEANING');
        document.getElementById('btnSetBedReserved').onclick = () => updateBedStatus(bed.id, 'RESERVED');

        modal.classList.add('open');
    };

    const updateBedStatus = async (bedId, newStatus) => {
        await ApiClient.updateBed(bedId, newStatus);
        document.getElementById('bedDetailModal').classList.remove('open');
        if (window.AppCoordinator) window.AppCoordinator.refreshAllData();
    };

    return { render };
})();
