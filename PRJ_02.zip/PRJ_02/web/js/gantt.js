// High-Precision Multi-OR Gantt Chart Visualizer with Clean Grid Alignment
const GanttModule = (() => {
    let currentScheduleData = null;
    let activeFilter = 'ALL';
    let currentViewMode = 'GANTT'; // 'GANTT' or 'TABLE'

    const init = () => {
        setupFilterListeners();
    };

    const setupFilterListeners = () => {
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                activeFilter = btn.getAttribute('data-filter') || 'ALL';
                if (currentScheduleData) {
                    render(currentScheduleData);
                }
            });
        });

        const toggleViewBtn = document.getElementById('btnToggleGanttView');
        if (toggleViewBtn) {
            toggleViewBtn.addEventListener('click', () => {
                currentViewMode = currentViewMode === 'GANTT' ? 'TABLE' : 'GANTT';
                toggleViewBtn.textContent = currentViewMode === 'GANTT' ? '📋 Switch to Table View' : '📊 Switch to Gantt Timeline';
                document.getElementById('ganttTimelineView').style.display = currentViewMode === 'GANTT' ? 'block' : 'none';
                document.getElementById('ganttTableView').style.display = currentViewMode === 'TABLE' ? 'block' : 'none';
                if (currentScheduleData) render(currentScheduleData);
            });
        }
    };

    const getProcedureIcon = (procName) => {
        const lower = (procName || '').toLowerCase();
        if (lower.includes('bypass') || lower.includes('cabg') || lower.includes('aortic') || lower.includes('cardiac')) return '🫀';
        if (lower.includes('craniotomy') || lower.includes('spine') || lower.includes('spinal') || lower.includes('neuro')) return '🧠';
        if (lower.includes('hip') || lower.includes('fracture') || lower.includes('fixation') || lower.includes('ortho') || lower.includes('knee')) return '🦴';
        if (lower.includes('laparotomy') || lower.includes('trauma') || lower.includes('hemorrhage')) return '🚨';
        if (lower.includes('cataract') || lower.includes('eye') || lower.includes('phaco')) return '👁️';
        return '🔬';
    };

    const formatTime = (totalMin) => {
        const h = Math.floor(totalMin / 60);
        const m = totalMin % 60;
        return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    };

    const render = (scheduleData) => {
        currentScheduleData = scheduleData;
        const container = document.getElementById('ganttRowsContainer');
        const tableBody = document.getElementById('ganttTableBody');
        if (!container) return;

        container.innerHTML = '';
        if (tableBody) tableBody.innerHTML = '';

        const rooms = scheduleData.rooms || [];
        const baseMinute = 480; // 08:00 AM

        // Calculate timeline span: standard 12-hour view (08:00 to 20:00 = 720 mins) or latest makespan
        let maxMinute = 1200; // 20:00 (8:00 PM)
        if (scheduleData.makespanMinutes > maxMinute) {
            maxMinute = Math.ceil((scheduleData.makespanMinutes + 60) / 60) * 60;
        }
        const totalTimelineMinutes = maxMinute - baseMinute;
        const totalHours = totalTimelineMinutes / 60;

        // 1. Render Time Scale Header
        const scaleContainer = document.getElementById('ganttTimeScale');
        if (scaleContainer) {
            scaleContainer.innerHTML = '';
            for (let h = 0; h < totalHours; h++) {
                const tick = document.createElement('div');
                tick.className = 'time-tick';
                const curH = Math.floor((baseMinute + h * 60) / 60);
                tick.textContent = `${String(curH).padStart(2, '0')}:00`;
                scaleContainer.appendChild(tick);
            }
        }

        // 2. Render Rooms & Tracks
        rooms.forEach((room, roomIdx) => {
            const row = document.createElement('div');
            row.className = 'gantt-row';

            // Room Sidebar Card
            const sidebar = document.createElement('div');
            sidebar.className = 'gantt-room-sidebar';

            const roomTag = room.id || `OR-${roomIdx + 1}`;
            const activeSlotsCount = (room.slots || []).length;
            const roomSpanMin = room.makespanMinutes > 0 ? (room.makespanMinutes - baseMinute) : 0;
            const utilPct = totalTimelineMinutes > 0 ? Math.min(100, Math.round((roomSpanMin / totalTimelineMinutes) * 100)) : 0;

            sidebar.innerHTML = `
                <div class="room-badge-row">
                    <span class="room-id-tag">${roomTag}</span>
                    <span class="room-status-dot" title="Operational / Ready"></span>
                    <span style="font-size:10.5px; font-weight:700; color:var(--accent-emerald);">READY</span>
                </div>
                <div class="room-name-text" title="${room.name}">${room.name}</div>
                <div class="room-stats-sub">
                    <span>${activeSlotsCount} Surgeries</span>
                    <span>&bull;</span>
                    <span>${roomSpanMin}m (${utilPct}% Load)</span>
                </div>
            `;
            row.appendChild(sidebar);

            // Track Container
            const trackContainer = document.createElement('div');
            trackContainer.className = 'gantt-track-container';

            // Vertical Hour Gridlines
            const gridlines = document.createElement('div');
            gridlines.className = 'gantt-gridlines';
            for (let h = 0; h < totalHours; h++) {
                const col = document.createElement('div');
                col.className = 'gridline-col';
                gridlines.appendChild(col);
            }
            trackContainer.appendChild(gridlines);

            // Filter slots
            const slotsToRender = (room.slots || []).filter(slot => {
                if (activeFilter === 'ALL') return true;
                if (activeFilter === 'EMERGENCY') return slot.triageLevel <= 2;
                if (activeFilter === 'ELECTIVE') return slot.triageLevel >= 3;
                return true;
            });

            // Render Slots
            slotsToRender.forEach(slot => {
                const startOffset = Math.max(0, slot.startMinute - baseMinute);
                const duration = slot.endMinute - slot.startMinute;

                const leftPct = (startOffset / totalTimelineMinutes) * 100;
                const widthPct = Math.max(4.0, (duration / totalTimelineMinutes) * 100);

                const block = document.createElement('div');
                block.className = `gantt-block block-triage-${slot.triageLevel || 4}`;
                block.style.left = `${leftPct}%`;
                block.style.width = `calc(${widthPct}% - 6px)`;

                const icon = getProcedureIcon(slot.procedureName);
                const timeStr = `${formatTime(slot.startMinute)}-${formatTime(slot.endMinute)}`;

                // Adapt layout for short vs standard duration cards
                if (duration <= 60) {
                    block.innerHTML = `
                        <div class="block-top-row">
                            <div class="block-proc-title" title="${slot.procedureName}">
                                <span>${icon}</span>
                                <span>${slot.procedureName}</span>
                            </div>
                        </div>
                        <div class="block-bottom-row">
                            <div class="block-patient-name" title="${slot.patientName}">👤 ${slot.patientName}</div>
                            <span class="block-duration-tag">${duration}m</span>
                        </div>
                    `;
                } else {
                    block.innerHTML = `
                        <div class="block-top-row">
                            <div class="block-proc-title" title="${slot.procedureName}">
                                <span>${icon}</span>
                                <span>${slot.procedureName}</span>
                            </div>
                            <span class="block-time-pill">${timeStr}</span>
                        </div>
                        <div class="block-bottom-row">
                            <div class="block-patient-name" title="Patient: ${slot.patientName} (${slot.patientId})">
                                👤 ${slot.patientName} &bull; <em>Dr. ${slot.surgeonName}</em>
                            </div>
                            <span class="block-duration-tag">${duration}m</span>
                        </div>
                    `;
                }

                block.title = `${slot.procedureName}\nPatient: ${slot.patientName} (${slot.patientId})\nSurgeon: Dr. ${slot.surgeonName}\nScheduled: ${timeStr} (${duration} mins)\nTriage: ${slot.triageLabel} (Tier ${slot.triageLevel})`;

                block.addEventListener('click', () => showSlotModal(room.id, slot));
                trackContainer.appendChild(block);

                // Add to Table View
                if (tableBody) {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td><strong>${slot.slotId}</strong></td>
                        <td>${room.name}</td>
                        <td><span class="bed-status-badge status-${slot.triageLevel <= 2 ? 'occupied' : 'available'}">${slot.triageLabel}</span></td>
                        <td><strong>${icon} ${slot.procedureName}</strong></td>
                        <td>${slot.patientName} (${slot.patientId})</td>
                        <td>Dr. ${slot.surgeonName}</td>
                        <td style="font-family:var(--font-mono);">${timeStr} (${duration}m)</td>
                        <td><button class="btn btn-secondary" style="padding:4px 8px; font-size:11px;" onclick="GanttModule.openModalDirectly('${room.id}', '${slot.slotId}')">Details / Overrun</button></td>
                    `;
                    tableBody.appendChild(tr);
                }

                // Render Turnaround Buffer with safe positioning
                if (slot.turnaroundMinutes > 0) {
                    const gapLeftPct = ((startOffset + duration) / totalTimelineMinutes) * 100;
                    const gapWidthPct = (slot.turnaroundMinutes / totalTimelineMinutes) * 100;

                    const gap = document.createElement('div');
                    gap.className = 'turnaround-gap';
                    gap.style.left = `${gapLeftPct}%`;
                    gap.style.width = `calc(${gapWidthPct}% - 4px)`;
                    gap.innerHTML = `<span>🧼 ${slot.turnaroundMinutes}m</span>`;
                    gap.title = `Sanitization & Sterilization Buffer: ${slot.turnaroundMinutes} minutes`;
                    trackContainer.appendChild(gap);
                }
            });

            row.appendChild(trackContainer);
            container.appendChild(row);
        });
    };

    const showSlotModal = (roomId, slot) => {
        const modal = document.getElementById('slotDetailModal');
        if (!modal) return;

        document.getElementById('modalPatientName').textContent = `${slot.patientName} (${slot.patientId})`;
        document.getElementById('modalProcedure').textContent = slot.procedureName;
        document.getElementById('modalSurgeon').textContent = `Dr. ${slot.surgeonName}`;
        document.getElementById('modalTriage').textContent = `${slot.triageLabel} (Triage Tier ${slot.triageLevel})`;
        document.getElementById('modalTimeWindow').textContent = `${formatTime(slot.startMinute)} - ${formatTime(slot.endMinute)} (${slot.endMinute - slot.startMinute} mins duration)`;

        document.getElementById('btnOverrun').onclick = async () => {
            const extra = parseInt(document.getElementById('overrunMinutes').value) || 30;
            await ApiClient.applyOverrun(roomId, slot.slotId, extra);
            modal.classList.remove('open');
            if (window.AppCoordinator) window.AppCoordinator.refreshAllData();
        };

        document.getElementById('btnCancelSlot').onclick = async () => {
            if (confirm(`Cancel scheduled procedure "${slot.procedureName}" for patient ${slot.patientName}?`)) {
                await ApiClient.cancelSlot(roomId, slot.slotId);
                modal.classList.remove('open');
                if (window.AppCoordinator) window.AppCoordinator.refreshAllData();
            }
        };

        modal.classList.add('open');
    };

    const openModalDirectly = (roomId, slotId) => {
        if (!currentScheduleData) return;
        const room = (currentScheduleData.rooms || []).find(r => r.id === roomId);
        if (room) {
            const slot = (room.slots || []).find(s => s.slotId === slotId);
            if (slot) showSlotModal(roomId, slot);
        }
    };

    return { init, render, openModalDirectly };
})();

document.addEventListener('DOMContentLoaded', GanttModule.init);
