// Quality & Operational Audit Reports Module
const ReportsModule = (() => {
    const init = () => {
        const fetchBtn = document.getElementById('btnRefreshReport');
        if (fetchBtn) fetchBtn.addEventListener('click', loadReport);

        const downloadBtn = document.getElementById('btnDownloadReport');
        if (downloadBtn) downloadBtn.addEventListener('click', downloadReport);
    };

    const loadReport = async () => {
        const preElem = document.getElementById('qualityReportOutput');
        if (!preElem) return;

        preElem.textContent = 'Generating comprehensive audit report from zero-dependency engine...';

        try {
            const res = await ApiClient.getReport();
            if (res.success) {
                preElem.textContent = res.reportText;
            }
        } catch (err) {
            preElem.textContent = 'Failed to load report: ' + err.message;
        }
    };

    const downloadReport = () => {
        const text = document.getElementById('qualityReportOutput').textContent;
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `Hospital_Scheduling_Audit_${new Date().toISOString().slice(0,10)}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    return { init, loadReport };
})();

document.addEventListener('DOMContentLoaded', ReportsModule.init);
