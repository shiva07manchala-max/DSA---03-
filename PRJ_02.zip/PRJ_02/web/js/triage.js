// Aho-Corasick Emergency Triage & String Analytics Lab
const TriageModule = (() => {
    const init = () => {
        const analyzeBtn = document.getElementById('btnAnalyzeTriage');
        if (analyzeBtn) {
            analyzeBtn.addEventListener('click', runTriageAnalysis);
        }

        const samplePresets = document.querySelectorAll('.triage-sample-btn');
        samplePresets.forEach(btn => {
            btn.addEventListener('click', () => {
                const sampleText = btn.getAttribute('data-sample');
                document.getElementById('triageInputText').value = sampleText;
                runTriageAnalysis();
            });
        });

        const fuzzyBtn = document.getElementById('btnRunFuzzy');
        if (fuzzyBtn) {
            fuzzyBtn.addEventListener('click', runFuzzySearch);
        }

        const lcsBtn = document.getElementById('btnRunLcs');
        if (lcsBtn) {
            lcsBtn.addEventListener('click', runSuffixLcs);
        }
    };

    const runTriageAnalysis = async () => {
        const text = document.getElementById('triageInputText').value;
        if (!text.trim()) return;

        try {
            const res = await ApiClient.evaluateTriage(text);
            renderTriageResults(res);
        } catch (err) {
            console.error('Triage analysis failed:', err);
        }
    };

    const renderTriageResults = (res) => {
        const resultContainer = document.getElementById('triageResultDisplay');
        if (!resultContainer) return;

        const badge = document.getElementById('inferredTriageBadge');
        if (badge) {
            badge.textContent = `${res.inferredLabel} (Level ${res.inferredLevel})`;
            badge.style.backgroundColor = res.inferredColor;
            badge.style.color = '#ffffff';
        }

        const tagsContainer = document.getElementById('detectedKeywordsContainer');
        if (tagsContainer) {
            tagsContainer.innerHTML = '';
            if (res.matches && res.matches.length > 0) {
                res.matches.forEach(m => {
                    const tag = document.createElement('span');
                    tag.className = `keyword-tag ${m.level === 1 ? 'crit-1' : ''}`;
                    tag.innerHTML = `🚨 <strong>${m.keyword}</strong> &bull; ${m.specialty} (Score: ${m.urgencyScore})`;
                    tagsContainer.appendChild(tag);
                });
            } else {
                tagsContainer.innerHTML = '<span style="color:var(--text-muted); font-size:13px;">No critical clinical alert patterns detected. Classified as Standard / Elective.</span>';
            }
        }
    };

    const runFuzzySearch = async () => {
        const q = document.getElementById('fuzzyQuery').value;
        const t = document.getElementById('fuzzyTarget').value;
        if (!q || !t) return;

        try {
            const res = await ApiClient.fuzzySearch(q, t);
            document.getElementById('fuzzyResult').innerHTML = `
                <div>Levenshtein Distance: <strong>${res.levenshtein}</strong></div>
                <div>Damerau-Levenshtein: <strong>${res.damerau}</strong></div>
                <div>Similarity Score: <strong>${(res.similarity * 100).toFixed(1)}%</strong></div>
            `;
        } catch (e) {
            console.error(e);
        }
    };

    const runSuffixLcs = async () => {
        const t1 = document.getElementById('lcsText1').value;
        const t2 = document.getElementById('lcsText2').value;
        if (!t1 || !t2) return;

        try {
            const res = await ApiClient.suffixLcs(t1, t2);
            document.getElementById('lcsResult').innerHTML = `
                <div>Longest Common Substring: <strong style="color:var(--accent-blue)">"${res.longestCommonSubstring}"</strong></div>
                <div>Length: <strong>${res.length} chars</strong></div>
            `;
        } catch (e) {
            console.error(e);
        }
    };

    return { init };
})();

document.addEventListener('DOMContentLoaded', TriageModule.init);
